<?php
/**
 * This class extends Storeup_Theme_Functions.
 */
if ( ! class_exists( 'Storeup_Niche_Theme' ) ) {
	class Storeup_Niche_Theme extends Storeup_Theme_Functions {

		/**
	     * load seminar custom meta.
	     */
		function storeup_theme_custom_meta() {
			parent::storeup_theme_custom_meta();
			$this->child_index_require_once( STOREUP_DIR . 'location/location-meta.php' );
			$this->child_index_require_once( STOREUP_DIR . 'location/booking-meta.php' );
		}

		function storeup_theme_custom_widgets() {
			parent::storeup_theme_custom_widgets();
			$this->child_index_require_once( STOREUP_DIR . 'location/location-wg-info.php' );
		}

		function child_index_require_once( $file ) {
			$child_file = str_replace( get_template_directory(), get_stylesheet_directory(), $file );
			if ( file_exists( $child_file ) ) {
				require_once( $child_file );
			} else {
				require_once( $file );
			}
		}

		function storeup_get_vars( $type ) {

			$storeup_tax_options = parent::storeup_get_vars( $type );

			switch ( $type ) {
				/**
				 * get service slug and name.
				 */
                case 'locations':
                    $args = array(
					  'posts_per_page'   => -1,
					  'offset'           => 0,
					  'orderby'          => 'post_date',
					  'order'            => 'DESC',
					  'post_type'        => 'location',
					  'post_status'      => 'publish',
					  'suppress_filters' => true,
					);
					$storeup_locations = get_posts( $args );
					foreach ( $storeup_locations as $key => $entry ) {
					   $storeup_tax_options[$entry->ID] = $entry->post_title;
					}
					break;
			}
			return $storeup_tax_options;
		}
	}
	$storeup_theme_ob = new Storeup_Niche_Theme();
	$storeup_admin_img_uri = STOREUP_FRAMEWORK_URI . 'admin/images/';
}
require_once( storeup_child_require_file( STOREUP_DIR . 'location/location-functions.php' ) );
require_once( storeup_child_require_file( STOREUP_DIR . 'storeup-functions.php' ) );
require_once( storeup_child_require_file( STOREUP_DIR . 'additional-themeoptions.php' ) );
require_once( storeup_child_require_file( STOREUP_DIR . 'posttype-labeloptions.php' ) );

// Postype Meta Cases
require_once( storeup_child_require_file( STOREUP_DIR . 'meta-cases.php' ) );

// S I N G L E  P O S T T Y P E S
//---------------------------------------------------------------------------
if ( ! function_exists( 'storeup_cpt_single_page' ) ) {
	function storeup_cpt_single_page() {

		global $wp_query, $post;
		$customtype = $post->post_type;

		if ( file_exists( storeup_child_require_file( STOREUP_DIR . $customtype . '/' . 'single-' . $customtype . '.php') ) ) {
			return storeup_child_require_file( STOREUP_DIR . $customtype . '/single-' . $customtype . '.php' );
		} elseif ( file_exists( storeup_child_require_file( STOREUP_THEME_DIR . '/single-' . $customtype . '.php' ) ) ) {
			return storeup_child_require_file( STOREUP_THEME_DIR . '/single-' . $customtype . '.php' );
		} else {
			return storeup_child_require_file( STOREUP_THEME_DIR . '/single.php' );
		}
	}
	add_filter( 'single_template', 'storeup_cpt_single_page' );
}

//Retrieve path of taxonomy template in current or parent template.
if ( ! function_exists( 'storeup_cpt_taxonomy' ) ) {
	function storeup_cpt_taxonomy() {

		global $wp_query, $post;
		$customtype = $post->post_type;
		$name 		= get_queried_object()->taxonomy;

		if ( file_exists( storeup_child_require_file( STOREUP_DIR . $customtype . '/taxonomy-' . $name . '.php' ) ) ) {
			return storeup_child_require_file( STOREUP_DIR . $customtype . '/taxonomy-' . $name . '.php' );
		} elseif ( storeup_child_require_file( file_exists( STOREUP_THEME_DIR . '/taxonomy-' . $name . '.php' ) ) ) {
			return storeup_child_require_file( STOREUP_THEME_DIR . '/taxonomy-' . $name . '.php' );
		} else {
			return storeup_child_require_file( STOREUP_THEME_DIR . '/archive.php' );
		}
	}
	add_filter( 'taxonomy_template', 'storeup_cpt_taxonomy' );
}

/**
 * function storeup_admin_enqueue_custom_scripts()
 * admin enqueue styles and scripts
 */
if ( ! function_exists( 'storeup_admin_enqueue_custom_scripts' ) ) {
	function storeup_admin_enqueue_custom_scripts() {
		global $pagenow,$typenow;

		if ( is_admin() &&  'location' === $typenow  && ( 'post-new.php' === $pagenow  || 'post.php' === $pagenow )  ) {
			$storeup_google_api_key = get_option( 'storeup_google_api_key' ) ? 'key=' . get_option( 'storeup_google_api_key' ) :'signed_in=false';
			wp_enqueue_script( 'storeup-gmap',  '//maps.googleapis.com/maps/api/js?v=3.exp&' . $storeup_google_api_key . '&libraries=places','jquery','','' );
			wp_enqueue_script( 'storeup-custommap',  STOREUP_URI . 'js/admin_map.js', false, false, 'all' );
		}
		wp_enqueue_style( 'storeup-map-css', STOREUP_URI . 'css/mapping.css', '', '', 'all' );
	}
	add_action( 'admin_enqueue_scripts', 'storeup_admin_enqueue_custom_scripts' );
}
/**
 * function storeup_cpt_frontend_enqueue()
 *
 * enqueues both scripts and styles on front end.
 * @uses wp_enqueue_style().
 * @uses wp_enqueue_script()
 */
if ( ! function_exists( 'storeup_cpt_frontend_enqueue' ) ) {
	function storeup_cpt_frontend_enqueue() {
		wp_enqueue_style( 'storeup-niche-style', STOREUP_URI . 'css/storeup-style.css' );

		$storeup_google_api_key = get_option( 'storeup_google_api_key' ) ? 'key=' . get_option( 'storeup_google_api_key' ) :'signed_in=false';
		wp_enqueue_script( 'storeup-gmap',  '//maps.googleapis.com/maps/api/js?v=3.exp&' . $storeup_google_api_key . '&libraries=places','jquery','','' );
		wp_enqueue_script( 'storeup_loc_map', STOREUP_URI . 'js/frontend_map.js', '', '', '' );

		if ( is_page_template( 'storeup-niche/template-booking.php' ) ) {
			wp_enqueue_style( 'storeup-weather-style', STOREUP_URI . 'css/simpleWeather.css' );
			wp_enqueue_script( 'jquery-ui-datepicker' );
			$storeup_bk_datepicker_lang = get_option( 'storeup_datepicker_language' );
			if ( $storeup_bk_datepicker_lang != '' ) {
				wp_enqueue_script( 'storeup-datepicker-lnguage', STOREUP_THEME_URI . '/js/i18n/datepicker-' . $storeup_bk_datepicker_lang . '.js', false, false, 'all' );
			}
			wp_enqueue_style( 'storeup-ui-datepicker', STOREUP_FRAMEWORK_URI . 'admin/css/storeup-datepicker.css' );
			wp_enqueue_script( 'storeup-simpleweather', STOREUP_URI . 'js/jquery.simpleWeather.min.js', false,false,'all' );
		}
		wp_enqueue_script( 'storeup-front-script', STOREUP_URI . 'js/storeup-front-script.js', array( 'jquery' ), false, true );
		wp_enqueue_script( 'storeup-table-sorter', STOREUP_URI . 'js/jquery.tablesorter.min.js', array( 'jquery' ), false, true );
	}
	add_action( 'wp_enqueue_scripts', 'storeup_cpt_frontend_enqueue' );
}
