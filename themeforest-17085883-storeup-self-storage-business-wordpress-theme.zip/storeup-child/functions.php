<?php
function storeup_child_scripts( $file ) {
	$child_file = str_replace( get_template_directory_uri(), get_stylesheet_directory_uri(), $file );
	return( $child_file );
}
/**
 * Enqueue the files in child theme
 * If you wish to change any js file or css file then use 'storeup_child_scripts' function for that specific file and place it in relevant folder.
 * for eg:wp_register_script('iva-countTo', storeup_child_scripts(THEME_JS . '/jquery.countTo.js'), 'jquery','1.0','in_footer'); 
 */
function storeup_child_require_file( $file ) {
	$child_file = str_replace( get_template_directory(), get_stylesheet_directory(), $file );
	if ( file_exists( $child_file ) ) {
		return( $child_file );
	} else {
		return( $file );
	}
}
/**
 * Register and enqueue scripts.
 */
if ( ! function_exists( 'storeup_theme_enqueue_scripts' ) ) {
	function storeup_theme_enqueue_scripts() {

		$storeup_theme_data	= wp_get_theme();
		$storeup_theme_version = $storeup_theme_data->get( 'Version' );

		global $post;

		if ( ! $post ) return false;

		$post_content = $post->post_content;

		// Enqueue scripts.
		wp_enqueue_script( 'storeup-sf-hover', STOREUP_THEME_JS . '/hoverIntent.js',array( 'jquery' ),'', true );
		wp_enqueue_script( 'storeup-sf-menu', STOREUP_THEME_JS . '/superfish.js',array( 'jquery' ),'',true );

		if ( is_singular( 'gallery' ) || stripos( $post_content, '[gallery' )  || is_page_template( 'template-blog.php' ) ) {
			wp_enqueue_script( 'storeup-prettyphoto', STOREUP_THEME_JS . '/jquery.prettyPhoto.js','','',true );
			wp_enqueue_style( 'storeup-prettyphoto', STOREUP_THEME_CSS . '/prettyPhoto.css', array(), $storeup_theme_version, false );
		}

		wp_enqueue_script( 'jquery-fitvids', STOREUP_THEME_JS . '/jquery.fitvids.js',array( 'jquery' ), $storeup_theme_version ,true );
		wp_enqueue_script( 'storeup-customjs', STOREUP_THEME_JS . '/storeup-custom.js', array( 'jquery' ), $storeup_theme_version , true );

		if ( is_singular() ) {
			wp_enqueue_script( 'comment-reply' );
		}

		// AJAX URL

		$storeup_data['ajaxurl'] = admin_url( 'admin-ajax.php' );

		// HOME URL
		$storeup_data['home_url'] = get_home_url();

		// Directory URI
		$storeup_data['directory_uri'] = get_template_directory_uri();

		// Pass data to javascript
		$storeup_params = array(
			'l10n_print_after' => 'storeup_localize_script_param = ' . wp_json_encode( $storeup_data ) . ';',
		);
		wp_localize_script( 'jquery', 'storeup_localize_script_param', $storeup_params );

		// Enqueue styles.
		wp_enqueue_style( 'storeup-theme', get_stylesheet_uri() );
		wp_enqueue_style( 'font-awesome', STOREUP_THEME_CSS . '/fontawesome/css/font-awesome.css' );
		wp_enqueue_style( 'fontello', STOREUP_THEME_CSS . '/fontello/css/aicon_.css' );
		wp_enqueue_style( 'fontello-animation', STOREUP_THEME_CSS . '/fontello/css/animation.css' );
		wp_enqueue_style( 'pe-icon-7-stroke', STOREUP_THEME_CSS . '/pe-icon-7-stroke/css/pe-icon-7-stroke.css' );
		wp_enqueue_style( 'storeup-responsive', STOREUP_THEME_CSS . '/responsive.css',array( 'storeup-niche-style' ), $storeup_theme_version, 'all' );

		if ( get_option( 'storeup_custom_skin' ) != '0' ) {
			$storeup_custom_skin = get_option( 'storeup_custom_skin' );
			wp_enqueue_style( 'storeup-presets', STOREUP_THEME_URI . '/colors/' . $storeup_custom_skin );
		}
	}
	add_action( 'wp_enqueue_scripts','storeup_theme_enqueue_scripts' );
}
/**
 * Flex Slider Enqueue Scripts
 */
if ( ! function_exists( 'storeup_flexslider_enqueue_scripts' ) ) {
	add_action( 'storeup_theme_flexslider','storeup_flexslider_enqueue_scripts' );
	function storeup_flexslider_enqueue_scripts() {
		$fs_slidespeed = get_option( 'storeup_flexslidespeed' ) ? get_option( 'storeup_flexslidespeed' ) : '3000';
		$fs_slideeffect = get_option( 'storeup_flexslideeffect' ) ? get_option( 'storeup_flexslideeffect' ) : 'fade';
		$fs_slidednav = get_option( 'storeup_flexslidednav' ) ? get_option( 'storeup_flexslidednav' ) : 'true';
		$flexslider_args = array(
								'slideeffect' => $fs_slideeffect,
								'slidespeed'  => $fs_slidespeed,
								'slidednav'	  => $fs_slidednav,
							);
		wp_enqueue_script( 'jquery-flexslider', STOREUP_THEME_JS . '/jquery.flexslider-min.js', array( 'jquery' ), '', true );
		wp_enqueue_script( 'storeup-easing', STOREUP_THEME_JS . '/jquery.easing.1.3.js',array( 'jquery' ), '', true );
		wp_localize_script( 'jquery-flexslider', 'flexslider_args', $flexslider_args );
		wp_enqueue_style( 'storeup-flexslider-style', STOREUP_THEME_CSS . '/flexslider.css' );
	}
}

/**
 * Theme Class
 */
 if ( ! class_exists( 'Storeup_Theme_Functions' ) ) {
 	class Storeup_Theme_Functions {
		public $storeup_meta_box;
		public function __construct() {
			$this->storeup_theme_constants();
			$this->storeup_theme_support();
			$this->storeup_theme_admin_scripts();
			$this->storeup_theme_admin_interface();
			$this->storeup_theme_custom_widgets();
			$this->storeup_theme_custom_meta();
			$this->storeup_theme_meta_generator();
			$this->storeup_theme_extras();
		}
		
		function storeup_theme_constants() {

			// framework general variables and directory paths.
			$storeup_theme_data	 = wp_get_theme();
			$storeup_theme_version  = $storeup_theme_data->get( 'Version' );
			$storeup_theme_name   	= $storeup_theme_data->get( 'Name' );

			/**
			 * Set the file path based on whether the Options
			 * Framework is in a parent theme or child theme
			 * Directory Structure
			 */
			define( 'STOREUP_FRAMEWORK', '2.0' );
			define( 'STOREUP_THEME_NAME', 'storeup' );
			define( 'STOREUP_THEME_VERSION', $storeup_theme_version );
			define( 'STOREUP_THEME_URI', get_template_directory_uri() );
			define( 'STOREUP_THEME_DIR', get_template_directory() );
			define( 'STOREUP_THEME_JS', STOREUP_THEME_URI . '/js' );
			define( 'STOREUP_THEME_CSS', STOREUP_THEME_URI . '/css' );
			define( 'STOREUP_FRAMEWORK_DIR', STOREUP_THEME_DIR . '/framework/' );
			define( 'STOREUP_FRAMEWORK_URI', STOREUP_THEME_URI . '/framework/' );
			define( 'STOREUP_ADMIN_URI',  STOREUP_FRAMEWORK_URI . 'admin' );
			define( 'STOREUP_ADMIN_DIR',  STOREUP_FRAMEWORK_DIR . 'admin' );
			define( 'STOREUP_THEME_WIDGETS',  STOREUP_FRAMEWORK_DIR . 'widgets/' );
			define( 'STOREUP_THEME_CUSTOM_META',  STOREUP_FRAMEWORK_DIR . 'custom-meta/' );
		}
		/**
		 * allows a theme to register its support of a certain features
		 */
		function storeup_theme_support() {

			add_theme_support( 'post-formats', array(
				'aside',
				'audio',
				'link',
				'image',
				'gallery',
				'quote',
				'status',
				'video',
				'event',
			));
			add_theme_support( 'post-thumbnails' );
			add_theme_support( 'automatic-feed-links' );
			add_editor_style( 'editor-style.css' );
			add_theme_support( 'menus' );
			add_theme_support( 'title-tag' );

			// Register menu.
			register_nav_menus( array(
				'primary-menu' => esc_html__( 'Primary Menu', 'storeup' ),
			));


			// Define content width.
			if ( ! isset( $content_width ) ) {
				$content_width = 1100;
			}
		}
		/**
		 * scripts and styles enqueue .
		 */
		function storeup_theme_admin_scripts() {
			$this->child_require_once( STOREUP_FRAMEWORK_DIR . 'common/admin-scripts.php' );
		}
		/**
		 * Admin interface .
		 */
		function storeup_theme_admin_interface() {
			$this->child_require_once( STOREUP_FRAMEWORK_DIR . 'common/iva-googlefont.php' );
			$this->child_require_once( STOREUP_FRAMEWORK_DIR . 'admin/admin-interface.php' );
			$this->child_require_once( STOREUP_FRAMEWORK_DIR . 'admin/theme-options.php' );
		}
		/**
		 * Widgets .
		 */
		function storeup_theme_custom_widgets() {
			$this->child_require_once( STOREUP_THEME_WIDGETS . '/register-widget.php' );
			$this->child_require_once( STOREUP_THEME_WIDGETS . '/contactinfo.php' );
			$this->child_require_once( STOREUP_THEME_WIDGETS . '/sociable.php' );
			$this->child_require_once( STOREUP_THEME_WIDGETS . '/recentpost.php' );
			$this->child_require_once( STOREUP_THEME_WIDGETS . '/icon-box.php' );
			$this->child_require_once( STOREUP_THEME_WIDGETS . '/button.php' );
		}
		/** load meta generator templates
		 * @files slider, Menus, page, posts,
		 */
		function storeup_theme_custom_meta() {
			$this->child_require_once( STOREUP_THEME_CUSTOM_META . '/page-meta.php' );
			$this->child_require_once( STOREUP_THEME_CUSTOM_META . '/post-meta.php' );
			$this->child_require_once( STOREUP_THEME_CUSTOM_META . '/slider-meta.php' );
			$this->child_require_once( STOREUP_THEME_CUSTOM_META . '/testimonial-meta.php' );
			$this->child_require_once( STOREUP_THEME_CUSTOM_META . '/gallery-meta.php' );
		}

		function storeup_theme_meta_generator() {
			$this->child_require_once( STOREUP_THEME_CUSTOM_META . '/meta-generator.php' );
		}

		/**
		 * Theme functions
		 * @uses skin generat$this->child_require_once(or
		 * @uses pagination
		 * @uses sociables
		 * @uses Aqua imageresize // Credits : http://aquagraphite.com/
		 * @uses plugin activation class
		 */
		function storeup_theme_extras() {
			$this->child_require_once( STOREUP_THEME_DIR . '/css/skin.php' );
			$this->child_require_once( STOREUP_FRAMEWORK_DIR . 'includes/mega-menu.php' );
			$this->child_require_once( STOREUP_FRAMEWORK_DIR . 'common/iva-generator.php' );
			$this->child_require_once( STOREUP_FRAMEWORK_DIR . 'common/sociables.php' );
			$this->child_require_once( STOREUP_FRAMEWORK_DIR . 'includes/image-resize.php' );
			$this->child_require_once( STOREUP_FRAMEWORK_DIR . 'includes/class-activation.php' );
		}
		
		
		function child_require_once( $file ) {
			$child_file = str_replace(get_template_directory(), get_stylesheet_directory(), $file );
			if ( file_exists( $child_file ) ) {
				require_once( $child_file );
			} else {
				require_once( $file );
			}
		}
		
		/**
		 * Custom switch case for fetching
		 * posts, post-types, custom-taxonomies, tags
		 */
		 function storeup_get_vars( $type ) {
			$storeup_tax_options = array();
			switch ( $type ) {
				/**
				 * Get page titles.
				 */
				case 'pages':
					$storeup_get_pages = get_pages( 'sort_column=post_parent,menu_order' );
					if ( ! empty( $storeup_get_pages ) && ! is_wp_error( $storeup_get_pages ) ) {
						foreach ( $storeup_get_pages as $page ) {
							$storeup_tax_options[ $page->ID ] = $page->post_title;
						}
					}
					break;
				/**
				 * Get slider slug and name.
				 */
				case 'slider':
					$storeup_slider_cats = get_terms( 'slider_cat', 'orderby=name&hide_empty=0' );
					if ( ! empty( $storeup_slider_cats ) && ! is_wp_error( $storeup_slider_cats ) ) {
						foreach ( $storeup_slider_cats as $slider ) {
							$storeup_tax_options[ $slider->slug ] = $slider->name;
						}
					}
					break;

				/**
				 * Get posts slug and name.
				 */
				case 'posts':
					$storeup_post_cats = get_categories( 'hide_empty=0' );
					if ( ! empty( $storeup_post_cats ) && ! is_wp_error( $storeup_post_cats ) ) {
						foreach ( $storeup_post_cats as $cat ) {
							$storeup_tax_options[ $cat->slug ] = $cat->name;
						}
					}
					break;

				/**
				 * Get categories slug and name.
				 */
				case 'categories':
					$storeup_post_cats = get_categories( 'hide_empty=true' );
					if ( ! empty( $storeup_post_cats ) && ! is_wp_error( $storeup_post_cats ) ) {
						foreach ( $storeup_post_cats as $cat ) {
							$storeup_tax_options[ $cat->term_id ] = $cat->name;
						}
					}
					break;

				/**
				 * Get taxonomy tags.
				 */
				case 'tags':
					$storeup_tags = get_tags(array(
						'taxonomy' => 'post_tag',
					) );
					if ( ! empty( $storeup_tags ) && ! is_wp_error( $storeup_tags ) ) {
						foreach ( $storeup_tags as $tags ) {
							$storeup_tax_options[ $tags->slug ] = $tags->name;
						}
					}
					break;

				/**
				 * Slider arrays for theme options.
				 */
				case 'slider_type':
					$storeup_tax_options = array(
						'' 				=> esc_html__( 'Select Slider', 'storeup' ),
						'flexslider' 	=> esc_html__( 'Flex Slider', 'storeup' ),
						'owlslider' 	=> esc_html__( 'Owl Slider', 'storeup' ),
						'static_image' 	=> esc_html__( 'Static Image', 'storeup' ),
						'customslider'	=> esc_html__( 'Custom Slider', 'storeup' ),
					);
					break;
			}

			return $storeup_tax_options;
		}
	}
}
/**
 * Section to decide whether use child theme or parent theme 
 */
if ( ! defined('STOREUP_NICHE_DIR') ) {
	define( 'STOREUP_NICHE_DIR', storeup_child_require_file( get_template_directory() . '/storeup-niche/') );
}
