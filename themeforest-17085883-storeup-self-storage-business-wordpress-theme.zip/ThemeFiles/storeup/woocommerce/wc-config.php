<?php

add_action( 'after_setup_theme', 'woocommerce_support' );
function woocommerce_support() {
    add_theme_support( 'woocommerce' );
}

// Register custom styles
if ( ! is_admin() ) {
	add_action( 'wp_enqueue_scripts', 'storeup_woocommerce_register_assets' );
}
add_theme_support( 'wc-product-gallery-zoom' );
add_theme_support( 'wc-product-gallery-lightbox' );
add_theme_support( 'wc-product-gallery-slider' );
if ( ! function_exists( 'storeup_woocommerce_register_assets' ) ) {
	function storeup_woocommerce_register_assets() {
		wp_enqueue_style( 'storeup-wc-css', get_template_directory_uri() . '/woocommerce/assets/css/woocommerce.css' );
	}
}
add_filter( 'loop_shop_columns', 'storeup_loop_columns' );
if ( ! function_exists( 'storeup_loop_columns' ) ) {
	function storeup_loop_columns() {
		global $woocommerce;
		$shop_pageid = get_option( 'woocommerce_shop_page_id' );
		if ( storeup_generator( 'storeup_sidebar_option', $shop_pageid ) == 'fullwidth' ) {
			$columns = 4;
		} else {
			$columns = 3;
		}
		return $columns;
	}
}

// Related Prducts
add_filter( 'woocommerce_output_related_products_args', 'storeup_related_columns' );
if ( ! function_exists( 'storeup_related_columns' ) ) {
	function storeup_related_columns( $args ) {
		global $product;
		$id = $product->get_id();	
		if ( storeup_generator( 'storeup_sidebar_option', $id ) == 'fullwidth' ) {
			$args['posts_per_page'] = 4;
	 		$args['columns'] = 4;
		}else{
			$args['posts_per_page'] = 3;
			$args['columns'] = 3;
		}
		return $args;
	}
}
// Upsell Prducts
add_filter( 'woocommerce_upsell_display_args', 'storeup_upsell_columns' );
if ( ! function_exists( 'storeup_upsell_columns' ) ) {
	function storeup_upsell_columns( $args ) {
		global $product;
		$id = $product->get_id();
		if ( storeup_generator( 'storeup_sidebar_option', $id ) == 'fullwidth' ) {
			$args['posts_per_page'] = 4;
	 		$args['columns'] = 4;
		}else{
			$args['posts_per_page'] = 3;
			$args['columns'] = 3;
		}
		return $args;
	}
}

if ( ! function_exists( 'storeup_shop_loop_item_author' ) ) {
	function storeup_shop_loop_item_author() {
		$html = '<div class="author">' . esc_html__( 'by', 'storeup' ) . ' ' . get_the_author() . '</div>';
		echo $html;
	}
}
add_action( 'woocommerce_shop_loop_item_title', 'storeup_shop_loop_item_author', 10 );
