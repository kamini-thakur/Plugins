<?php
// E N Q U E U E   S C R I P T S   I N   A D M I N
if ( ! function_exists( 'storeup_admin_enqueue_scripts' ) ) {
	function storeup_admin_enqueue_scripts() {

		global $storeup_theme_version;

		wp_enqueue_script( 'storeup-of-script', STOREUP_FRAMEWORK_URI . 'admin/js/storeup-of-script.js', array(), $storeup_theme_version );

		wp_enqueue_script( 'jquery-ui-core' );
		wp_enqueue_script( 'jquery-ui-datepicker' );
		wp_enqueue_script( 'wp-color-picker' );

		wp_enqueue_script( 'jquery-ui-timepicker-addon', STOREUP_FRAMEWORK_URI . 'admin/js/jquery-ui-timepicker-addon.js',false,false,'all' );

		$datepicker_language = get_option( 'storeup_datepicker_language' ) ? get_option( 'storeup_datepicker_language' ):'';
		if ( $datepicker_language != '' ) {
			wp_enqueue_script( 'datepicker_language', STOREUP_THEME_URI . '/js/i18n/datepicker-' . $datepicker_language . '.js' );
		}
		wp_localize_script( 'storeup-of-script', 'storeup_localize_script_param', array(
			'SiteUrl' => get_template_directory_uri(),
		) );
		wp_localize_script( 'storeup-of-script', 'storeup_admin_js_param', array(
			'themeoption_reset' 		=> esc_html__( 'Click OK to reset. Any settings will be lost!', 'storeup' ),
			'importing_data_load' 		=> esc_html__( 'Importing the sample data will overwrite your current pages and content. Please make sure you take a backup of content and proceed with importing.', 'storeup' ),
			'importer_success' 			=> esc_html__( 'Imported Successfully, please wait a few seconds to reload the page', 'storeup' ),
			'ob_import_success' 		=> esc_html__( 'Imported successfully, please wait a few seconds until reloading the page', 'storeup' ),
			'importer_delete_confirm'	=> esc_html__( 'Are you sure you want to delete this theme options permanently?', 'storeup' ),
			'importer_delete_success'	=> esc_html__( 'Deleted successfully, please wait few seconds until the page reloads', 'storeup' ),
		) );
		wp_enqueue_style( 'wp-color-picker' );
		wp_enqueue_style( 'storeup-admin-style', STOREUP_FRAMEWORK_URI . 'admin/css/admin-style.css', array(), $storeup_theme_version );
		wp_enqueue_style( 'storeup-ui-datepicker', STOREUP_FRAMEWORK_URI . 'admin/css/storeup-datepicker.css' );
		wp_enqueue_style( 'font-awesome', STOREUP_THEME_CSS . '/fontawesome/css/font-awesome.css' );
	}
}
add_action( 'admin_enqueue_scripts', 'storeup_admin_enqueue_scripts' );
