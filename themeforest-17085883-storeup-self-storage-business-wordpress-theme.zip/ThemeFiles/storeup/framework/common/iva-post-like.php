<?php
class Storeup_Post_Like {
	function __construct() {
		// Enqueues the scripts.
		add_action( 'wp_enqueue_scripts', array( &$this, 'storeup_enqueue_scripts' ) );
		// Handle the request
		add_action( 'wp_ajax_storeup-love', array( &$this, 'storeup_ajax_like' ) );
		// Executes for users that are not logged in.
		add_action( 'wp_ajax_nopriv_storeup-love', array( &$this, 'storeup_ajax_like' ) );
	}
	/**
	 * function storeup_enqueue_scripts()
	 *
	 * enqueues the scripts.
	 * @uses wp_enqueue_script()
	 */
	function storeup_enqueue_scripts() {
		wp_enqueue_script( 'storeup-post-like', get_template_directory_uri() . '/js/storeup-post-like.js', array( 'jquery' ), '1.0', true );
		// In javascript, object properties are accessed as ajax_object.ajax_url
		wp_localize_script( 'storeup-post-like', 'ivaLove', array(
			'ajaxurl' => admin_url( 'admin-ajax.php' ),
			'youLikedit' => esc_html__( 'You already liked it!', 'storeup' ),
		));
	}
	/**
	 *
	 * Handle request then generate response using WP_Ajax_Response
	 *
	 */
	function storeup_ajax_like( $post_id ) {
		$likes_id = sanitize_text_field( $_POST['loves_id'] );
		// Update
		if ( isset( $likes_id ) ) {
			$post_id = str_replace( 'iva-love-', '', $likes_id );
			echo wp_kses_post( $this->storeup_like_post( $post_id, 'update' ) );
		} else {
			$post_id = str_replace( 'iva-love-', '', $likes_id );
			echo wp_kses_post( $this->storeup_like_post( $post_id, 'get' ) );
		}

		exit;
	}

	function storeup_like_post( $post_id, $action = 'get' ) {
		if ( ! is_numeric( $post_id ) ) return;
		switch ( $action ) {

			case 'get':
				$love_count = get_post_meta( $post_id, '_storeup_love', true );
				if ( ! $love_count ) {
					$love_count = 0;
					add_post_meta( $post_id, '_storeup_love', $love_count, true );
				}

				return '<span class="iva-love-count">' . $love_count . '</span>';
				break;

			case 'update':
				$love_count = get_post_meta( $post_id, '_storeup_love', true );
				if ( isset( $_COOKIE[ 'iva_love_' . $post_id ] ) ) return $love_count;

				$love_count++;
				update_post_meta( $post_id, '_storeup_love', $love_count );
				setcookie( 'iva_love_' . $post_id, $post_id, time() * 20, '/' );

				return '<span class="iva-love-count">' . $love_count . '</span>';
				break;

		}
	}


	function storeup_add_like() {
		global $post;

		$output = $this->storeup_like_post( $post->ID );
		$class = 'iva-love';
		$title = esc_html__( 'Like this','storeup' );
		if ( isset( $_COOKIE[ 'iva_love_' . $post->ID ] ) ) {
			$class = 'iva-love loved';
			$title = esc_html__( 'You already like this!','storeup' );
		}

		return '<a href="#" class="' . $class . '" id="iva-love-' . $post->ID . '" title="' . $title . '">' . $output . ' ' . esc_html__( 'Likes', 'storeup' ) . '</a>';
	}
}

$storeup_post_like = new Storeup_Post_Like();

// get the ball rollin'
function storeup_post_like( $storeup_like = '' ) {
	global $storeup_post_like;
	if ( $storeup_like == 'iva_like' ) {
		return $storeup_post_like->storeup_add_like();
	} else {
		echo wp_kses_post( $storeup_post_like->storeup_add_like() );
	}
}
