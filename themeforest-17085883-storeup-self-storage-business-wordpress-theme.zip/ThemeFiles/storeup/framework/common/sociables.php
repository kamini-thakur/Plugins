<?php
// Sociables
function storeup_sociables( $color = 'black' ) {
	$out = '';
	if ( get_option( 'storeup_social_bookmark' ) != '' ) {

		$storeup_social_bookmark_icons = explode( '#;', get_option( 'storeup_social_bookmark' ) );
		$out = '<div class="iva_socials ' . $color . '">';
		for ( $i = 0; $i < count( $storeup_social_bookmark_icons ); $i++ ) {

			$storeup_social_icon = explode( '#|', $storeup_social_bookmark_icons[ $i ] );
			if ( $storeup_social_icon[1] == '' ) {
				$storeup_social_icon[1] = '#';
			}

			$out .= '<a class="at-social-link" href="' . esc_url( $storeup_social_icon[2] ) . '" target="_blank">';
			$out .= '<i class="fa fa-' . $storeup_social_icon[1] . ' fa-fw" title="' . $storeup_social_icon[0] . '"></i><span class="ttip">' . ucfirst( $storeup_social_icon[1] ) . '</span></a>';

		} //End for
		$out .= '</div>';
	}
	return $out;
}
