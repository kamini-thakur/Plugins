<?php
if ( ! class_exists( 'Storeup_Generator_Class' ) ) {
	class Storeup_Generator_Class {

		// P R I M A R Y   M E N U
		//--------------------------------------------------------
		function storeup_primary_menu() {
			if ( has_nav_menu( 'primary-menu' ) ) {
				wp_nav_menu(array(
					'container'     => false,
					'theme_location' => 'primary-menu',
					'menu_class'    => 'sf-menu',
					'menu_id'       => 'iva_menu',
					'echo'          => true,
					'before'        => '',
					'after'         => '',
					'link_before'   => '',
					'link_after'    => '',
					'depth'         => 0,
					'walker'        => new Storeup_Custom_Menu_Walker(),
				) );
			} else {
				echo '<ul class="iva_menu sf-menu"><li><a class="alignright" href="' . esc_url( home_url( '/' ) . 'wp-admin/nav-menus.php' ) . '">' . esc_html__( 'WordPress Menu is not assigned or created.', 'storeup' ) . '</a></li></ul>';
			}
		}
		function storeup_mobile_menu() {
			if ( has_nav_menu( 'primary-menu' ) ) {
				wp_nav_menu(array(
					'container'     => 'div',
					'container_class' => 'iva-mobile-menu',
					'theme_location' => 'primary-menu',
					'menu_class'	=> 'iva_mmenu',
					'echo'          => true,
					'before'        => '',
					'after'         => '',
					'link_before'   => '',
					'link_after'    => '',
					'depth'         => 0,
					'walker'        => new Storeup_Mobile_Custom_Menu_Walker(),
				));
			}
		}

		function storeup_vertical_menu() {
			if (has_nav_menu( 'primary-menu' ) ) {
				wp_nav_menu(array(
					'container'     => 'div',
					'container_class'=> 'iva_vertical_menu',
					'theme_location'=> 'primary-menu',
					'menu_class'    => 'sf-menu sf-vertical',
					'menu_id'       => 'iva_menu',
					'echo'          => true,
					'before'        => '',
					'after'         => '',
					'link_before'   => '',
					'link_after'    => '',
					'depth'         => 0,
					'walker'        => new Storeup_Custom_Menu_Walker()
				));
			}
		}

		// L O G O   G E N E R A T O R
		//--------------------------------------------------------
		function storeup_logo( $storeup_logoid ) {
			$storeup_logo = get_option( 'storeup_logo' );
			if ( $storeup_logo == 'logo' ) {

				$storeup_img_attachment_id = storeup_get_attachment_id_from_src( get_option( $storeup_logoid ) );
				$storeup_image_attributes  = wp_get_attachment_image_src( $storeup_img_attachment_id , 'full' ); // returns an array
				?>
				<a href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php bloginfo( 'name' ); ?>">
					<img src="<?php echo esc_url( $storeup_image_attributes[0] ); ?>" alt="<?php bloginfo( 'name' ); ?>"  width="<?php echo esc_attr( $storeup_image_attributes[1] ); ?>" height="<?php echo esc_attr( $storeup_image_attributes[2] ); ?>" />
				</a>
				<?php
			} else { ?>
				<h1 id="site-title"><span><a href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?>	</a></span></h1>
				<h2 id="site-description"><?php echo bloginfo( 'description' ); ?></h2>
				<?php
			}
		}
		// S I D E B A R   P O S I T I O N S
		//--------------------------------------------------------
		function storeup_sidebar_option( $postid ) {
			// Get sidebar class and adds sub class to pagemid block layout

			$storeup_sidebar_layout = get_option( 'storeup_defaultlayout' ) ? get_option( 'storeup_defaultlayout' ) : 'rightsidebar';
			$storeup_sidebaroption  = get_post_meta( $postid, 'storeup_sidebar_options', true ) ? get_post_meta( $postid, 'storeup_sidebar_options', true ): $storeup_sidebar_layout;

			switch ( $storeup_sidebaroption ) {
				case  'rightsidebar':
					$storeup_sidebaroption = 'rightsidebar';
					break;
				case  'leftsidebar':
					$storeup_sidebaroption = 'leftsidebar';
					break;
				case  'fullwidth':
					$storeup_sidebaroption = 'fullwidth';
					break;

				default:
					$storeup_sidebaroption = $storeup_sidebaroption;
			}

			if ( is_archive() || is_search() || is_tax( 'gallery_category' ) ) {
				$storeup_sidebaroption = $storeup_sidebar_layout;
			}

			if ( is_404() ) {
				$storeup_sidebaroption = 'fullwidth';
			}

			return $storeup_sidebaroption;
		}

		/***
		 * P O S T   L I N K   T Y P E
		 *--------------------------------------------------------
		 * storeup_post_link_to - generates URL based on link type
		 * @param - string link_type - Type of link
		 * @return - string URL
		 *
		 */
		function storeup_post_link_to( $storeup_link_type ) {

			global $post;

			//use switch to generate URL based on link type
			switch ( $storeup_link_type ) {
				case 'linkpage':
						return get_page_link( get_post_meta( $post->ID, 'storeup_linkpage', true ) );
						break;
				case 'linktocategory':
						return get_category_link( get_post_meta( $post->ID, 'storeup_linktocategory', true ) );
						break;
				case 'linktopost':
						return get_permalink( get_post_meta( $post->ID, 'storeup_linktopost', true ) );
						break;
				case 'linkmanually':
						return esc_url( get_post_meta( $post->ID, 'storeup_linkmanually', true ) );
						break;
				case 'nolink':
						return 'nolink';
						break;
			}
		}

		/**
		 * P O S T   A T T A C H M E N T S
		 *--------------------------------------------------------
		 * storeup_get_post_attachments - displays post attachements
		 * @param - int post_id - Post ID
		 * @param - string size - thumbnail, medium, large or full
		 * @param - string attributes - thumbnail, medium, large or full
		 * @param - int width - width to which image has be revised to
		 * @param - int height - height to which image has be revised to
		 * @return - string Post Attachments
		 */

		function storeup_get_post_attachments( $postid = 0, $size = 'thumbnail', $attributes = '', $width, $height, $postlinkurl ) {

			global $post;

			//get the postid
			if ( $postid < 1 ) { $postid = get_the_ID(); }

			//variables
			$rel = $out = '';

			// get the attachments (images)
			$storeup_images = get_children( array(
				'post_parent'    => $postid,
				'post_type'      => 'attachment',
				'order'          => 'DESC',
				'numberposts'    => 0,
				'post_mime_type' => 'image',
			) );

			//if images exists	, define/determine the relation for lightbox
			if ( count( $storeup_images ) > 1 ) {
				$rel = '"group' . $postid . '"';
			} else {
				$rel = '""';
			}
			$rel = ' rel=' . $rel;

			//if images exists, loop through and prepare the output
			if ( $storeup_images ) {
				$out .= '<div class="flexslider">';
				$out .= '<ul class="slides">';
				// loop through
				foreach ( $storeup_images as $image ) {
					$storeup_full_attachment = wp_get_attachment_image_src( $image->ID, 'full' );

					if ( ! empty( $image -> ID ) ) {
						$alt = get_the_title( $image->ID );
					}
					$out .= '<li>';
					$out .= storeup_img_resize( '',$storeup_full_attachment['0'], $width, $height,'',$alt );
					$out .= '</li>';
				} //loop ends
				$out .= '</ul>';
				$out .= '</div><div class="clear"></div>';
			} else { //if images does not exists
				$alt = '';
				$storeup_post_thumbnail_id  = get_post_thumbnail_id( $postid );
				$storeup_full_attachment 	= wp_get_attachment_image_src( $storeup_post_thumbnail_id, 'full' );

				if ( ! empty( $storeup_post_thumbnail_id ) ) {
					$alt = get_the_title( $storeup_post_thumbnail_id );
				}
				$out .= '<figure><a href="' . esc_url( $postlinkurl ) . '">';
				$out .= storeup_img_resize( '',$storeup_full_attachment['0'],$width,$height,'imageborder',$alt );
				$out .= '</a></figure>';
			}// if images exists

			return $out;
		}

		// S U B H E A D E R
		//--------------------------------------------------------
		function storeup_subheader( $postid ) {

			global $wp_query, $storeup_kses_array;

			$storeup_sub_desc = $storeup_sub_title   = $storeup_subheader_props = $storeup_sh_css = $storeup_sh_bg_css = $out = '';

			$storeup_sub_option         = get_post_meta( $postid, 'storeup_subheader_teaser_options', true );
			$storeup_page               = get_post( $postid );
			$storeup_pagetitle_styling  = get_post_meta( $postid, 'storeup_sub_styling', true );
			$storeup_sh_bg_properties 	= get_post_meta( $postid,'storeup_subheader_img', true );
			$storeup_sh_breadcrumb      = get_post_meta( $postid, 'storeup_breadcrumb', true );
			$storeup_sh_txt_clr 		= get_post_meta( $postid,'storeup_sh_txtcolor',true );
			$storeup_sh_padding   		= get_post_meta( $postid,'storeup_sh_padding',true );
			$storeup_sh_textcolor_val 	= $storeup_sh_txt_clr ? 'color:' . $storeup_sh_txt_clr . ';':'';
			$storeup_sh_padding_val 	= $storeup_sh_padding ? 'padding:' . $storeup_sh_padding . ';':'';

			// conditional execution of subheader
			if (
				is_page() || // if is page
				is_page_template() || // if is page template
				( is_single() ) ||  // if is single page
				( is_front_page() && $postid != null ) ||  // if is not empty static frontpage
				( is_home() && $postid != null ) // if is not empty static frontpage
				) {
				// subheader background properties
				if ( is_array( $storeup_sh_bg_properties ) && ! empty( $storeup_sh_bg_properties['0']['image'] ) ) {
					$storeup_subheader_props = 'background:url(' . $storeup_sh_bg_properties['0']['image'] . ') ' . $storeup_sh_bg_properties['0']['position'] . ' ' . $storeup_sh_bg_properties['0']['repeat'] . ' ' . $storeup_sh_bg_properties['0']['attachement'] . ' ' . $storeup_sh_bg_properties['0']['color'] . ';';
				} elseif ( is_array( $storeup_sh_bg_properties ) && ! empty( $storeup_sh_bg_properties['0']['color'] ) ) {
					$storeup_subheader_props = 'background-color:' . $storeup_sh_bg_properties['0']['color'] . ';';
				} elseif ( ! is_array( $storeup_sh_bg_properties )  && $storeup_sh_bg_properties != '' ) {
					$storeup_subheader_props  = 'background:url(' . $storeup_sh_bg_properties . ');';
				}
				
				$storeup_sh_bg_css = ( $storeup_subheader_props != '' ) ? ' style="' . $storeup_subheader_props . '"' : '';
				$storeup_sh_css = ( $storeup_sh_textcolor_val != '' || $storeup_sh_padding_val != ''  ) ? ' style="' . $storeup_sh_textcolor_val . $storeup_sh_padding_val . '"' : '';

				// Subheader Option
				switch ( $storeup_sub_option ) {
					case 'customtitle':
						$storeup_custom_title = get_post_meta( $postid, 'storeup_page_title', true );
						if ( $storeup_custom_title ) {
							$storeup_sub_title = get_post_meta( $postid, 'storeup_page_title', true );
						}

						$storeup_sub_desc = stripslashes( do_shortcode( get_post_meta( $postid, 'storeup_page_desc', true ) ) );
						break;
					case 'default':
						if ( get_option( 'storeup_teaser' ) == 'default' ) :
							$storeup_sub_title = $storeup_page->post_title;
						elseif ( get_option( 'storeup_teaser' ) == 'disable' ) :
						else :
							$storeup_sub_title = $storeup_page->post_title;
						endif;
						break;
					default:
						if ( get_option( 'storeup_teaser' ) == 'default' ) :
							$storeup_sub_title = $storeup_page->post_title;
						elseif ( get_option( 'storeup_teaser' ) == 'disable' ) :
						else :
							$storeup_sub_title = $storeup_page->post_title;
						endif;
						break;
				}
			}

			// iF IS  is_single
			if ( is_single() ) {
				if ( $storeup_sub_option == 'customtitle' ) {
					$storeup_sub_title = get_post_meta( $postid, 'storeup_page_title', true );
				} else {
					$storeup_sub_title = esc_html__( 'Blog', 'storeup' );
				}
			}
			//
			if (  is_singular( 'slider' )
				|| is_singular( 'testimonialtype' )
				|| is_singular( 'service' )
				|| is_singular( 'location' )
				|| is_singular( 'package' )
				|| is_singular( 'gallery' )
				) {
				if ( $storeup_sub_option == 'customtitle' ) {
					$storeup_sub_title = get_post_meta( $postid, 'storeup_page_title', true );
				} else {
					$storeup_sub_title = $storeup_page->post_title;
				}
			}

			// If is static blog Page
			if ( is_home() ) {
				if ( $storeup_sub_option == 'customtitle' ) {
					$storeup_sub_title = get_post_meta( $postid, 'storeup_page_title', true );
				} else {
					$storeup_sub_title = esc_html__( 'Blog', 'storeup' );
				}
			}
			// Is archive
			if ( is_archive() ) {
				//
				$storeup_sub_title = esc_html__( 'Archives', 'storeup' );
				//
				if ( is_category() ) {

					$storeup_taxonomy_archive_query_obj = $wp_query->get_queried_object();
					$storeup_cat_title = $storeup_taxonomy_archive_query_obj->name; // Taxonomy term name
					$storeup_sub_title = sprintf( esc_html__( 'Category Archives: %s', 'storeup' ), '<span>' . $storeup_cat_title . '</span>' );
				}
				//

				if ( is_tax( 'gallery_category' ) ||  is_tax( 'cities' ) ) {
					$storeup_taxonomy_archive_query_obj = $wp_query->get_queried_object();
					$storeup_cat_title = $storeup_taxonomy_archive_query_obj->name; // Taxonomy term name
					$storeup_sub_title = $storeup_cat_title;
				}

				//
				if ( is_day() ) :
						$storeup_sub_title = sprintf( esc_html__( 'Archive for date: %s', 'storeup' ), '<span>' . get_the_date() . '</span>' );
					elseif ( is_month() ) :
						$storeup_sub_title = sprintf( esc_html__( 'Archive for month: %s', 'storeup' ), '<span>' . get_the_date( 'F Y' ) . '</span>' );
					elseif ( is_year() ) :
						$storeup_sub_title = sprintf( esc_html__( 'Archive for year: %s', 'storeup' ), '<span>' . get_the_date( 'Y' ) . '</span>' );
					else :
				endif;
			}

			// If is Shop page
			if( function_exists('is_shop') ){
				if ( is_shop() ) {
					$storeup_sub_title = sprintf( esc_html__( 'Supplies', 'storeup' ), '<span>' . single_tag_title( '', false ) . '</span>' );
				}
			}
			// If is product page
			if( function_exists('is_product') ){
				if ( is_product()) {
					$storeup_sub_title = sprintf( esc_html__( 'Supplies', 'storeup' ), '<span>' . single_tag_title( '', false ) . '</span>' );
				}
			}
			// If is tag page
			if ( is_tag() ) {
				$storeup_sub_title = sprintf( esc_html__( 'Tag Archives: %s', 'storeup' ), '<span>' . single_tag_title( '', false ) . '</span>' );
			}
			// If is Search
			if ( is_search() ) {
				$storeup_sub_title = esc_html__( 'Search Results : ' . stripslashes( strip_tags( get_search_query() ) ) , 'storeup' );
			}
			// If is author
			if ( is_author() ) {
				$storeup_cur_auth = ( get_query_var( 'author_name' ) ) ? get_user_by( 'slug', get_query_var( 'author_name' ) ) : get_userdata( get_query_var( 'author' ) );
				$storeup_sub_title = sprintf( esc_html__( 'Author Archives: %s', 'storeup' ), $storeup_cur_auth->display_name );
			}
			/**
			 * Subheader content alignment
			 * gets an default case from theme options panel
			 * gets an alignment for specific page
			 */
			if ( $storeup_pagetitle_styling == '' ) {
				$storeup_pagetitle_styling = get_option( 'storeup_subheader_style' ) ? get_option( 'storeup_subheader_style' ) : 'center';
			}
			switch ( $storeup_pagetitle_styling ) {
				case 'left':
							$storeup_subtitle_align = 'sleft';
							break;
				case 'right':
							$storeup_subtitle_align = 'sright';
							break;
				case 'center':
							$storeup_subtitle_align = 'scenter';
							break;
				default :
							$storeup_subtitle_align = 'sleft';
			}
			if ( get_option( 'storeup_teaser' ) != 'disable' ) {

				// If is not disabled from page
				if ( $storeup_sub_option != 'disable' ) {

					// Header style4 style
					$storeup_h4_id 	= $sub_header_txtcolor = '';
					$headerstyle	= get_option( 'storeup_headerstyle' );

					if ( isset( $headerstyle ) && $headerstyle == 'headerstyle4' ) {
						if ( $storeup_sh_textcolor_val != '' ) {
							$sub_header_txtcolor = $storeup_sh_textcolor_val;
						}
						$storeup_h4_id = 'style="' . $sub_header_txtcolor . ' ' . $storeup_sh_padding_val . ' "';
						$storeup_sh_css = '';
					}
					$storeup_sh_text_css = ( $storeup_sh_textcolor_val != '' ) ? ' style="' . $storeup_sh_textcolor_val . '"' : '';

					$out .= '<div id="subheader" ' . $storeup_h4_id . ' class="' . $storeup_subtitle_align . '" ' . $storeup_sh_css . '>';
					if ( ! empty( $storeup_sh_bg_css ) ) {
						if ( $headerstyle == 'headerstyle1' || $headerstyle == 'headerstyle2' ||  $headerstyle == 'headerstyle3' ||  $headerstyle == 'fixedheader' ) {
							$out .= '<div class="subheader_bg_image"></div>';
							if( $storeup_sh_bg_properties['0']['image'] ) {
								$out .= '<div class="subheader_bg_overlay"></div>';
							}
						}
					}
					$out .= '<div class="subheader-inner">';
					$out .= '<div class="subdesc">';
					if ( $storeup_sub_title ) {
						$out .= '<h1 class="page-title" ' . $storeup_sh_text_css . '>' . $storeup_sub_title . '</h1>';
					}
					if ( $storeup_sub_desc ) {
						$out .= '<div class="customtext">' . $storeup_sub_desc . '</div>';
					}
					$out .= '</div>';
					ob_start();
					$out .= $this->storeup_breadcrumb( $postid );
					$out .= ob_get_contents();
					ob_end_clean();
					$out .= '</div>';
					$out .= '</div>';
				}
			}

			$allowed_tags = wp_kses_allowed_html( 'post' );
			echo  wp_kses( $out, $allowed_tags );
		}


		// B R E A D C R U M B S
		//--------------------------------------------------------
		function storeup_breadcrumb( $postid ) {

			$storeup_sh_breadcrumb 	= get_post_meta( $postid, 'storeup_breadcrumb', true );
			$bc_out = '';
			if ( function_exists( 'bcn_display' ) ) {
				if ( is_tag() || is_search() || is_404() || is_author() || is_archive() ) {
					if ( get_option( 'storeup_breadcrumbs' ) != 'on' ) {
						$bc_out .= '<div class="breadcrum-main"><div class="breadcrumb-wrap">';
						$bc_out .= '<div class="breadcrumbs">';
						ob_start();
						$bc_out .= bcn_display();
						$bc_out .= ob_get_contents();
						ob_end_clean();
						$bc_out .= '</div>';
						$bc_out .= '</div></div>';
					}
				} else {
					if ( $storeup_sh_breadcrumb != 'on' and ( get_option( 'storeup_breadcrumbs' ) != 'on') and ! is_front_page() ) {
						$bc_out .= '<div class="breadcrum-main"><div class="breadcrumb-wrap">';
						$bc_out .= '<div class="breadcrumbs">';
						ob_start();
						$bc_out .= bcn_display();
						$bc_out .= ob_get_contents();
						ob_end_clean();
						$bc_out .= '</div>';
						$bc_out .= '</div></div>';
					}
				}
			}
			return $bc_out;
		}


		// A B O U T   A U T H O R
		//--------------------------------------------------------
		function storeup_about_author() { 
			if ( get_the_author_meta( 'description' ) != '' ) {
			?>
				<div id="about-author">
					<div class="author_containter">
						<div class="author-avatar"><?php echo get_avatar( get_the_author_meta( 'email' ), $size = '80', $default = '' ); ?></div>
						<div class="author-description">
						<h4><?php the_author_meta( 'display_name' ); ?></h4>
						<p><?php the_author_meta( 'description' ); ?></p></div>
					</div>
				</div>
				<?php
			}
		}

		// R E L A T E D   P O S T S
		//--------------------------------------------------------
		function storeup_related_posts( $postid ) {

			global $wpdb,$post;

			$storeup_post_tags = wp_get_post_tags( $postid );

			if ( $storeup_post_tags ) {

				$storeup_tag_ids = array();

				foreach ( $storeup_post_tags as $individual_tag ) {
					$storeup_tag_ids[] = $individual_tag->term_id;
				}

				$storeup_post_args = array(
					'tag__in'				=> $storeup_tag_ids,
					'post__not_in'			=> array( $post->ID ),
					'showposts'				=> 4, // Number of related posts that will be shown.
					'ignore_sticky_posts'	=> 1,
				);

				$related_post_found = 'true';
				$storeup_post_query = new wp_query( $storeup_post_args );

				if ( $storeup_post_query->have_posts() ) {
					echo '<div class="related-posts"><div class="fancyheading textleft"><h4><span>' . esc_html__( 'You might also like', 'storeup' ) . '</span></h4></div><ul>';
					while ( $storeup_post_query->have_posts() ) {
						$storeup_post_query->the_post();
						echo '<li>';
						echo '<a href="' . esc_url( get_permalink( $post->ID ) ) . '">' . get_the_title() . '</a> - <span>' . get_the_date() . '</span>';
						echo '</li>';
					}
					echo '</ul>';
					echo '</div>';
				}
			}
			wp_reset_postdata();
		}
	}
	// end class
}

	/**
	* Description Walker Class for Custom Menu
	*/
	//http://code.tutsplus.com/tutorials/understanding-the-walker-class--wp-25401
class Storeup_Custom_Menu_Walker extends Walker_Nav_Menu {

		// columns
		var $columns  = 0;
		var $max_columns = 0;
		// rows
		var $rows   = 1;
		var $arows   = array();
		// mega menu
		var $storeup_megamenu = 0;

	function start_lvl( &$output, $depth = 0, $args = array() ) {

			$indent = str_repeat( "\t", $depth );

		if ( $depth == 0 && $this->iva_megamenu ) {
				 $output .= "\n$indent<div class=\"sf-mega\"><div class=\"sf-mega-wrap\">\n";
		} else {
			$output .= "\n$indent<ul>\n";
		}
	}

	function end_lvl( &$output, $depth = 0, $args = array() ) {
		$indent = str_repeat( "\t", $depth );
		if ( $depth == 0 && $this->iva_megamenu ) {
			$output .= "$indent</div></div>\n";
		} else {
			$output .= "$indent</ul>\n";
		}

		if ( $depth == 0 ) {
			if ( $this->iva_megamenu ) {
				$output = str_replace( '{menu_ul_class}', ' sf-mega-section mmcol-' . $this->max_columns, $output );
				foreach ( $this->arows as $row => $columns ) {
					$output = str_replace( '{menu_li_class_' . $row . '}', 'sf-mega-section mmcol-' . $columns, $output );
				}
				$this->columns		= 0;
				$this->max_columns	= 0;
				$this->arows		= array();
			} else {
					$output = str_replace( '{menu_ul_class}', '', $output );
			}
		}
	}

	function start_el( &$output, $object, $depth = 0, $args = array(), $current_object_id = 0 ) {

			global $wp_query;

			$object_output = $column_class = $li_text_block_class = '';

			$classes = empty( $object->classes ) ? array() : (array) $object->classes;

			$class = array();

		if ( $depth == '0' ) {
			$this->iva_megamenu	= get_post_meta( $object->ID, 'menu-item-iva-megamenu', true );
			if ( $this->iva_megamenu == 'on' ) { $li_text_block_class = 'iva-megamenu  '; }
		}

		if ( $depth == 1 && $this->iva_megamenu ) {

			$this->columns ++;
			$this->arows[ $this->rows ] = $this->columns;

			if ( $this->max_columns < $this->columns ) { $this->max_columns = $this->columns; }

			$attributes  = ! empty( $object->attr_title ) ? ' title="' . esc_attr( $object->attr_title ) . '"' : '';
			$attributes .= ! empty( $object->target )     ? ' target="' . esc_attr( $object->target ) . '"' : '';
			$attributes .= ! empty( $object->xfn )        ? ' rel="' . esc_attr( $object->xfn ) . '"' : '';
			$attributes .= ! empty( $object->url )        ? ' href="' . esc_attr( $object->url ) . '"' : '';

			$prepend = $append = $description = '';

			$description  = ! empty( $object->attr_title ) ? '<span class="msubtitle">' . esc_attr( $object->attr_title ) . '</span>' : '';

			if ( $depth != 0 ) {
				$description = $append = $prepend = '';
			}
			$object_output = $args->before;
			$object_output .= '<a' . $attributes . ' class="col_title">';
			if ( $classes['0'] != '' ) {
				$object_output .= '<i class= "iva_menu_icon fa fa-caret-right ' . $classes['0'] . '"></i>';
			}
			$object_output .= $args->link_before . $prepend . apply_filters( 'the_title', $object->title, $object->ID ) . $append;
			$object_output .= $description . $args->link_after;
			$object_output .= '</a>';
			$object_output .= $args->after;
			$column_class = ' {menu_li_class_' . $this->rows . '}';
		} else {

			$attributes  = ! empty( $object->attr_title ) ? ' title="' . esc_attr( $object->attr_title ) . '"' : '';
			$attributes .= ! empty( $object->target )     ? ' target="' . esc_attr( $object->target ) . '"' : '';
			$attributes .= ! empty( $object->xfn )        ? ' rel="' . esc_attr( $object->xfn ) . '"' : '';
			$attributes .= ! empty( $object->url )        ? ' href="' . esc_attr( $object->url ) . '"' : '';

			$prepend = $append = $description = '';

			$description  = ! empty( $object->attr_title ) ? '<span class="msubtitle">' . esc_attr( $object->attr_title ) . '</span>' : '';

			if ( $depth != 0 ) {
				 $description = $append = $prepend = '';
			}
			$object_output = $args->before;
			$object_output .= '<a ' . $attributes . '>';
			if ( $classes['0'] != '' ) {
				$object_output .= '<i class="iva_menu_icon fa fa-caret-right ' . $classes['0'] . '"></i>';
			}
			$object_output .= $args->link_before . $prepend . apply_filters( 'the_title', $object->title, $object->ID ) . $append;
			$object_output .= $description . $args->link_after;
			$object_output .= '</a>';
			$object_output .= $args->after;
		}

			$indent = ( $depth ) ? str_repeat( "\t", $depth ) : '';
			$class_names = $value = '';
			$class_names = apply_filters( 'nav_menu_css_class', array_filter( $classes ) );

			foreach ( $class_names as $key => $values ) {
				if ( $key != '0' ) {
					$class[] .= $values;
				}
			}
			$class_names = join( ' ', $class );
			$class_names = ' class="' . $li_text_block_class . esc_attr( $class_names ) . $column_class . '"';

			if ( $depth == 1 && $this->iva_megamenu ) {
				$output .= $indent . '<div id="menu-item-' . $object->ID . '"' . $value . $class_names . '>';
			} else {
				$output .= $indent . '<li id="menu-item-' . $object->ID . '"' . $value . $class_names . '>';
			}
			$output .= apply_filters( 'walker_nav_menu_start_el', $object_output, $object, $depth, $args );
	}

	function end_el( &$output, $object, $depth = 0, $args = array() ) {
		$indent = str_repeat( "\t", $depth );
		if ( $depth == 1 && $this->iva_megamenu ) {
		 	$output .= "$indent</div>\n";
		} else {
			$output .= "$indent</li>\n";
		}
	}
}


	/**
	 * Description Walker Class for Mobile Menu
	 */
class Storeup_Mobile_Custom_Menu_Walker extends Walker_Nav_Menu {
	function start_el( &$output, $object, $depth = 0, $args = array(), $current_object_id = 0 ) {

		global $wp_query;

		$indent = ( $depth ) ? str_repeat( "\t", $depth ) : '';

		$class_names = $value = '';

		$classes = empty( $object->classes ) ? array() : (array) $object->classes;
		$class = array();
		$class_names = apply_filters( 'nav_menu_css_class', array_filter( $classes ) );

		foreach ( $class_names as $key => $values ) {
			if ( $key != '0' ) {
				$class[] .= $values;
			}
		}
		$custommneu_class = join( ' ',$class );
		$class_menu = ' class="' . esc_attr( $custommneu_class ) . '"';
		$output .= $indent . '<li id="mobile-menu-item-' . $object->ID . '"' . $value . $class_menu . '>';

		$attributes  = ! empty( $object->attr_title ) ? ' title="' . esc_attr( $object->attr_title ) . '"' : '';
		$attributes .= ! empty( $object->target )     ? ' target="' . esc_attr( $object->target ) . '"' : '';
		$attributes .= ! empty( $object->xfn )        ? ' rel="' . esc_attr( $object->xfn ) . '"' : '';
		$attributes .= ! empty( $object->url )        ? ' href="' . esc_attr( $object->url ) . '"' : '';

		$prepend = $append = '';

		$description  = ! empty( $object->attr_title ) ? '<span class="msubtitle">' . esc_attr( $object->attr_title ) . '</span>' : '';

		if ( $depth != 0 ) {
			 $description = $append = $prepend = '';
		}

		$object_output = $args->before;
		$object_output .= '<a' . $attributes . '>';

		if ( $classes['0'] != '' ) {
			$object_output .= '<i class="iva_menuicon fa ' . $classes['0'] . ' fa-lg"></i>';
		}

		$object_output .= $args->link_before . $prepend . apply_filters( 'the_title', $object->title, $object->ID ) . $append;
		$object_output .= $description . $args->link_after;

		if ( 'primary-menu' == $args->theme_location ) {
			$submenus = 0 == $depth || 1 == $depth ? get_posts( array( 'post_type' => 'nav_menu_item', 'numberposts' => 1, 'meta_query' => array( array( 'key' => '_menu_item_menu_item_parent', 'value' => $object->ID, 'fields' => 'ids' ) ) ) ) : false;
			$object_output .= ! empty( $submenus ) ? ( 0 == $depth ? '<span class="iva-children-indenter"><i class="fa fa fa-angle-down"></i></span>' : '<span class="iva-children-indenter"><i class="fa fa fa-angle-down"></i></span>' ) : '';
		}

		$object_output .= '</a>';
		$object_output .= $args->after;

		$output .= apply_filters( 'walker_nav_menu_start_el', $object_output, $object, $depth, $args );
	}
}
	// W R I T E   G E N E R A T O R
	//--------------------------------------------------------

	/**
	 * function storeup_generator()
	 * link @ http://php.net/manual/en/function.call-user-func-array.php
	 * link @ http://php.net/manual/en/function.func-get-args.php
	 */
function storeup_generator( $function ) {

	global $storeup_generator;

	$storeup_generator 	= new Storeup_Generator_Class;
	$storeup_args 		= array_slice( func_get_args(), 1 );

	return call_user_func_array( array( &$storeup_generator, $function ), $storeup_args );
}

// C U S T O M   C O M M E N T   T E M P L A T E
//--------------------------------------------------------

function storeup_custom_comment( $comment, $args, $depth ) {

	global $post;

	switch ( $comment->comment_type ) :
		case 'pingback' :
		case 'trackback' : ?>
				<li <?php comment_class(); ?> id="comment-<?php comment_ID(); ?>">
				<p><?php esc_html_e( 'Pingback:', 'storeup' ); ?> <?php comment_author_link(); ?> <?php edit_comment_link( esc_html__( 'Edit', 'storeup' ), '<span class="edit-link">', '</span>' ); ?></p>
				<?php
				break;
		default :
			// Proceed with normal comments.
			?>
			<li <?php comment_class(); ?> id="li-comment-<?php comment_ID(); ?>">
			<div id="comment-<?php comment_ID(); ?>" class="comment-body">
				<header class="comment-meta comment-author vcard">
					<?php
						echo get_avatar( $comment, 60 );
						printf( '<cite class="fn">%1$s %2$s</cite>',
							get_comment_author_link(),
							// If current post author is also comment author, make it known visually.
							( $comment->user_id === $post->post_author ) ? '<span> ' . esc_html__( 'Post author', 'storeup' ) . '</span>' : ''
						);
						echo '<div class="comment-metadata">';
						printf( '<a href="%1$s"><time pubdate datetime="%2$s">%3$s</time></a>',
							esc_url( get_comment_link( $comment->comment_ID ) ),
							get_comment_time( 'c' ),
							/* translators: 1: date, 2: time */
							sprintf( esc_html__( '%1$s at %2$s', 'storeup' ), get_comment_date(), get_comment_time() )
						);

						edit_comment_link( esc_html__( 'Edit', 'storeup' ), '<span class="edit-link">', '</span>' );
						echo '</div>';
					?>
				</header><!-- .comment-meta -->
				<div class="comment-content">
					<?php if ( '0' == $comment->comment_approved ) : ?>
					<p class="comment-awaiting-moderation"><?php esc_html_e( 'Your comment is awaiting moderation.', 'storeup' ); ?></p>
					<?php endif; ?>
					<?php comment_text(); ?>
					<div class="reply">
						<?php comment_reply_link( array_merge( $args, array( 'reply_text' => esc_html__( 'Reply', 'storeup' ), 'depth' => $depth, 'max_depth' => $args['max_depth'] ) ) ); ?>
					</div><!-- .reply -->
				</div><!-- .comment-content -->
			</div><!-- #comment-## -->
			<?php
			break;
	endswitch; // end comment_type check
}
