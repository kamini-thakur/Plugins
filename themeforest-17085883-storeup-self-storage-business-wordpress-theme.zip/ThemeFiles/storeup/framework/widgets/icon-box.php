<?php
/**
 * Widget API: storeup_Iconbox_Widget class
 *
 * @package WordPress
 * @subpackage Widgets
 * @since 4.5.0
 */
class Storeup_Iconbox_Widget extends WP_Widget {
	private $fontawesome_list_icons = array(
		'fa-home',
		'fa-mobile',
		'fa-envelope',
		'fa-phone',
		'fa-clock-o',
		'fa-fax',
		'fa-hourglass-3',
		'fa-support',
		'fa-question-circle-o',
		'fa-car',
		'fa-wrench',
		'fa-truck',
		'fa-taxi',
		'fa-ambulance',
		'fa-bus',
		'fa-cab',
		'fa-share-alt',
		'fa-share-alt-square',
	);
	public function __construct() {
		$widget_ops = array( 'classname' => 'iconbox', 'description' => esc_html__( 'Icon Box', 'storeup' ) );
		$control_ops = array( 'width' => 400, 'height' => 350 );
		parent::__construct( 'iconbox', STOREUP_THEME_NAME . esc_html__( ' Iconbox', 'storeup' ), $widget_ops, $control_ops );
	}

	public function widget( $args, $instance ) {
		extract( $args );
		/** This filter is documented in wp-includes/widgets/class-wp-widget-pages.php */
		$title = apply_filters( 'widget_title', empty( $instance['title'] ) ? '' : $instance['title'], $instance, $this->id_base );
		$text = ! empty( $instance['text'] ) ? $instance['text'] : '';
		$icon_name = ! empty( $instance['icon_name'] ) ? $instance['icon_name'] : '';
		$icon_color   = ! empty( $instance['icon_color'] ) ? $instance['icon_color'] : '';
		$text_color   = ! empty( $instance['text_color'] ) ? $instance['text_color'] : '';
		$icon_color		= $icon_color 	? 'color:' . $icon_color . ';' : '';
		$text_color		= $text_color 	? 'color:' . $text_color . ';' : '';

		if ( ! empty( $text_color ) ) {
			$textcolorextras = ' style="' . $text_color . '"';
		} else {
			$textcolorextras = '';
		}
		if ( ! empty( $icon_color ) ) {
			$iconcolorextras = ' style="' . $icon_color . '"';
		} else {
			$iconcolorextras = '';
		}
		$out = wp_kses_post( $before_widget );
		if ( $text ) {
			$out .= '<div class="icon-box_w_text">';
			if ( $icon_name ) {
				$out .= '<i class="fa icon-box-w_al fa-fw ' . esc_attr( $icon_name ) . '" ' . $iconcolorextras . '></i>';
			}
			$out .= '<span class="icon-box-w_title" ' . $textcolorextras . '>' . $title . '</span>';
			$out .= '<span class="icon-box-w_desc" ' . $textcolorextras . '>' . $text . '</span>';
			$out .= '</div>'; // icon box text end
		}
		$out .= wp_kses_post( $after_widget );
		echo wp_kses_post( $out );
	}
	/**
	 * Handles updating settings for the current iconbox widget instance.
	 *
	 * @since 2.8.0
	 * @access public
	 *
	 * @param array $new_instance New settings for this instance as input by the user via
	 *                            WP_Widget::form().
	 * @param array $old_instance Old settings for this instance.
	 * @return array Settings to save or bool false to cancel saving.
	 */
	public function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		$instance['title'] = sanitize_text_field( $new_instance['title'] );
		$instance['text'] = $new_instance['text'];
		$instance['icon_name'] = sanitize_text_field( $new_instance['icon_name'] );
		$instance['icon_color'] = sanitize_text_field( $new_instance['icon_color'] );
		$instance['text_color'] = sanitize_text_field( $new_instance['text_color'] );

		return $instance;
	}

	/**
	 * Outputs the Text widget settings form.
	 *
	 * @since 2.8.0
	 * @access public
	 *
	 * @param array $instance Current settings.
	 */
	public function form( $instance ) {
		?>
		<script type="text/javascript">
		jQuery(document).ready(function() {
			jQuery('.storeup-font-icon-name').each(function() {
				jQuery(this).click( function(){
					var w_data_id = jQuery(this).closest('.widget').attr('id');
					var icon_name =jQuery(this).attr('data-icon');
					jQuery('#'+w_data_id+' .icon-input').val(icon_name);
				});
			});
		});
		</script>

		<?php
			$instance = wp_parse_args( (array) $instance, array( 'title' => '', 'text' => '', 'icon_name' => '', 'text_color' => '', 'icon_color' => '' ) );
			$title    = sanitize_text_field( $instance['title'] );
			$text    = $instance['text'];
			$text_color  = sanitize_text_field( $instance['text_color'] );
			$icon_color  = sanitize_text_field( $instance['icon_color'] );
			$icon_name  = sanitize_text_field( $instance['icon_name'] );
		?>
		<p><label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title', 'storeup' ); ?></label>
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" /></p>
		<p><label for="<?php echo esc_attr( $this->get_field_id( 'text' ) ); ?>"><?php esc_html_e( 'Text', 'storeup' ); ?></label>
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'text' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'text' ) ); ?>" type="text" value="<?php echo esc_attr( $text ); ?>" /></p>
		<p><label for="<?php echo esc_attr( $this->get_field_id( 'icon_color' ) ); ?>"><?php esc_html_e( 'Icon color:', 'storeup' ); ?></label>
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'icon_color' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'icon_color' ) ); ?>" type="text" value="<?php echo esc_attr( $icon_color ); ?>" /></p>
		<p><label for="<?php echo esc_attr( $this->get_field_id( 'text_color' ) ); ?>"><?php esc_html_e( 'Text color:', 'storeup' ); ?></label>
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'text_color' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'text_color' ) ); ?>" type="text" value="<?php echo esc_attr( $text_color ); ?>" /></p>
		<p><label for="<?php echo esc_attr( $this->get_field_id( 'icon_name' ) ); ?>"><?php esc_html_e( 'Select Icon:', 'storeup' ); ?></label>
		<input class="widefat icon-input" id="<?php echo esc_attr( $this->get_field_id( 'icon_name' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'icon_name' ) ); ?>" type="text" value="<?php echo esc_attr( $icon_name ); ?>" /></p>
		<?php foreach ( $this->fontawesome_list_icons as $icon ) : ?>
		<span class="font-icon-name storeup-font-icon-name"  data-icon="<?php echo esc_attr( $icon ); ?>"><i class="fa fa-fw fa-lg <?php echo esc_attr( $icon ); ?>"></i></span>
		<?php endforeach; ?>
		<?php
	}
}
// Register Widget
function storeup_iconbox_widget() {
	register_widget( 'Storeup_Iconbox_Widget' );
}

/* Add our function to the widgets_init hook. */
add_action( 'widgets_init', 'storeup_iconbox_widget' );
