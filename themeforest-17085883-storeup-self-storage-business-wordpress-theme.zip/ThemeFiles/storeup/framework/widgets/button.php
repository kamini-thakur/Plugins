<?php
/**
 * Widget API: storeup_Button_Widget class
 *
 * @package WordPress
 * @subpackage Widgets
 * @since 4.5.0
 */
class Storeup_Button_Widget extends WP_Widget {
	public function __construct() {
		$widget_ops = array( 'classname' => 'Button', 'description' => esc_html__( 'Button', 'storeup' ) );
		$control_ops = array( 'width' => 400, 'height' => 350 );
		parent::__construct( 'button', STOREUP_THEME_NAME . esc_html__( ' Button', 'storeup' ), $widget_ops, $control_ops );
	}

	public function widget( $args, $instance ) {
		extract( $args );

		/** This filter is documented in wp-includes/widgets/class-wp-widget-pages.php */
		$text 			= ! empty( $instance['text'] ) ? $instance['text'] : '';
		$button_url 	= ! empty( $instance['button_url'] ) ? $instance['button_url'] : '';
		$newtab 		= ! empty( $instance['new_tab'] ) ? $instance['new_tab'] : '';
		$button_bgcolor = ! empty( $instance['button_bgcolor'] ) ? $instance['button_bgcolor'] : '';
		$text_color   	= ! empty( $instance['text_color'] ) ? $instance['text_color'] : '';
		$text_color		= $text_color ? 'color:' . $text_color . ';' : '';
		$target			= ! empty( $newtab ) ? '_blank' : '_self';
		$buttonbg		= $button_bgcolor ? 'background-color:' . $button_bgcolor . ';' : '';

		if ( ! empty( $text_color ) ) {
			$buttontextcolor = ' style="' . $text_color . '"';
		} else {
			$buttontextcolor = '';
		}
		if ( ! empty( $buttonbg ) ) {
			$buttonbg = ' style="' . $buttonbg . '"';
		} else {
			$buttonbg = '';
		}
		$out = wp_kses_post( $before_widget );
		if ( $text ) {
			$out .= '<div class="button_w" ' . $buttonbg . '>';
			if ( $button_url ) {
				$out .= '<a href="' . esc_url( $button_url ) . '" target="' . $target . '">';
			}
			$out .= '<span class="button-w_text" ' . $buttontextcolor . '>' . $text . '</span>';
			if ( $button_url ) {
				$out .= '</a>';
			}
			$out .= '</div>'; // button_w_text
		}
		$out .= wp_kses_post( $after_widget );
		echo wp_kses_post( $out );
	}
	public function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		$instance['text'] = sanitize_text_field( $new_instance['text'] );
		$instance['button_url'] = sanitize_text_field( $new_instance['button_url'] );
		$instance['button_bgcolor'] = sanitize_text_field( $new_instance['button_bgcolor'] );
		$instance['new_tab'] = ! empty( $new_instance['new_tab'] );
		$instance['text_color'] = sanitize_text_field( $new_instance['text_color'] );

		return $instance;
	}

	public function form( $instance ) {
			$instance = wp_parse_args( (array) $instance, array( 'text' => '', 'button_url' => '', 'text_color' => '', 'button_bgcolor' => '' ) );
			$new_tab  = isset( $instance['new_tab'] ) ? $instance['new_tab'] : 0;
			$text    = sanitize_text_field( $instance['text'] );
			$button_url  = sanitize_text_field( $instance['button_url'] );
			$button_bgcolor  = sanitize_text_field( $instance['button_bgcolor'] );
			$text_color  = sanitize_text_field( $instance['text_color'] );
		?>
		<p><label for="<?php echo esc_attr( $this->get_field_id( 'text' ) ); ?>"><?php esc_html_e( 'Text', 'storeup' ); ?></label>
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'text' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'text' ) ); ?>" type="text" value="<?php echo esc_attr( $text ); ?>" /></p>
		<p><label for="<?php echo esc_attr( $this->get_field_id( 'button_url' ) ); ?>"><?php esc_html_e( 'Button Url:', 'storeup' ); ?></label>
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'button_url' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'button_url' ) ); ?>" type="text" value="<?php echo esc_attr( $button_url ); ?>" /></p>
		<p><label for="<?php echo esc_attr( $this->get_field_id( 'button_bgcolor' ) ); ?>"><?php esc_html_e( 'Button Bg Color:', 'storeup' ); ?></label>
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'button_bgcolor' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'button_bgcolor' ) ); ?>" type="text" value="<?php echo esc_attr( $button_bgcolor ); ?>" /></p>
		<p><label for="<?php echo esc_attr( $this->get_field_id( 'text_color' ) ); ?>"><?php esc_html_e( 'Text color:', 'storeup' ); ?></label>
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'text_color' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'text_color' ) ); ?>" type="text" value="<?php echo esc_attr( $text_color ); ?>" /></p>
		<p><input id="<?php echo esc_attr( $this->get_field_id( 'new_tab' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'new_tab' ) ); ?>" type="checkbox"<?php checked( $new_tab ); ?> />&nbsp;<label for="<?php echo esc_attr( $this->get_field_id( 'new_tab' ) ); ?>"><?php esc_html_e( ' Open Link in New Tab', 'storeup' );?></label></p>
		<?php
	}
}
// Register Widget
function storeup_button_widget() {
	register_widget( 'Storeup_Button_Widget' );
}

/* Add our function to the widgets_init hook. */
add_action( 'widgets_init', 'storeup_button_widget' );
