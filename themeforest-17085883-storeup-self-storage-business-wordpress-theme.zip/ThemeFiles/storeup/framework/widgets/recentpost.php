<?php
/**
 * Plugin Name: Recent Posts Widget
 * Description: A widget used for displaying recent posts.
 * Version: 1.0
 * Author: Fem Khan
 * Author URI: http://www.aivahthemes.com
 *
 */
// Register Widget
function storeup_recent_post_widget() {
	register_widget( 'Storeup_Recent_Post_Widget' );
}
add_action( 'widgets_init', 'storeup_recent_post_widget' );

class Storeup_Recent_Post_Widget extends WP_Widget {

	function __construct() {

		$widget_ops = array( 'classname' => 'widget_postslist', 'description' => esc_html__( 'The most recent posts on your site','storeup' ) );

		parent::__construct( 'recentpost_entries', STOREUP_THEME_NAME . esc_html__( ' - Recent Posts', 'storeup' ), $widget_ops );

		$this->alt_option_name = 'recentpost_entries';
	}

	function widget( $args, $instance ) {

		if ( ! isset( $args['widget_id'] ) ) {
			$args['widget_id'] = $this->id;
		}

		ob_start();

		extract( $args );

		$title = ( ! empty( $instance['title'] ) ) ? $instance['title'] : esc_html__( 'Recent Posts','storeup' );
		/** This filter is documented in wp-includes/widgets/class-wp-widget-pages.php */
		$title = apply_filters( 'widget_title', $title, $instance, $this->id_base );

		if ( empty( $instance['number'] ) || ! $number = absint( $instance['number'] ) ) {
			$number = 10;
		}
		if ( empty( $instance['description_length'] ) || ! $description_length = absint( $instance['description_length'] ) ) {
			$description_length = 40;
		}

		$show_date 		= isset( $instance['show_date'] ) ? $instance['show_date'] : false;
		$imagedisable 	= isset( $instance['recentpost_imagedisable'] ) ? $instance['recentpost_imagedisable'] : false;
		$storeup_description_length = '60';

		$storeup_recent_post_query = new WP_Query( apply_filters( 'widget_posts_args', array(
			'posts_per_page' => $number,
			'no_found_rows' => true,
			'post_status' => 'publish',
			'ignore_sticky_posts' => true,
		) ) );

		if ( $storeup_recent_post_query->have_posts() ) :

			echo wp_kses_post( $before_widget );

			if ( $title ) {
				echo wp_kses_post( $before_title . $title . $after_title );
			}

			echo '<ul>';
			while ( $storeup_recent_post_query->have_posts() ) : $storeup_recent_post_query->the_post();
				echo '<li>';
				echo '<div class="latest-news">';
				if ( 'true' != $imagedisable ) {

					$storeup_post_thumb = get_post_thumbnail_id();

					if ( $storeup_post_thumb ) {
						$post_thumbnail_id = get_post_thumbnail_id(); ?>

						<div class="thumb">
							<a href="<?php echo esc_url( get_permalink() ); ?>" title="<?php echo esc_attr( get_the_title() ); ?>">
							<figure><?php the_post_thumbnail( 'thumbnail', array( 'class' => 'imgborder' ) );?></figure>
							</a>
						</div>
						<?php
					}
				}
				?>
				<div class="pdesc">
				<a href="<?php echo esc_url( get_permalink() ) ?>" title="<?php echo esc_attr( get_the_title() ? get_the_title() : get_the_ID() ); ?>">
				<?php
				if ( get_the_title() ) {
					the_title();
				} else {
					the_ID();
				}?></a>

				<?php if ( 'true' == $show_date ) : ?>
					<div class="w-postmeta"><?php echo get_the_date(); ?></div>
				<?php else : ?>
					<p><?php echo esc_html( wp_html_excerpt( get_the_content(), $storeup_description_length ) ); ?></p>
				<?php endif;//end Description Length ?>
				</div><!-- pdesc -->
				</div>
				</li>
				<?php endwhile; ?>
				</ul>
			<?php echo wp_kses_post( $after_widget ); ?>
			<?php
			// Reset the global $the_post as this query will have stomped on it
			wp_reset_postdata();

		endif;
	}

	function update( $new_instance, $old_instance ) {

		$instance = $old_instance;

		$instance['title'] 				 	 = strip_tags( $new_instance['title'] );
		$instance['number'] 				 = (int) $new_instance['number'];
		$instance['description_length']		 = (int) $new_instance['description_length'];
		$instance['show_date'] 				 = (bool) $new_instance['show_date'];
		$instance['recentpost_imagedisable'] = (bool) $new_instance['recentpost_imagedisable'];

		$alloptions = wp_cache_get( 'alloptions', 'options' );

		if ( isset( $alloptions['recentpost_widgets'] ) ) {
			delete_option( 'recentpost_widgets' );
		}

		return $instance;
	}

	function form( $instance ) {

		$title     				= isset( $instance['title'] ) ? esc_attr( $instance['title'] ) : '';
		$number    				= isset( $instance['number'] ) ? absint( $instance['number'] ) : 5;
		$description_length   	= isset( $instance['description_length'] ) ? absint( $instance['description_length'] ) : 40;
		$show_date 				= isset( $instance['show_date'] ) ? (bool) $instance['show_date'] : false;
		$imagedisable 			= isset( $instance['recentpost_imagedisable'] ) ? (bool) $instance['recentpost_imagedisable'] : false;	?>

		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title:','storeup' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
		</p>

		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'number' ) ); ?>"><?php esc_html_e( 'Number of posts to show:','storeup' ); ?></label>
			<input id="<?php echo esc_attr( $this->get_field_id( 'number' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'number' ) ); ?>" type="text" value="<?php echo esc_attr( $number ); ?>" size="3" />
		</p>

		<p>
			<input class="checkbox" type="checkbox" <?php checked( $show_date ); ?> id="<?php echo esc_attr( $this->get_field_id( 'show_date','storeup' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'show_date' ) ); ?>" />
			<label for="<?php echo esc_attr( $this->get_field_id( 'show_date' ) ); ?>"><?php esc_html_e( 'Display post date?','storeup' ); ?></label>
		</p>

		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'description_length' ) ); ?>"><?php esc_html_e( 'Length of Description to show:','storeup' ); ?></label>
			<input id="<?php echo esc_attr( $this->get_field_id( 'description_length' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'description_length' ) ); ?>" type="text" value="<?php echo esc_attr( $description_length ); ?>" size="3" />
		</p>

		<p>
			<input class="checkbox" type="checkbox" <?php checked( $imagedisable ); ?> id="<?php echo esc_attr( $this->get_field_id( 'recentpost_imagedisable' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'recentpost_imagedisable' ) ); ?>" />
			<label for="<?php echo esc_attr( $this->get_field_id( 'recentpost_imagedisable' ) ); ?>"><?php esc_html_e( 'Disable Post Thumbnail?','storeup' ); ?></label>
		</p>
<?php
	}
}
