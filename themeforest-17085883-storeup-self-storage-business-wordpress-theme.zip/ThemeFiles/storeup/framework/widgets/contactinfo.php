<?php
/**
 * Plugin Name: Contact Info Widget
 * Description: A widget used for displaying Contact Info.
 * Version: 1.0
 * Author: Fem Khan
 * Author URI: http://www.aivahthemes.com
 *
 */
	// Register Widget
function storeup_contactinfo_widget() {
	register_widget( 'Storeup_Contactinfo_Widget' );
}

/* Add our function to the widgets_init hook. */
add_action( 'widgets_init', 'storeup_contactinfo_widget' );

// Define the Widget as an extension of WP_Widget
class Storeup_Contactinfo_Widget extends WP_Widget {

	function __construct() {

		/* Widget settings. */
		$widget_ops = array(
			'classname'		=> 'contactinfo-wg',
			'description'	=> esc_html__( 'Add Contact Info to your widget.', 'storeup' ),
		);

		/* Widget control settings. */
		$control_ops = array(
			'width'		=> 300,
			'height'	=> 350,
			'id_base'	=> 'contactinfo_widgets',
		);

		/* Create the widget. */
		parent::__construct( 'contactinfo_widgets', STOREUP_THEME_NAME . esc_html__( ' - Contact Info', 'storeup' ), $widget_ops, $control_ops );
	}

	// outputs the content of the widget
	function widget( $args, $instance ) {

		extract( $args );

		$title 					= $instance['contactinfo_title'];
		$syscontact_name 		= $instance['syscontact_name'];
		$syscontact_address 	= $instance['syscontact_address'];
		$syscontact_phone 		= $instance['syscontact_phone'];
		$syscontact_email 		= $instance['syscontact_email'];
		$syscontact_websiteurl 	= $instance['syscontact_websiteurl'];
		$show_map 		= isset( $instance['show_map'] ) ? $instance['show_map'] : false;

		echo wp_kses_post($before_widget);

		if( $title ) :
			echo wp_kses_post($before_title.$title.$after_title);
		endif;

		echo '<div class="contactinfo-wrap">';
		if ( $syscontact_name ) {
			echo '<p><strong><span class="details">'.esc_html( $syscontact_name ).'</span></strong></p>';
		}
		if ( $syscontact_address ) {
			echo '<p><span class="icon"><i class="fa fa-map-marker fa-lg"></i></span>';
			echo '<span class="details">'. stripslashes( nl2br( esc_html($syscontact_address) ) ) .'</span>';
			echo '</p>';
		}
		if( $syscontact_phone ){
			echo '<p class="phone"><span class="icon"><i class="fa fa-phone fa-lg"></i></span><span class="details">'.esc_html( $syscontact_phone ).'</span></p>';
		}
		if( $syscontact_email ){
			echo '<p><span class="icon"><i class="fa fa-envelope fa-lg"></i></span><span class="details"><a href="mailto:'.esc_attr($syscontact_email).'">'.esc_html( $syscontact_email ).'</a></span></p>';
		}
		if( $syscontact_websiteurl ){
			echo '<p><span class="icon"><i class="fa fa-link fa-lg"></i></span><span class="details"><a href="'.esc_url( $syscontact_websiteurl ).'">'.esc_url($syscontact_websiteurl).'</a></span></p>';
		}
		if ( 'true' == $show_map ){
			echo '<a href="' . esc_url( "//maps.google.com/maps?saddr=Current+Location&daddr=$syscontact_address" ) . '" target="_blank">'. esc_html__( 'View Map', 'storeup' ).'</a>';
		}
		echo '</div>';
		echo wp_kses_post($after_widget);
	}

	//processes widget options to be saved
	function update( $new_instance, $old_instance ) {

		$instance = $old_instance;

		/* Strip tags for title and name to remove HTML (important for text inputs). */
		$instance['contactinfo_title'] 		= strip_tags( $new_instance['contactinfo_title'] );
		$instance['syscontact_name'] 		= strip_tags( $new_instance['syscontact_name'] );
		$instance['syscontact_address'] 	= strip_tags( $new_instance['syscontact_address'] );
		$instance['syscontact_email'] 		= strip_tags( $new_instance['syscontact_email'] );
		$instance['syscontact_phone'] 		= strip_tags( $new_instance['syscontact_phone'] );
		$instance['syscontact_websiteurl'] 	= strip_tags( $new_instance['syscontact_websiteurl'] );
		$instance['show_map'] 				 = (bool) $new_instance['show_map'];
		
		return $instance;
	}

	// outputs the options form on admin
	function form( $instance ) {
		/* Set up some default widget settings. */
		$instance = wp_parse_args( (array) $instance, array(
			'contactinfo_title' => '',
			'syscontact_name' => '',
			'syscontact_address' => '',
			'syscontact_phone' => '',
			'syscontact_email' => '',
			'syscontact_websiteurl' =>'',
		));

		$title 					= strip_tags( $instance['contactinfo_title'] );
		$syscontact_name 		= strip_tags( $instance['syscontact_name'] );
		$syscontact_address 	= strip_tags( $instance['syscontact_address'] );
		$syscontact_phone 		= strip_tags( $instance['syscontact_phone'] );
		$syscontact_email 		= strip_tags( $instance['syscontact_email'] );
		$syscontact_websiteurl 	= strip_tags( $instance['syscontact_websiteurl'] );
		$show_map 				= isset( $instance['show_map'] ) ? (bool) $instance['show_map'] : false;
		?>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'contactinfo_title' ) ); ?>"><?php esc_html_e( 'Title', 'storeup' ); ?></label>
			<input id="<?php echo esc_attr($this->get_field_id( 'contactinfo_title' )); ?>" name="<?php echo esc_attr( $this->get_field_name( 'contactinfo_title' )); ?>" value="<?php echo esc_attr($title); ?>" type="text" style="width:100%;" />
		</p>
		<p>
			<label for="<?php echo esc_attr($this->get_field_id( 'syscontact_name' )); ?>"><?php esc_html_e('Name', 'storeup'); ?></label>
			<input id="<?php echo esc_attr($this->get_field_id( 'syscontact_name' )); ?>" name="<?php echo esc_attr($this->get_field_name('syscontact_name')); ?>" value="<?php echo esc_attr($syscontact_name); ?>" type="text" style="width:100%;" />
		</p>
		<p>
			<label for="<?php echo esc_attr($this->get_field_id( 'syscontact_address' )); ?>"><?php esc_html_e('Address', 'storeup'); ?></label>
			<textarea  rows="8" style="width:100%" id="<?php echo esc_attr($this->get_field_id( 'syscontact_address' )); ?>" name="<?php echo esc_attr($this->get_field_name('syscontact_address')); ?>"><?php echo esc_attr($syscontact_address); ?></textarea>
		</p>
		<p>
			<label for="<?php echo esc_attr($this->get_field_id( 'syscontact_phone' )); ?>"><?php esc_html_e('Phone', 'storeup'); ?></label>
			<input id="<?php echo esc_attr($this->get_field_id( 'syscontact_phone' )); ?>" name="<?php echo esc_attr($this->get_field_name('syscontact_phone')); ?>" value="<?php echo esc_attr($syscontact_phone); ?>" type="text" style="width:100%;" />
		</p>
		<p>
			<label for="<?php echo esc_attr($this->get_field_id( 'syscontact_email' )); ?>"><?php esc_html_e('Email', 'storeup'); ?></label>
			<input id="<?php echo esc_attr($this->get_field_id( 'syscontact_email' )); ?>" name="<?php echo esc_attr($this->get_field_name('syscontact_email')); ?>" value="<?php echo esc_attr($syscontact_email); ?>" type="text" style="width:100%;" />
		</p>
		<p>
			<label for="<?php echo esc_attr($this->get_field_id( 'syscontact_websiteurl' )); ?>"><?php esc_html_e('Website Url', 'storeup'); ?></label>
			<input id="<?php echo esc_attr($this->get_field_id( 'syscontact_websiteurl' )); ?>" name="<?php echo esc_attr($this->get_field_name('syscontact_websiteurl')); ?>" value="<?php echo esc_attr( $syscontact_websiteurl ); ?>" type="text" style="width:100%;" />
		</p>
		<p>
			<input class="checkbox" type="checkbox" <?php checked( $show_map ); ?> id="<?php echo esc_attr( $this->get_field_id( 'show_map','storeup' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'show_map' ) ); ?>" />
			<label for="<?php echo esc_attr( $this->get_field_id( 'show_map' ) ); ?>"><?php esc_html_e( 'Display Map?','storeup' ); ?></label>
		</p>
	<?php
	}
}
