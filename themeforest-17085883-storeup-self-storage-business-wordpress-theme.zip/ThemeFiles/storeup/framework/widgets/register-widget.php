<?php
/**
 * Register Sidebars
 */
if ( function_exists( 'register_sidebar' ) ) {

	// Default Sidebar
	register_sidebar( array(
		'name'			=> esc_html__( 'Main Sidebar', 'storeup' ),
		'id'			=> 'defaultsidebar',
		'before_title'	=> '<h3 class="widget-title">',
		'after_title'	=> '</h3>',
		'before_widget'	=> '<aside id="%1$s" class="widget %2$s">',
		'after_widget'	=> '<div class="clear"></div></aside>',
	));

	// Header Right Side Area
	register_sidebar(array(
		'name'			=> esc_html__( 'Header Widget Left', 'storeup' ),
		'id'			=> 'header_widget_area_left',
		'description'	=> esc_html__( 'Select only one widget which will appear on your headers', 'storeup' ),
		'before_widget'	=> '<div id="%1$s" class="icon-box_widget left-w %2$s">',
		'after_widget'	=> '</div>',
		'before_title'	=> '<strong>',
		'after_title'	=> '</strong>',
	));
	// Header Right Side Area
	register_sidebar(array(
		'name'			=> esc_html__( 'Header Widget Right', 'storeup' ),
		'id'			=> 'header_widget_area_right',
		'description'	=> esc_html__( 'Select only one widget which will appear on your headers style 2 only', 'storeup' ),
		'before_widget'	=> '<div id="%1$s" class="icon-box_widget right-w %2$s">',
		'after_widget'	=> '</div>',
		'before_title'	=> '<strong>',
		'after_title'	=> '</strong>',
	));
	// Vertical menu footer widget
	register_sidebar(array(
		'name'			=> esc_html__( 'Vertical Menu Footer Widget', 'finserv' ),
		'id'			=> 'vertical-menu-footer',
		'description'	=> esc_html__( 'Select only one widget which will appear on your vertical Menu', 'finserv' ),
		'before_widget'	=> '<aside id="%1$s" class="%2$s">',
		'after_widget'	=> '</aside>',
		'before_title'	=> '<h3 class="widget-title">',
		'after_title'	=> '</h3>',
	));
}
/**
 * Custom Sidebars
 */
if ( function_exists( 'register_sidebar' ) ) {

	/**
	 * TOP Widgets
	 *-----------------------------
	 */
	 // Left Topbar
	register_sidebar(array(
		'name'			=> esc_html__( 'Topbar Left', 'storeup' ),
		'id'			=> 'topbarleft',
		'description'	=> esc_html__( 'Select only one widget which will appear on your Left topbar', 'storeup' ),
		'before_widget'	=> '<aside id="%1$s" class="%2$s">',
		'after_widget'	=> '</aside>',
		'before_title'	=> '<h3 class="widget-title">',
		'after_title'	=> '</h3>',
	));
		// Right Topbar
	register_sidebar(array(
		'name'			=> esc_html__( 'Topbar Right', 'storeup' ),
		'id'			=> 'topbarright',
		'description'	=> esc_html__( 'Select only one widget which will appear on your Right topbar', 'storeup' ),
		'before_widget'	=> '<aside id="%1$s" class="%2$s">',
		'after_widget'	=> '</aside>',
		'before_title'	=> '<h3 class="widget-title">',
		'after_title'	=> '</h3>',
	));


	/**
	 * Footer Copyright  Widgets
	 *-----------------------------
	 */
	 // Copyright Left Content
	register_sidebar(array(
		'name'			=> esc_html__( 'Copyright Left Content', 'storeup' ),
		'id'			=> 'footer_leftcopyright',
		'description'	=> esc_html__( 'Select only one widget which will appear on your Copyright Left Content', 'storeup' ),
		'before_widget'	=> '<aside id="%1$s" class="%2$s">',
		'after_widget'	=> '</aside>',
		'before_title'	=> '<h3 class="widget-title">',
		'after_title'	=> '</h3>',
	));
		// Copyright Right Content
	register_sidebar(array(
		'name'			=> esc_html__( 'Copyright Right Content', 'storeup' ),
		'id'			=> 'footer_rightcopyright',
		'description'	=> esc_html__( 'Select only one widget which will appear on your Copyright Right contemt', 'storeup' ),
		'before_widget'	=> '<aside id="%1$s" class="%2$s">',
		'after_widget'	=> '</aside>',
		'before_title'	=> '<h3 class="widget-title">',
		'after_title'	=> '</h3>',
	));

	// footer-branches
	register_sidebar(array(
		'name'			=> esc_html__( 'Footer Branches', 'storeup' ),
		'id'			=> 'footer-branches',
		'description'	=> esc_html__( 'Select only one widget which will appear after copyright in footer', 'storeup' ),
		'before_widget'	=> '<aside id="%1$s" class="%2$s">',
		'after_widget'	=> '</aside>',
		'before_title'	=> '<h3 class="widget-title">',
		'after_title'	=> '</h3>',
	));
	/**
	 * Sticky Content  Widgets
	 *-----------------------------
	 */
	 // Sticky Contentt
	register_sidebar(array(
		'name'			=> esc_html__( 'Sticky Content', 'storeup' ),
		'id'			=> 'storeup_stickycontent',
		'description'	=> esc_html__( 'Select only one widget which will appear on your sticky bar Content', 'storeup' ),
		'before_widget'	=> '<aside id="%1$s" class="%2$s">',
		'after_widget'	=> '</aside>',
		'before_title'	=> '<h3 class="widget-title">',
		'after_title'	=> '</h3>',
	));


	/**
	 * Footer Column Widgets
	 *-----------------------------
	 */

	 // Footer area top
	register_sidebar(array(
		'name'			=> esc_html__( 'Footer Area Top','storeup' ),
		'id'			=> 'footer_area_top',
		'description'	=> esc_html__( 'Select widget which will appear on your footer top section', 'storeup' ),
		'before_widget'	=> '<aside id="%1$s" class="widget %2$s">',
		'after_widget'	=> '</aside>',
		'before_title'	=> '<h3 class="widget-title">',
		'after_title'	=> '</h3>',
	));
	 // Footer area bottom
	register_sidebar(array(
		'name'			=> esc_html__( 'Footer Area Bottom','storeup' ),
		'id'			=> 'footer_area_bottom',
		'description'	=> esc_html__( 'Select widget which will appear on your footer bottom section', 'storeup' ),
		'before_widget'	=> '<aside id="%1$s" class="widget %2$s">',
		'after_widget'	=> '</aside>',
		'before_title'	=> '<h3 class="widget-title">',
		'after_title'	=> '</h3>',
	));
	register_sidebar(array(
		'name'			=> esc_html__( 'Footer Column1', 'storeup' ),
		'id'			=> 'footercolumn1',
		'description'	=> esc_html__( 'Select widget which will appear on your Footer column1', 'storeup' ),
		'before_widget'	=> '<aside id="%1$s" class="widget %2$s">',
		'after_widget'	=> '</aside>',
		'before_title'	=> '<h3 class="widget-title">',
		'after_title'	=> '</h3>',
	));
	// footer column2
	register_sidebar(array(
		'name'			=> esc_html( 'Footer Column2', 'storeup' ),
		'id'			=> 'footercolumn2',
		'description'	=> esc_html__( 'Select only one widget which will appear on your Footer column2', 'storeup' ),
		'before_widget'	=> '<aside id="%1$s" class="widget %2$s">',
		'after_widget'	=> '</aside>',
		'before_title'	=> '<h3 class="widget-title">',
		'after_title'	=> '</h3>',
	));
	// footer column3
	register_sidebar(array(
		'name'			=> esc_html__( 'Footer Column3', 'storeup' ),
		'id'			=> 'footercolumn3',
		'description'	=> esc_html__( 'Select only one widget which will appear on your Footer column3', 'storeup' ),
		'before_widget'	=> '<aside id="%1$s" class="widget %2$s">',
		'after_widget'	=> '</aside>',
		'before_title'	=> '<h3 class="widget-title">',
		'after_title'	=> '</h3>',
	));
	// footer column4
	register_sidebar(array(
		'name'			=> esc_html__( 'Footer Column4','storeup' ),
		'id'			=> 'footercolumn4',
		'description'	=> esc_html__( 'Select only one widget which will appear on your Footer column4', 'storeup' ),
		'before_widget'	=> '<aside id="%1$s" class="widget %2$s">',
		'after_widget'	=> '</aside>',
		'before_title'	=> '<h3 class="widget-title">',
		'after_title'	=> '</h3>',
	));
	// footer column5
	register_sidebar(array(
		'name'			=> esc_html__( 'Footer Column5','storeup' ),
		'id'			=> 'footercolumn5',
		'description'	=> esc_html__( 'Select only one widget which will appear on your Footer column5', 'storeup' ),
		'before_widget'	=> '<aside id="%1$s" class="widget %2$s">',
		'after_widget'	=> '</aside>',
		'before_title'	=> '<h3 class="widget-title">',
		'after_title'	=> '</h3>',
	));
	// footer column6
	register_sidebar(array(
		'name'			=> esc_html__( 'Footer Column6', 'storeup' ),
		'id'			=> 'footercolumn6',
		'description'	=> esc_html__( 'Select only one widget which will appear on your Footer column6', 'storeup' ),
		'before_widget'	=> '<aside id="%1$s" class="widget %2$s">',
		'after_widget'	=> '</aside>',
		'before_title'	=> '<h3 class="widget-title">',
		'after_title'	=> '</h3>',
	));
}

/**
 * Custom Sidebar Widget
 *
 */
if ( function_exists( 'register_sidebar' ) ) {

	$storeup_template_custom_widget = get_option( 'storeup_customsidebar' );

	if ( is_array( $storeup_template_custom_widget ) ) {
		foreach ( $storeup_template_custom_widget as $storeup_page_name ) {
			if ( '' !== $storeup_page_name ) {
				$storeup_page_name = trim( $storeup_page_name );
				register_sidebar(array(
					'name'			=> $storeup_page_name,
					'id'			=> 'sidebar-' . strtolower( preg_replace( '/\s+/', '-', $storeup_page_name ) ),
					'before_widget'	=> '<aside id="%1$s" class="widget %2$s">',
					'after_widget'	=> '</aside>',
					'before_title'	=> '<h3 class="widget-title">',
					'after_title'	=> '</h3>',
				));
			}
		}
	}
}

// Add input fields(priority 5, 3 parameters)
add_action( 'in_widget_form', 'storeup_add_widget_form', 5 , 3 );

// Callback function for options update (priorität 5, 3 parameters)
add_filter( 'widget_update_callback', 'storeup_widget_form_update', 5 , 3 );

// add class names (default priority, one parameter)
add_filter( 'dynamic_sidebar_params', 'storeup_from_params' );

function storeup_add_widget_form( $t, $return, $instance ) {

	$instance = wp_parse_args( (array) $instance, array( 'iva_widget_custom_css' => '' ) );
	$storeup_extracss = strip_tags( $instance['iva_widget_custom_css'] );

	if ( 'iva_business_hrs' !== $t->id_base ) { ?>
		<p><label for="<?php echo esc_attr( $t->get_field_id( 'iva_widget_custom_css' ) ); ?>"><?php esc_html_e( 'Custom Class:', 'storeup' ); ?></label>
		<input id="<?php echo esc_attr( $t->get_field_id( 'iva_widget_custom_css' ) ); ?>" type="text" name="<?php echo esc_attr( $t->get_field_name( 'iva_widget_custom_css' ) ); ?>" value="<?php echo esc_attr( $storeup_extracss ); ?>" style="width:100%;" />
		</p>
		<?php
	}
	$retrun = null;
	return array( $t,$return,$instance );
}

function storeup_widget_form_update( $instance, $new_instance, $old_instance ) {
	$instance['iva_widget_custom_css'] = strip_tags( $new_instance['iva_widget_custom_css'] );

	return $instance;
}

function storeup_from_params( $params ) {

	global $wp_registered_widgets;

	$storeup_widget_id  = $params[0]['widget_id'];
	$storeup_widget_obj = $wp_registered_widgets[ $storeup_widget_id ];
	$storeup_widget_opt = get_option( $storeup_widget_obj['callback'][0]->option_name );
	$storeup_widget_num = $storeup_widget_obj['params'][0]['number'];

	if ( isset( $storeup_widget_opt[ $storeup_widget_num ]['iva_widget_custom_css'] ) ) {
		if ( isset( $storeup_widget_opt[ $storeup_widget_num ]['iva_widget_custom_css'] ) ) {
			$float = $storeup_widget_opt[ $storeup_widget_num ]['iva_widget_custom_css'];
		} else {
			$float = '';
		}
		$params[0]['before_widget'] = preg_replace( '/class="/', 'class="' . $float . ' ', $params[0]['before_widget'] );
	}
	return $params;
}
