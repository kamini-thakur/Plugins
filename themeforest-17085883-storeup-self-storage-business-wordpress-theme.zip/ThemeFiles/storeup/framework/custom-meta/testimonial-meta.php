<?php
/**
 * testimonials meta box
 */
$this->meta_box[] = array(
		'id'		=> 'Testimonial-meta-box',
		'title'		=> esc_html__( 'Testimonial Options', 'storeup' ),
		'page'		=> array( 'testimonialtype' ),
		'context'	=> 'normal',
		'priority'	=> 'core',
		'fields'	=> array(
			/**
			 * email id
			 */
			array(
				'name'	=> esc_html__( 'Email ID', 'storeup' ),
				'desc'	=> esc_html__( 'If you are using gravtar logo then enter the email id here. Email ID will not be displayed on the frontend.', 'storeup' ),
				'id'	=> 'storeup_testimonial_email',
				'std'	=> '',
				'type'	=> 'text',
			),
			/**
			 * company name
			 */
			array(
				'name'	=> esc_html__( 'Company Name', 'storeup' ),
				'desc'	=> esc_html__( 'Enter company Name/individual.', 'storeup' ),
				'id'	=> 'storeup_company_name',
				'std'	=> '',
				'type'	=> 'text',
			),
			/**
			 * website url
			 */
			array(
				'name'	=> esc_html__( 'Website URL', 'storeup' ),
				'desc'	=> esc_html__( 'Type the URL you wish to display. Excluding any protocols (ex:http://) .', 'storeup' ),
				'id'	=> 'storeup_website_url',
				'std'	=> '',
				'type'	=> 'text',
			),
			/**
			 * website name
			 */
			array(
				'desc'	=> esc_html__( 'Enter the website name you wish to display for the website url. If left empty, complete website url will be displayed.', 'storeup' ),
				'name'	=> esc_html__( 'Website Name', 'storeup' ),
				'id'	=> 'storeup_website_name',
				'std'	=> '',
				'type'	=> 'text',
			),
		),
	);
