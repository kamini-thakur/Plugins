<?php
	// S L I D E R   M E T A B O X
	//--------------------------------------------------------
	$this->meta_box[] = array(
		'id'		=> 'slider-meta-box',
		'title'		=> esc_html__( 'Slider Options','storeup' ),
		'page'		=> array( 'slider' ),
		'context'	=> 'normal',
		'priority'	=> 'high',
		'fields'	=> array(
			array(
				'name'	=> esc_html__( 'Link for Slide Item','storeup' ),
				'id'	=> 'storeup_postlinktype_options',
				'desc'	=> esc_html__( 'The url that the slide post is linked to','storeup' ),
				'type'	=> 'select',
				'class'	=> 'select300',
				'std'	=> 'nolink',
				'options' => array(
						'linkpage'		=> esc_html__( 'Link to Page', 'storeup' ),
						'linktocategory' => esc_html__( 'Link to Category', 'storeup' ),
						'linktopost'	=> esc_html__( 'Link to Post', 'storeup' ),
						'linkmanually'	=> esc_html__( 'Link Manually', 'storeup' ),
						'nolink'		=> esc_html__( 'No Link', 'storeup' ),
				),
			),

			array(
					'name'		=> esc_html__( 'Slider Page Link','storeup' ),
					'desc'		=> esc_html__( 'Slider Page Link.','storeup' ),
					'id'		=> 'storeup_linkpage',
					'class' 	=> 'linkoption linkpage select300',
					'options' 	=> $this->storeup_get_vars( 'pages' ),
					'std'		=> '',
					'type'		=> 'select',
			),
			array(
					'name'	=> esc_html__( 'Link Category for Slider','storeup' ),
					'desc'	=> esc_html__( 'Slider Description..','storeup' ),
					'id'	=> 'storeup_linktocategory',
					'class' => 'linkoption linktocategory select300',
					'std'	=> '',
					'options' 	=> $this->storeup_get_vars( 'categories' ),
					'type'	=> 'select',
			),
			array(
					'name'	=> esc_html__( 'Slider Post Link','storeup' ),
					'desc'	=> esc_html__( 'Slider Description..','storeup' ),
					'class' => 'linkoption linktopost select300',
					'id'	=> 'storeup_linktopost',
					'std'	=> '',
					'options' 	=> $this->storeup_get_vars( 'posts' ),
					'type'	=> 'select',
			),
			array(
					'name'	=> esc_html__( 'Slider Link','storeup' ),
					'desc'	=> esc_html__( 'Slider Description..','storeup' ),
					'id'	=> 'storeup_linkmanually',
					'class' => 'linkoption linkmanually',
					'std'	=> '',
					'type'	=> 'text',
			),
	
			array(
					'name'	=> esc_html__( 'Slider Caption','storeup' ),
					'desc'	=> esc_html__( 'Slider Caption not more than 100 characters','storeup' ),
					'id'	=> 'storeup_slider_desc',
					'class' => '',
					'std'	=> '',
					'type'	=> 'default_editor',
			),

			array(
				'name'  	=> esc_html__( 'Slider Caption Alignment','storeup' ),
				'desc'   	=> esc_html__( 'Select Slider caption alignment. Choose between 1, 2 or 3 position layout.','storeup' ),
				'id' 		=> 'storeup_slider_cap_align',
				'std' 		=> 'center',
				'type'   	=> 'layout',
				'options'   => array(
					'left'   => STOREUP_FRAMEWORK_URI . 'admin/images/columns/sh-left.png',
					'center' => STOREUP_FRAMEWORK_URI . 'admin/images/columns/sh-center.png',
					'right'  => STOREUP_FRAMEWORK_URI . 'admin/images/columns/sh-right.png',
				),
			),

			array(
					'name'	=> esc_html__( 'Caption Disable','storeup' ),
					'desc'	=> esc_html__( 'Check this if you wish to disable caption for this slide','storeup' ),
					'id'	=> 'storeup_slider_caption',
					'class' => '',
					'std'	=> '',
					'type'	=> 'checkbox',
			),
		),
	);
