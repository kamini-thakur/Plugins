<?php
//
//--------------------------------------------------------
$storeup_sidebar_widget  = get_option( 'storeup_customsidebar' );
$storeup_pagetitle_align = get_option( 'storeup_subheader_style' ) ? get_option( 'storeup_subheader_style' ) : 'center';
$storeup_sidebar_layout  = get_option( 'storeup_defaultlayout' ) ? get_option( 'storeup_defaultlayout' ) : 'rightsidebar';

$this->meta_box[] = array(
	'id'		=> 'post-meta-box',
	'title'		=> esc_html__( '&nbsp;Post Options','storeup' ),
	'page'		=> array( 'post' ),
	'context'	=> 'normal',
	'priority'	=> 'core',
	'fields'	=> array(

		/**
		 * link
		 */
		array(
			'name' => esc_html__( 'The URL','storeup' ),
			'desc' => esc_html__( 'Insert the URL you wish to link to. Including http://','storeup' ),
			'class' => 'postformatmetabox-link',
			'id' => 'storeup_link_url',
			'std' => '',
			'type' => 'text',
		),
		/**
		 * quote
		 */
		array(
			'name' => esc_html__( 'The Quote', 'storeup' ),
			'desc' => esc_html__( 'Write your blockquote in above textarea.', 'storeup' ),
			'id' => 'storeup_postformat_quote',
			'class'	=> 'postformatmetabox-quote',
			'std' => '',
			'type' => 'textarea',
		),

		/**
		 * status
		 */
		array(
			'name' => esc_html__( 'The Status', 'storeup' ),
			'desc' => esc_html__( 'Write your status in above textarea.', 'storeup' ),
			'id' => 'storeup_status',
			'class'	=> 'postformatmetabox-status',
			'std' => '',
			'type' => 'textarea',
		),
		/**
		 * Layout Mode
		 */
		array(
			'name'		=> esc_html__( 'Layout Mode','storeup' ),
			'desc'		=> esc_html__( 'Check this if you wish to use Boxed mode layout for this page.','storeup' ),
			'id'		=> 'storeup_page_layout',
			'std' 		=> 'off',
			'type'		=> 'checkbox',
		),

		/**
		 * page background
		 */
		array(
		'name'		=> esc_html__( 'Page Background','storeup' ),
		'desc'		=> esc_html__( 'Upload the image for the page background. This will apply only if the layout is selected as boxed in options panel','storeup' ),
		'id'		=> 'storeup_page_bg_prop',
		'class'		=> 'storeup_page_bg',
		'std'		=> '',
		'type'		=> 'background',
		'options'	=> array(
						'image'		=> '',
						'color'		=> '',
						'repeat' 	=> 'repeat',
						'position'	=> 'center top',
						'attachment' => 'scroll',
			),
		),
		
		/**
		 * subheader options
		 */
		array(
			'name'		=> esc_html__( 'Subheader Options','storeup' ),
			'desc'		=> esc_html__( 'Select the subheader type you wish to display.', 'storeup' ),
			'id'		=> 'storeup_subheader_teaser_options',
			'std'		=> '',
			'type'		=> 'select',
			'class'		=> 'select300',
			'options'	=> array(
						'default'		=> esc_html__( 'Default ( Options Panel )', 'storeup' ),
						'customtitle'	=> esc_html__( 'Custom', 'storeup' ),
						'disable'		=> esc_html__( 'Disable', 'storeup' ),
					),
		),

		/**
		 * subheader content alignment
		 */
		array(
			'name'  	=> esc_html__( 'Subheader Alignment','storeup' ),
			'desc'   	=> esc_html__( 'Select subheader content alignment. Choose between 1, 2 or 3 position layout.', 'storeup' ),
			'id' 		=> 'storeup_sub_styling',
			'std' 		=> $storeup_pagetitle_align,
			'class'		=> 'sub_teaser_option customtitle default',
			'type'   	=> 'layout',
			'options'  	=> array(
				'left'   => STOREUP_FRAMEWORK_URI . 'admin/images/columns/sh-left.png',
				'center' => STOREUP_FRAMEWORK_URI . 'admin/images/columns/sh-center.png',
				'right'  => STOREUP_FRAMEWORK_URI . 'admin/images/columns/sh-right.png',
			),
		),

		/**
		 * subheader custom title
		 */
		array(
			'name'		=> esc_html__( 'Subheader Custom Title', 'storeup' ),
			'desc'		=> esc_html__( 'Type the custom text you wish to display in the subheader of this page/post. If you wish to use bold text then use strong element example &lt;strong&gt;bold text &lt;/strong&gt;', 'storeup' ),
			'id'		=> 'storeup_page_title',
			'class'		=> 'sub_teaser_option customtitle',
			'std'		=> '',
			'type'		=> 'text',
		),

		/**
		 * subheader custom text
		 */
		array(
			'name'		=> esc_html__( 'Subheader Custom Text', 'storeup' ),
			'desc'		=> esc_html__( 'Type the custom text you wish to display in the subheader of this page/post. If you wish to use bold text then use strong element example &lt;strong&gt;bold text &lt;/strong&gt;', 'storeup' ),
			'id'		=> 'storeup_page_desc',
			'class'		=> 'sub_teaser_option customtitle',
			'std'		=> '',
			'type'		=> 'textarea',
		),
		/**
		 * subheader background
		 */
		array(
			'name'		=> esc_html__( 'Subheader Background', 'storeup' ),
			'desc'		=> esc_html__( 'Upload Subheader Image and its properties', 'storeup' ),
			'id'		=> 'storeup_subheader_img',
			'type'		=> 'background',
			'class'		=> 'sub_teaser_option customtitle default',
			'std' 		=> '',
			'options'	=> array(
						'image'		=> '',
						'color'		=> '',
						'repeat' 	=> '',
						'position'	=> '',
						'attachment' => '',
			),
		),
		/**
		 * subheader text color
		 */
		array(
			'name'		=> esc_html__( 'Subheader Text Color', 'storeup' ),
			'desc'		=> esc_html__( 'Select the color for the content in the subheader', 'storeup' ),
			'id'		=> 'storeup_sh_txtcolor',
			'std'		=> '',
			'type'		=> 'color',
		),
		/**
		 * subheader padding
		 */
		array(
			'name'		=> esc_html__( 'Subheader Padding', 'storeup' ),
			'desc'		=> esc_html__( 'Enter the padding for the subheader area. Padding should be in the following format - 20px 0 20px 0 - directions are Top Right Bottom Left.', 'storeup' ),
			'id'		=> 'storeup_sh_padding',
			'std'		=> '',
			'type'		=> 'text',
		),
		/**
		 * sidebar position
		 */
		array(
			'name'		=> esc_html__( 'Sidebar Position', 'storeup' ),
			'desc'		=> esc_html__( 'Select the sidebar position you wish to use for this page, Left Sidebar or Right Sidebar or Full Width.', 'storeup' ),
			'id'		=> 'storeup_sidebar_options',
			'std'		=> $storeup_sidebar_layout,
			'type'		=> 'layout',
			'options'	=> array(
					'rightsidebar'	=> STOREUP_FRAMEWORK_URI . 'admin/images/columns/rightsidebar.png',
					'leftsidebar'	=> STOREUP_FRAMEWORK_URI . 'admin/images/columns/leftsidebar.png',
					'fullwidth'		=> STOREUP_FRAMEWORK_URI . 'admin/images/columns/fullwidth.png',
				),
		),
		/**
		 * custom sidebar
		 */
		array(
			'name'		=> esc_html__( 'Custom Sidebar', 'storeup' ),
			'desc' 		=> esc_html__( 'Select the Sidebar you wish to assign for this page.', 'storeup' ),
			'id' 		=> 'storeup_custom_widget',
			'type' 		=> 'customselect',
			'class'		=> 'select300',
			'std' 		=> '',
			'options'	=> $storeup_sidebar_widget,
		),
		/**
		 * breadcrumb
		 */
		array(
			'name'		=> esc_html__( 'Breadcrumb', 'storeup' ),
			'desc'		=> esc_html__( 'Check this if you wish to disable the breadcrumb for this page.', 'storeup' ),
			'id'		=> 'storeup_breadcrumb',
			'std' 		=> 'off',
			'type'		=> 'checkbox',
		),
	),
);
