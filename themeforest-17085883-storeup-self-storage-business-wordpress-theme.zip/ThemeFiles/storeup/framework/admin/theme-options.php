<?php
add_action( 'init', 'storeup_theme_options' );
// Get theme version from style.css
if ( ! function_exists( 'storeup_theme_options' ) ) {

	$storeup_options = array();

	function storeup_theme_options() {

		global $storeup_options, $storeup_theme_ob ;

		// More Options
		$uploads_arr 		= wp_upload_dir();
		$all_uploads_path 	= $uploads_arr['path'];
		$all_uploads 		= get_option( 'storeup_uploads' );

		$storeup_colors = array();
		if ( is_dir( STOREUP_THEME_DIR . '/colors/' ) ) {
			if ( $style_dirs = opendir( STOREUP_THEME_DIR . '/colors/' ) ) {
				while ( ( $color = readdir( $style_dirs ) ) !== false ) {
					if ( stristr( $color, '.css' ) !== false ) {
						$storeup_colors[ $color ] = $color;
					}
				}
			}
		}
		$storeup_colors_select = $storeup_colors;
		array_unshift( $storeup_colors_select,'Default Color' );

			$options_array_allowed_html = array(
				'a' 	 => array( 'href' => array(), 'title' => array() ),
				'em'	 => array(),
				'i' 	 => array(),
				'strong' => array(),
				'span'	 => array(),
				'small'  => array(),
				'br' 	 => array(),
			);
			$storeup_fontface = array(
				' ' 									=> esc_html__( 'Select a font', 'storeup' ),
				'Arial'									=> esc_html__( 'Arial', 'storeup' ),
				'Verdana'								=> esc_html__( 'Verdana', 'storeup' ),
				'Tahoma'								=> esc_html__( 'Tahoma', 'storeup' ),
				'Sans-serif'							=> esc_html__( 'Sans-serif', 'storeup' ),
				'Lucida Grande'							=> esc_html__( 'Lucida Grande', 'storeup' ),
				'Georgia, Serif'						=> esc_html__( 'Georgia', 'storeup' ),
				'Trebuchet MS, Tahoma, Sans-serif'		=> esc_html__( 'Trebuchet', 'storeup' ),
				'Times New Roman, Geneva, Sans-serif'	=> esc_html__( 'Times New Roman', 'storeup' ),
				'Palatino, Palatino Linotyp, Serif'		=> esc_html__( 'Palatino', 'storeup' ),
				'Helvetica Neue, Helvetica, sans-serif'	=> esc_html__( 'Helvetica', 'storeup' ),
			);

			/**
			* General Settings
			*/
			$storeup_options[] = array(
				'name' => esc_html__( 'General', 'storeup' ),
				'icon' => 'fa-cog',
				'type' => 'heading',
			);

			$storeup_options[] = array(
								'name'	=> esc_html__( 'Custom Logo', 'storeup' ),
								'desc'	=> esc_html__( 'Select the Logo style you wish to use title or image.', 'storeup' ),
								'id'	=> 'storeup_logo',
								'std'	=> 'title',
								'class' => 'select300',
								'options' => array(
									'title' => esc_html__( 'Title', 'storeup' ),
									'logo' => esc_html__( 'Logo', 'storeup' ),
								),
								'type'	=> 'select',
							);

			$storeup_options[] = array(
								'name'	=> esc_html__( 'Dark Logo Image', 'storeup' ),
								'desc'	=> esc_html__( 'Upload a dark colored logo for your theme which will be displayed in white background areas, or specify the image url of your online logo. (http://yoursite.com/logo_dark.png)', 'storeup' ),
								'id'	=> 'storeup_header_dark_logo',
								'std'	=> '',
								'class' => 'iva_of logo',
								'type'	=> 'upload',
							);

			$storeup_options[] = array(
								'name'	=> esc_html__( 'Light Logo Image', 'storeup' ),
								'desc'	=> esc_html__( 'Upload a light colored logo for your theme which will be displayed in dark background areas, or specify the image url of your online logo. (http://yoursite.com/logo_light.png)', 'storeup' ),
								'id'	=> 'storeup_header_light_logo',
								'std'	=> '',
								'class' => 'iva_of logo',
								'type'	=> 'upload',
							);

			$storeup_options[] = array(
								'name'	=> esc_html__( 'Admin Login Logo', 'storeup' ),
								'desc'	=> esc_html__( 'Upload a logo for your wordpress admin area which displays only when the login screen appears.', 'storeup' ),
								'id'	=> 'storeup_admin_logo',
								'std'	=> '',
								'class' => 'iva_of logo',
								'type'	=> 'upload',
							);

			$storeup_options[] = array(
								'name'	=> esc_html__( 'Logo Background Color', 'storeup' ),
								'desc'	=> esc_html__( 'Logo Background Color for Header Style 4.', 'storeup' ),
								'id'	=> 'storeup_header_logo_bgcolor',
								'std'	=> '',
								'class' => 'iva_of logo',
								'type'	=> 'color',
							);

			$storeup_options[] = array(
								'name'	=> esc_html__( 'Site Title', 'storeup' ),
								'desc'	=> esc_html__( 'Site Title Color Properties', 'storeup' ),
								'id'	=> 'storeup_site_title',
								'std'	=> array( 'size' => '', 'lineheight' => '', 'style' => '', 'fontvariant' => '' ),
								'class' => 'iva_of title',
								'type'	=> 'typography',
							);

			$storeup_options[] = array(
								'name'	=> esc_html__( 'Site Description', 'storeup' ),
								'desc'	=> esc_html__( 'Site Description Color and properties', 'storeup' ),
								'id'	=> 'storeup_tagline',
								'std'	=> array( 'size' => '', 'lineheight' => '', 'style' => '', 'fontvariant' => '' ),
								'class' => 'iva_of title',
								'type'	=> 'typography',
							);

			$storeup_options[] = array(
								'name'	=> esc_html__( 'Custom Favicon', 'storeup' ),
								'desc'	=> esc_html__( 'Upload a 16px x 16px ICO icon format that will represent your website favicon.', 'storeup' ),
								'id'	=> 'storeup_custom_favicon',
								'std'	=> '',
								'type'	=> 'upload',
							);

			$storeup_options[] = array(
								'name'	=> esc_html__( 'Disable General Preloader', 'storeup' ),
								'desc'	=> esc_html__( 'Check this if you wish to disable general preloader image on front page.', 'storeup' ),
								'id'	=> 'storeup_page_preloader',
								'std'	=> '',
								'type'	=> 'checkbox',
							);
			$storeup_options[] = array(
								'name'  => esc_html__( 'General Preloader Image', 'labora' ),
								'desc'	=> esc_html__( 'Select the General Preloader Image.', 'labora' ),
								'id'	=> 'storeup_page_preloader_image',
								'std' 		=> '',
								'type'  	=> 'images',
								'class'		=> 'svg_loader',
								'options' 	=> array(
										'audio.svg' 			=> STOREUP_THEME_URI . '/images/svg-loaders/audio.svg',
										'rings.svg'  			=> STOREUP_THEME_URI . '/images/svg-loaders/rings.svg',
										'grid.svg'  			=> STOREUP_THEME_URI . '/images/svg-loaders/grid.svg',
										'hearts.svg'  			=> STOREUP_THEME_URI . '/images/svg-loaders/hearts.svg',
										'oval.svg'  			=> STOREUP_THEME_URI . '/images/svg-loaders/oval.svg',
										'three-dots.svg'  		=> STOREUP_THEME_URI . '/images/svg-loaders/three-dots.svg',
										'spinning-circles.svg'  => STOREUP_THEME_URI . '/images/svg-loaders/spinning-circles.svg',
										'puff.svg'  			=> STOREUP_THEME_URI . '/images/svg-loaders/puff.svg',
										'circles.svg'  			=> STOREUP_THEME_URI . '/images/svg-loaders/circles.svg',
										'tail-spin.svg'  		=> STOREUP_THEME_URI . '/images/svg-loaders/tail-spin.svg',
										'bars.svg'  			=> STOREUP_THEME_URI . '/images/svg-loaders/bars.svg',
										'ball-triangle.svg'  	=> STOREUP_THEME_URI . '/images/svg-loaders/ball-triangle.svg',
									),
									);
			$storeup_options[] = array(
								'name'	=> esc_html__( 'General Preloader Background Color', 'labora' ),
								'desc'	=> esc_html__( 'Preloader Background Color set to default with theme if you choose color from here it will change Preloader Background color.', 'labora' ),
								'id'	=> 'storeup_page_preloader_bgcolor',
								'std'	=> '',
								'type'	=> 'color',
								);
			$storeup_options[] = array(
								'name' 	=> esc_html__( 'Subheader Content Alignment', 'storeup' ),
								'desc'	=> esc_html__( 'Select subheader content alignment. Choose between 1, 2 or 3 position layout.', 'storeup' ),
								'id'	=> 'storeup_subheader_style',
								'std'	=> 'left',
								'type'  	=> 'images',
								'options' 	=> array(
									   'left'   => STOREUP_FRAMEWORK_URI . 'admin/images/columns/sh-left.png',
									   'center' => STOREUP_FRAMEWORK_URI . 'admin/images/columns/sh-center.png',
									   'right'  => STOREUP_FRAMEWORK_URI . 'admin/images/columns/sh-right.png',
								   ),
								);
			$storeup_options[] = array(
								'name'	=> esc_html__( 'Subheader Teaser', 'storeup' ),
								'desc'	=> esc_html__( 'Teaser call out for the subheader section of the theme.', 'storeup' ),
								'id'	=> 'storeup_teaser',
								'std'	=> 'default',
								'class' => 'select300',
								'options' => array(
											'default'	=> esc_html__( 'Default (post title)', 'storeup' ),
											'disable'	=> esc_html__( 'Disable Subheader', 'storeup' ),
										),
								'type'	=> 'select',
								);
			$storeup_options[] = array(
								'name'	=> esc_html__( 'Breadcrumbs', 'storeup' ),
								'desc'	=> esc_html__( 'Check this if you wish to disable the breadcrumbs for the theme which appears in the subheader. If you wish to disable the breadcrumb for a specific page then go to edit page and check from page options.', 'storeup' ),
								'id'  	=> 'storeup_breadcrumbs',
								'std' 	=> 'true',
								'type' 	=> 'checkbox',
								);

			$storeup_options[] = array(
								'name'	=> esc_html__( 'DatePicker Format', 'storeup' ),
								'desc'	=> esc_html__( 'This format is used only for jQuery DatePicker whick appears in Schedule Day Calender', 'storeup' ),
								'id'	=> 'storeup_date_format',
								'std'	=> '',
								'type'	=> 'select',
								'class'	=> 'select300',
								'options' => array(
											'Y/m/d'  => date( 'Y/m/d' ),
											'm/d/Y'  => date( 'm/d/Y' ),
											'd-m-Y'  => date( 'd-m-Y' ),
							 	),
			);
			$storeup_options[] = array(
									'name'	=> esc_html__( 'Google API key', 'storeup' ),
									'desc'	=> esc_html__( 'Enter the google api key', 'storeup' ),
									'id'	=> 'storeup_google_api_key',
									'std'	=> '',
									'type'	=> 'text',
									'inputsize' => '',
								);

			// HEADER STYLE #########################################################################################
			//---------------------------------------------------------------------------------------------------
			$storeup_options[] = array( 'name' => esc_html__( 'Headers', 'storeup' ), 'icon' => 'fa-header', 'type' => 'heading' );
			//---------------------------------------------------------------------------------------------------

			$storeup_options[] = array(
								'name'	=> esc_html__( 'Header Style', 'storeup' ),
								'desc'	=> esc_html__( 'Select the style you wish to choose for the Header.', 'storeup' ),
								'id'	=> 'storeup_headerstyle',
								'std'	=> 'headerstyle1',
								'class' => 'select300',
								'options' => array(
									'' => esc_html__( 'Choose Header Style', 'storeup' ),
									'headerstyle1' => esc_html__( 'Header Style1', 'storeup' ),
									'headerstyle2' => esc_html__( 'Header Style2', 'storeup' ),
									'headerstyle3' => esc_html__( 'Header Style3', 'storeup' ),
									'headerstyle4' => esc_html__( 'Header Style4', 'storeup' ),
									'headerstyle5' => esc_html__( 'Header Style5', 'storeup' ),
									'fixedheader'  => esc_html__( 'Fixed Header', 'storeup' ),
									'verticalleftmenu'  => esc_html__( 'Vertical Left Header', 'storeup' ),
								),
								'type'	=> 'select',
							);


			$storeup_options[] = array(
								'name'	=> esc_html__( 'Fixed Nav', 'storeup' ),
								'desc'	=> esc_html__( 'Check this if you wish to enable the Fixed-Nav.', 'storeup' ),
								'class' => 'iva_of_headerstyle headerstyle3',
								'id'	=> 'storeup_hs3_fixednav',
								'std'	=> '',
								'type'	=> 'checkbox',
							);


		    $storeup_options[] = array(
							'name'	=> esc_html__( 'Header Background Properties', 'storeup' ),
							'desc'	=> esc_html__( 'Select the Background Image for Header and assign its Properties according to your requirements.', 'storeup' ),
							'id'	=> 'storeup_headerproperties',
							'class' => 'iva_of_headerstyle headerstyle1 headerstyle2 headerstyle3 headerstyle4 fixedheader',
							'std'	=> array(
											'image'		=> '',
											'color'		=> '',
											'style' 	=> '',
											'position'	=> '',
											'attachment' => '',
										),
							'type'	=> 'background',
						);

		     $storeup_options[] = array(
							'name'	=> esc_html__( 'Sociable Icons', 'storeup' ),
							'desc'	=> esc_html__( 'Check this if you wish to disable the Sociable Icons form Header Style4.', 'storeup' ),
							'id'	=> 'storeup_disable_sociables',
							'class' => 'iva_of_headerstyle headerstyle4',
							'std'	=> '',
							'type'	=> 'checkbox',
						);

				$storeup_options[] = array(
									'name'	=> esc_html__( 'Sociable Icons Color', 'storeup' ),
									'desc'	=> esc_html__( 'Check this if you wish to change the Sociable hover color.', 'storeup' ),
									'id'	=> 'storeup_sociables_color',
									'class' => 'iva_of_headerstyle headerstyle4',
									'std'	=> '',
									'type'	=> 'checkbox',
								);
				$storeup_options[] = array(
									'name'	=> esc_html__( 'Topbar Background Color', 'storeup' ),
									'desc'	=> esc_html__( 'This will apply the background color to the topbar.', 'storeup' ),
									'id'	=> 'storeup_topbar_bgcolor',
									'std'	=> '',
									'type'	=> 'color',
								);

				$storeup_options[] = array(
										'name'	=> esc_html__( 'Topbar Text Color', 'storeup' ),
										'desc'	=> esc_html__( 'This will apply text color to the topbar', 'storeup' ),
										'id'	=> 'storeup_topbar_text',
										'std'	=> '',
										'type'	=> 'color',
									);

				$storeup_options[] = array(
										'name'	=> esc_html__( 'Topbar Link Color', 'storeup' ),
										'desc'	=> esc_html__( 'This will apply link color in the topbar.', 'storeup' ),
										'id'	=> 'storeup_topbar_link',
										'std'	=> '',
										'type'	=> 'color',
									);

				$storeup_options[] = array(
									'name'	=> esc_html__( 'Top Bar', 'storeup' ),
									'desc'	=> esc_html__( 'Check this if you wish to disable the Top Bar.', 'storeup' ),
									'id'	=> 'storeup_topbar',
									'std'	=> '',
									'type'	=> 'checkbox',
								);


				// COLORS ###########################################################################################
				//---------------------------------------------------------------------------------------------------
				$storeup_options[] = array( 'name' => esc_html__( 'Styling', 'storeup' ), 'icon' => 'fa-paint-brush', 'type' => 'heading' );
				//---------------------------------------------------------------------------------------------------

				//---------------------------------------------------------------------------------------------------
				$storeup_options[] = array( 'name' => esc_html__( 'General Elements', 'storeup' ), 'type' => 'subnav' );
				//---------------------------------------------------------------------------------------------------

				$storeup_options[] = array(
									'name' 		=> esc_html__( 'Layout Option', 'storeup' ),
									'desc'		=> esc_html__( 'Select the layout option BOXED/STRETCHED which you wish to choose for the theme.', 'storeup' ),
									'id'		=> 'storeup_layoutoption',
									'std' 		=> 'stretched',
									'type'  	=> 'images',
									'class' 	=> 'select300',
									'options' 	=> array(
										'stretched' => STOREUP_FRAMEWORK_URI . 'admin/images/columns/stretched.png',
										'boxed'     => STOREUP_FRAMEWORK_URI . 'admin/images/columns/boxed.png',
									 	),
									);

				$storeup_options[] = array(
									'name' => esc_html__( 'Colors', 'storeup' ),
									'desc'	=> esc_html__( 'Select alternative color scheme for this theme. You can add your custom css skin located in colors folder of the theme.', 'storeup' ),
									'id'	=> 'storeup_custom_skin',
									'std'	=> '',
									'class' => 'select300',
									'options' => $storeup_colors_select,
									'type'	=> 'select',
								);
				$storeup_options[] = array(
									'name'	=> esc_html__( 'Theme Color', 'storeup' ),
									'desc'	=> esc_html__( 'Theme Color set to default with theme. But if you wish to choose color from here it will change all the links and backgrounds used in the theme.', 'storeup' ),
									'id'	=> 'storeup_themecolor',
									'std'	=> '',
									'type'	=> 'color',
								);
				$storeup_options[] = array(
									'name'	=> esc_html__( 'Body Background Properties', 'storeup' ),
									'desc'	=> esc_html__( 'Select the Background Image for Body and assign its Properties according to your requirements.', 'storeup' ),
									'id'	=> 'storeup_bodyproperties',
									'std'	=> array(
													'image'		=> '',
													'color'		=> '',
													'style' 	=> '',
													'position'	=> '',
													'attachment' => '',
												),
									'type'	=> 'background',
								);

				$storeup_options[] = array(
									'name' => esc_html__( 'Background Pattern Images', 'storeup' ),
									'desc' => esc_html__( 'Choose Background Pattern Images for the theme and this works only if the layout is selected as Boxed in Styling Section.', 'storeup' ),
									'id'   => 'storeup_overlayimages',
									'std'  => '',
									'type' => 'images',
									'options' => array(
													''			 => STOREUP_THEME_URI . '/images/patterns/no-pat.png',
													'pat_01.png' => STOREUP_THEME_URI . '/images/patterns/pattern-1-Preview.jpg',
													'pat_02.png' => STOREUP_THEME_URI . '/images/patterns/pattern-2-Preview.jpg',
													'pat_03.png' => STOREUP_THEME_URI . '/images/patterns/pattern-3-Preview.jpg',
													'pat_04.png' => STOREUP_THEME_URI . '/images/patterns/pattern-4-Preview.jpg',
													'pat_05.png' => STOREUP_THEME_URI . '/images/patterns/pattern-5-Preview.jpg',
													'pat_06.png' => STOREUP_THEME_URI . '/images/patterns/pattern-6-Preview.jpg',
													'pat_07.png' => STOREUP_THEME_URI . '/images/patterns/pattern-7-Preview.jpg',
													'pat_08.png' => STOREUP_THEME_URI . '/images/patterns/pattern-8-Preview.jpg',
												),
											);

				$storeup_options[] = array(
									'name'	=> esc_html__( 'Subheader Background Properties', 'storeup' ),
									'desc'	=> esc_html__( 'Select the Background Image for Subheader and assign its Properties according to your requirements.', 'storeup' ),
									'id'	=> 'storeup_subheaderproperties',
									'std'	=> array(
													'image'		=> '',
													'color'		=> '',
													'style' 	=> '',
													'position'	=> '',
													'attachment' => '',
												),
									'type'	=> 'background',
								);



				$storeup_options[] = array(
									'name'	=> esc_html__( 'Subheader', 'storeup' ),
									'desc'	=> esc_html__( 'Subheader Text Color', 'storeup' ),
									'id'	=> 'storeup_subheader_textcolor',
									'std'	=> '',
									'type'	=> 'color',
								);
				$storeup_options[] = array(
									'name'	=> esc_html__( 'Footer Background', 'storeup' ),
									'desc'	=> esc_html__( 'Footer background properties includes the sidebar footer widgets area as well. If you wish to disable footer area you can go to Footer Tab and do that..', 'storeup' ),
									'id'	=> 'storeup_footerbg',
									'std'	=> array(
													'image'		=> '',
													'color'		=> '',
													'style' 	=> '',
													'position'	=> '',
													'attachment' => '',
												),
									'type'	=> 'background',
								);
				$storeup_options[] = array(
									'name'	=> esc_html__( 'Content Area Background Color', 'storeup' ),
									'desc'	=> esc_html__( 'This will apply color to the primary content area of theme.', 'storeup' ),
									'id'	=> 'storeup_wrapbg',
									'std'	=> '',
									'type'	=> 'color',
								);
				$storeup_options[] = array(
									'name'	=> esc_html__( 'Breadcrumb', 'storeup' ),
									'desc'	=> esc_html__( 'Breadcrumb Text Color.', 'storeup' ),
									'id'	=> 'storeup_breadcrumbtext',
									'std'	=> '',
									'type'	=> 'color',
								);

				//---------------------------------------------------------------------------------------------------
				$storeup_options[] = array( 'name' => esc_html__( 'Menu', 'storeup' ), 'type' => 'subnav' );
				//---------------------------------------------------------------------------------------------------

				$storeup_options[] = array(
									'name'  => esc_html__( 'Menu Background', 'storeup' ),
									'desc'  => esc_html__( 'This applies the background color for Header Style2, Header Style3 and Header Style4 .', 'storeup' ),
									'id'    => 'storeup_mmenu_bg',
									'std'   => '',
									'type'  => 'color',
								 );

				$storeup_options[] = array(
									'name'	=> esc_html__( 'Menu Font and Link Color', 'storeup' ),
									'desc'	=> esc_html__( 'Select the Color and Font Properties for Menu Parent Lists.', 'storeup' ),
									'id'	=> 'storeup_mmenu_font',
									'std'	=> array(
													'size' 		  => '',
													'lineheight'  => '',
													'fontvariant' => '',
													'style' 	  => '',
													'color' 	  => '',
												),
									'type'	=> 'typography',
								);

				$storeup_options[] = array(
									'name'  => esc_html__( 'Menu Hover BG', 'storeup' ),
									'desc'  => esc_html__( 'Select the Color for Menu Hover BG.', 'storeup' ),
									'id'    => 'storeup_mmenu_hoverbg',
									'std'   => '',
									'type'  => 'color',
								);

				$storeup_options[] = array(
									'name'	=> esc_html__( 'Menu Hover Text', 'storeup' ),
									'desc'	=> esc_html__( 'Select the Color for Menu Hover Text.', 'storeup' ),
									'id'	=> 'storeup_mmenu_linkhover',
									'std'	=> '',
									'type'	=> 'color',
								);

				$storeup_options[] = array(
									'name'	=> esc_html__( 'Menu Dropdown Background Color', 'storeup' ),
									'desc'	=> esc_html__( 'Select the Color for Dropdown Menu Background Color', 'storeup' ),
									'id'	=> 'storeup_mmenu_dd_bg',
									'std'	=> '',
									'type'	=> 'color',
									);

				$storeup_options[] = array(
					                'name'	=> esc_html__( 'Menu Dropdown Text Color', 'storeup' ),
									'desc'	=> esc_html__( 'Select the Color for Dropdown Menu Text Color', 'storeup' ),
									'id'	=> 'storeup_mmenu_dd_link',
									'std'	=> '',
									'type'	=> 'color',
								);

				$storeup_options[] = array(
									'name'	=> esc_html__( 'Menu Dropdown Text Hover Color', 'storeup' ),
									'desc'	=> esc_html__( 'Select the Color for Dropdown Menu Text Hover Color', 'storeup' ),
									'id'	=> 'storeup_mmenu_dd_linkhover',
									'std'	=> '',
									'type'	=> 'color',
								);

				$storeup_options[] = array(
									'name'	=> esc_html__( 'Menu Dropdown Hover Background Color', 'storeup' ),
									'desc'	=> esc_html__( 'Select the Color for Dropdown Menu Hover Background Color', 'storeup' ),
									'id'	=> 'storeup_mmenu_dd_hoverbg',
									'std'	=> '',
									'type'	=> 'color',
								);

				$storeup_options[] = array(
									'name'	=> esc_html__( 'Menu Active Link Color', 'storeup' ),
									'desc'	=> esc_html__( 'Select the Color for Active Link Color', 'storeup' ),
									'id'	=> 'storeup_mmenu_active_link',
									'std'	=> '',
									'type'	=> 'color',
								);
				//---------------------------------------------------------------------------------------------------
				$storeup_options[] = array( 'name' => esc_html__( 'Link Colors', 'storeup' ), 'type' => 'subnav' );
				//---------------------------------------------------------------------------------------------------

				$storeup_options[] = array(
									'name'	=> esc_html__( 'Link Color', 'storeup' ),
									'desc'	=> esc_html__( 'Select the Color for Theme links', 'storeup' ),
									'id'	=> 'storeup_link',
									'std'	=> '',
									'type'	=> 'color',
								);

				$storeup_options[] = array(
									'name'	=> esc_html__( 'Link Hover Color', 'storeup' ),
									'desc'	=> esc_html__( 'Select the Color for Theme links hover', 'storeup' ),
									'id'	=> 'storeup_linkhover',
									'std'	=> '',
									'type'	=> 'color',
								);

				$storeup_options[] = array(
									'name'	=> esc_html__( 'Subheader Link Color', 'storeup' ),
									'desc'	=> esc_html__( 'Links under subheader section', 'storeup' ),
									'id'	=> 'storeup_subheaderlink',
									'std'	=> '',
									'type'	=> 'color',
								);

				$storeup_options[] = array(
									'name'	=> esc_html__( 'Subheader Link Hover Color', 'storeup' ),
									'desc'	=> esc_html__( 'Links Hover under subheader section', 'storeup' ),
									'id'	=> 'storeup_subheaderlinkhover',
									'std'	=> '',
									'type'	=> 'color',
								);

				$storeup_options[] = array(
									'name'	=> esc_html__( 'Footer Link Color', 'storeup' ),
									'desc'	=> esc_html__( 'Footer containing links under widget or text widget, (link color).', 'storeup' ),
									'id'	=> 'storeup_footerlinkcolor',
									'std'	=> '',
									'type'	=> 'color',
								);

				$storeup_options[] = array(
									'name'	=> esc_html__( 'Footer Link Hover Color', 'storeup' ),
									'desc'	=> esc_html__( 'Footer content containing any links under widget or text widget, (link hover color).', 'storeup' ),
									'id'	=> 'storeup_footerlinkhovercolor',
									'std'	=> '',
									'type'	=> 'color',
								);

				$storeup_options[] = array(
									'name'	=> esc_html__( 'Copyright Link Color', 'storeup' ),
									'desc'	=> esc_html__( 'Copyright content containing any links color. (link color).', 'storeup' ),
									'id'	=> 'storeup_copylinkcolor',
									'std'	=> '',
									'type'	=> 'color',
								);

				//---------------------------------------------------------------------------------------------------
				$storeup_options[] = array( 'name' => esc_html__( 'Typography', 'storeup' ), 'type' => 'subnav' );
				//---------------------------------------------------------------------------------------------------
				//---------------------------------------------------------------------------------------------------
				$storeup_options[] = array(
					'name'	=> esc_html__( 'Google Font', 'storeup' ),
					'desc' => wp_kses( __( 'Select the fonts you wish to use for the website fonts or google webfonts. If you select the headings font it will replace all the heading font family for the whole theme including footer and sidebar widget titles.', 'storeup' ), $options_array_allowed_html ),
					'type' => 'subsection',
				);
				//---------------------------------------------------------------------------------------------------

				$storeup_options[] = array(
										'name' 		=> esc_html__( 'Body Font Family', 'storeup' ),
										'desc' 		=> esc_html__( 'Select a font family for body content', 'storeup' ),
										'id' 		=> 'storeup_bodyfont',
										'class'		=> '',
										'preview' 	=> array(
															'text' => esc_html__( 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s', 'storeup' ),
															'size' => '14px',
														),
										'options' 	=> $storeup_fontface,
										'type' 		=> 'custom_google_fonts',
									);

				$storeup_options[] = array(
										'name' 		=> esc_html__( 'Headings Font Family', 'storeup' ),
										'desc' 		=> esc_html__( 'Select a font family for Headings ( h1, h2, h3, h4, h5, h6 )', 'storeup' ),
										'id' 		=> 'storeup_headingfont',
										'class'		=> '',
										'preview' 	=> array(
															'text' => esc_html__( 'This is font preview text!', 'storeup' ),
															'size' => '36px',
														),
										'options' 	=> $storeup_fontface,
										'type' 		=> 'custom_google_fonts',
									);

				$storeup_options[] = array(
										'name' 		=> esc_html__( 'Menu Font Family', 'storeup' ),
										'desc' 		=> esc_html__( 'Select a font family for Top Navigation Menu', 'storeup' ),
										'id' 		=> 'storeup_mainmenufont',
										'class'		=> '',
										'preview' 	=> array(
															'text' => esc_html__( 'This is font preview text!', 'storeup' ),
															'size' => '26px',
														),
										'options'	=> $storeup_fontface,
										'type' 		=> 'custom_google_fonts',
									);

				$storeup_options[] = array(
										'name' 		=> esc_html__( 'CountDown Font Family', 'storeup' ),
										'desc' 		=> esc_html__( 'Select a font for the CountDown Shortcode', 'storeup' ),
										'id' 		=> 'storeup_countdown_font',
										'class'		=> '',
										'preview' 	=> array(
															'text' => esc_html__( '0123456789 - DAYS - MONTHS - MIN - SECS','storeup' ),
															'size' => '36px',
														),
										'options'	=> $storeup_fontface,
										'type' 		=> 'custom_google_fonts',
									);

				//---------------------------------------------------------------------------------------------------
				$storeup_options[] = array(
					'name'	=> esc_html__( 'Various Font Properties', 'storeup' ),
					'desc' => wp_kses( __( 'Select the front properties like font size, line-height, font-style and font-weight for various elements used in the theme.', 'storeup' ), $options_array_allowed_html ),
					'type' => 'subsection',
				);
				//---------------------------------------------------------------------------------------------------
				$storeup_options[] = array(
									'name'	=> esc_html__( 'Body', 'storeup' ),
									'desc'	=> esc_html__( 'Select the Color and Font Properties for Body Font.', 'storeup' ),
									'id'	=> 'storeup_bodyp',
									'std'	=> array(
													'color'		=> '',
													'size'		=> '',
													'lineheight' => '',
													'style'		=> '',
													'fontvariant' => '',
												),
									'type'	=> 'typography',
								);
				$storeup_options[] = array(
									'name'	=> esc_html__( 'H1', 'storeup' ),
									'desc'	=> esc_html__( 'Select the Color and Font Properties for H1 Heading.', 'storeup' ),
									'id'	=> 'storeup_h1',
									'std'	=> array(
													'color'		=> '',
													'size' 		=> '',
													'lineheight' => '',
													'style' 	=> '',
													'fontvariant' => '',
												),
									'type'	=> 'typography',
								);

				$storeup_options[] = array(
									'name'	=> esc_html__( 'H2', 'storeup' ),
									'desc'	=> esc_html__( 'Select the Color and Font Properties for H2 Heading.', 'storeup' ),
									'id'	=> 'storeup_h2',
									'std'	=> array(
													'color'		=> '',
													'size' 		=> '',
													'lineheight' => '',
													'style'		=> '',
													'fontvariant' => '',
												),
									'type'	=> 'typography',
								);

				$storeup_options[] = array(
									'name'	=> esc_html__( 'H3', 'storeup' ),
									'desc'	=> esc_html__( 'Select the Color and Font Properties for H3 Heading.', 'storeup' ),
									'id'	=> 'storeup_h3',
									'std'	=> array(
													'color'		=> '',
													'size' 		=> '',
													'lineheight' => '',
													'style' 	=> '',
													'fontvariant' => '',
												),
									'type'	=> 'typography',
								);

				$storeup_options[] = array(
									'name'	=> esc_html__( 'H4', 'storeup' ),
									'desc'	=> esc_html__( 'Select the Color and Font Properties for H4 Heading.', 'storeup' ),
									'id'	=> 'storeup_h4',
									'std'	=> array(
													'color'		=> '',
													'size' 		=> '',
													'lineheight' => '',
													'style' 	=> '',
													'fontvariant' => '',
												),
									'type'	=> 'typography',
								);

				$storeup_options[] = array(
									'name'	=> esc_html__( 'H5', 'storeup' ),
									'desc'	=> esc_html__( 'Select the Color and Font Properties for H5 Heading.', 'storeup' ),
									'id'	=> 'storeup_h5',
									'std'	=> array(
													'color'		=> '',
													'size'		=> '',
													'lineheight' => '',
													'style'		=> '',
													'fontvariant' => '',
												),
									'type'	=> 'typography',
								);

				$storeup_options[] = array(
									'name'	=> esc_html__( 'H6', 'storeup' ),
									'desc'	=> esc_html__( 'Select the Color and Font Properties for H6 Heading.', 'storeup' ),
									'id'	=> 'storeup_h6',
									'std'	=> array(
													'color'		=> '',
													'size'		=> '',
													'lineheight' => '',
													'style'		=> '',
													'fontvariant' => '',
												),
									'type'	=> 'typography',
								);

				$storeup_options[] = array(
									'name'	=> esc_html__( 'Sidebar Widget Titles', 'storeup' ),
									'desc'	=> esc_html__( 'Select the Color and Font Properties for sidebar Widget Titles.', 'storeup' ),
									'id'	=> 'storeup_sidebar_widget_title',
									'std'	=> array(
													'color'		=> '',
													'size'		=> '',
													'lineheight' => '',
													'style'		=> '',
													'fontvariant' => '',
												),
									'type'	=> 'typography',
								);

				$storeup_options[] = array(
									'name'	=> esc_html__( 'Footer Widget Titles', 'storeup' ),
									'desc'	=> esc_html__( 'Select the Color and Font Properties for Footer Widget Titles.', 'storeup' ),
									'id'	=> 'storeup_footer_widget_title',
									'std'	=> array(
													'color'		=> '',
													'size'		=> '',
													'lineheight' => '',
													'style'		=> '',
													'fontvariant' => '',
												),
									'type'	=> 'typography',
								);
				$storeup_options[] = array(
									'name'	=> esc_html__( 'Footer Text', 'storeup' ),
									'desc'	=> esc_html__( 'Select the Color &amp; Font Properties for Footer Section', 'storeup' ),
									'id'	=> 'storeup_footer_widget_text',
									'std'	=> array(
													'color'		=> '',
													'size'		=> '',
													'lineheight' => '',
													'style'		=> '',
													'fontvariant' => '',
												),
									'type'	=> 'typography',
								);
				$storeup_options[] = array(
									'name'	=> esc_html__( 'Copyright Text', 'storeup' ),
									'desc'	=> esc_html__( 'Select the Color &amp; Font Properties for Copyright Section.', 'storeup' ),
									'id'	=> 'storeup_copyright_text',
									'std'	=> array(
													'color'		=> '',
													'size'		=> '',
													'lineheight' => '',
													'style'		=> '',
													'fontvariant' => '',
												),
									'type'	=> 'typography',
								);
				//---------------------------------------------------------------------------------------------------
				$storeup_options[] = array( 'name' => esc_html__( 'Custom CSS', 'storeup' ), 'type' => 'subnav' );
				//---------------------------------------------------------------------------------------------------

				$storeup_options[] = array(
									'name'	=> esc_html__( 'Custom CSS', 'storeup' ),
									'desc'	=> esc_html__( 'Quickly add some CSS of your own choice to this theme by adding it in this block.', 'storeup' ),
									'id'	=> 'storeup_extracss',
									'std'	=> '',
									'type'	=> 'textarea',
								);

				// S L I D E R S
				//------------------------------------------------------------------------
				$storeup_options[] = array(
									'name'	=> esc_html__( 'Sliders', 'storeup' ),
									'icon'	=> 'fa-sliders',
									'type'	=> 'heading',
								);

				$storeup_options[] = array(
									'name'	=> esc_html__( 'Frontpage Slider', 'storeup' ),
									'desc'	=> esc_html__( 'Check this if you wish to disable the Slider', 'storeup' ),
									'id'	=> 'storeup_slidervisble',
									'std'	=> '',
									'type'	=> 'checkbox',
								);
				$storeup_options[] = array(
									'name'	=> esc_html__( 'Select Slider Type', 'storeup' ),
									'desc'	=> esc_html__( 'Select which slider you want to use for the Frontpage of the theme.', 'storeup' ),
									'id'	=> 'storeup_slider',
									'std'	=> 'flexslider',
									'class' => 'select300',
									'options' => $storeup_theme_ob->storeup_get_vars( 'slider_type' ),
									'type'	=> 'select',
								);

				$storeup_options[] = array(
									'name'	=> esc_html__( 'Slider Category', 'storeup' ),
									'desc'	=> esc_html__( 'Select Slider Categories to hold the slides from.', 'storeup' ),
									'id'	=> 'storeup_flexslidercat',
									'class' => 'iva_of_sliders flexslider',
									'std'	=> 'flexslider',
									'options' => $storeup_theme_ob->storeup_get_vars( 'slider' ),
									'type'	=> 'multiselect',
								);

				$storeup_options[] = array(
									'name'	=> esc_html__( 'Slides Limits', 'storeup' ),
									'desc'	=> esc_html__( 'Enter the limit for Slides you want to hold on the Flex Slider', 'storeup' ),
									'id'	=> 'storeup_flexslidelimit',
									'std'	=> '',
									'class' => 'iva_of_sliders flexslider',
									'type'	=> 'text',
									'inputsize' => '',
								);

				$storeup_options[] = array(
									'name'	=> esc_html__( 'Slides Speed', 'storeup' ),
									'desc'	=> esc_html__( 'Select the slide speed you want to set', 'storeup' ),
									'id'	=> 'storeup_flexslidespeed',
									'std'	=> '3000',
									'class' => 'iva_of_sliders flexslider',
									'type'	=> 'text',
									'inputsize' => '',
									);

				$storeup_options[] = array(
									'name'	=> esc_html__( 'Slider Effect', 'storeup' ),
									'desc'	=> esc_html__( 'Select your animation type, "fade" or "slide"', 'storeup' ),
									'id'	=> 'storeup_flexslideeffect',
									'std'	=> 'flexslider',
									'class' => 'iva_of_sliders flexslider select300',
									'options' => array(
													'fade'	=> esc_html__( 'Fade', 'storeup' ),
													'slide'	=> esc_html__( 'Slide', 'storeup' ),
												),
									'type'	=> 'select',
								);

				$storeup_options[] = array(
									'name'	=> esc_html__( 'Direction Nav', 'storeup' ),
									'desc'	=> esc_html__( 'Navigation for previous/next arrows', 'storeup' ),
									'id'	=> 'storeup_flexslidednav',
									'class' => 'iva_of_sliders flexslider select300',
									'std'	=> '',
									'options' => array(
													'true'	=> esc_html__( 'True', 'storeup' ),
													'false'	=> esc_html__( 'False', 'storeup' ),
												),
									'type'	=> 'select',
								);
				$storeup_options[] = array(
								'name'	=> esc_html__( 'Slider Category', 'storeup' ),
								'desc'	=> esc_html__( 'Select Slider Categories to hold the slides from.', 'storeup' ),
								'id'	=> 'storeup_owlslidercat',
								'class' => 'iva_of_sliders owlslider',
								'std'	=> 'owlslider',
								'options' => $storeup_theme_ob->storeup_get_vars( 'slider' ),
								'type'	=> 'multiselect',
							);

				$storeup_options[] = array(
								'name'	=> esc_html__( 'Slides Limits', 'storeup' ),
								'desc'	=> esc_html__( 'Enter the limit for Slides you want to hold on the owlCarousel Slider', 'storeup' ),
								'id'	=> 'storeup_owlslidelimit',
								'std'	=> '',
								'class' => 'iva_of_sliders owlslider',
								'type'	=> 'text',
								'inputsize' => '',
							);

				$storeup_options[] = array(
								'name'	=> esc_html__( 'Slides Speed', 'storeup' ),
								'desc'	=> esc_html__( 'Select the slide speed you want to set', 'storeup' ),
								'id'	=> 'storeup_owlslidespeed',
								'std'	=> '3000',
								'class' => 'iva_of_sliders owlslider',
								'type'	=> 'text',
								'inputsize' => '',
								);
				$storeup_options[] = array(
								'name'	=> esc_html__( 'Navigation', 'storeup' ),
								'desc'	=> esc_html__( 'Navigation for previous/next arrows', 'storeup' ),
								'id'	=> 'storeup_owlslidernavigation',
								'class' => 'iva_of_sliders owlslider select300',
								'std'	=> '',
								'options' => array(
												'true'	=> esc_html__( 'True', 'storeup' ),
												'false'	=> esc_html__( 'False', 'storeup' ),
											),
								'type'	=> 'select',
							);
				$storeup_options[] = array(
									'name'	=> esc_html__( 'Static Image', 'storeup' ),
									'desc'	=> esc_html__( 'Upload the image size 1920 x 750 pixels to display on the homepage instead of slider.', 'storeup' ),
									'id'	=> 'storeup_static_image_upload',
									'std'	=> '',
									'class' => 'iva_of_sliders static_image',
									'type'	=> 'upload',
								);

				$storeup_options[] = array(
									'name'	=> esc_html__( 'Custom Slider', 'storeup' ),
									'desc'	=> esc_html__( 'Use in Your custom slider Plugin shortcodes Example : [revslider id="1"]', 'storeup' ),
									'id'	=> 'storeup_customslider',
									'std'	=> '',
									'class' => 'iva_of_sliders customslider',
									'type'	=> 'textarea',
									'inputsize' => '',
								);

				// P O S T   O P T I O N S
				//------------------------------------------------------------------------
				$storeup_options[] = array(
									'name'	=> esc_html__( 'Post Options', 'storeup' ),
									'icon'	=> 'fa-newspaper-o',
									'type'	=> 'heading',
								);

				$storeup_options[] = array(
									'name'	=> esc_html__( 'Blog Page Categories', 'storeup' ),
									'desc'	=> esc_html__( 'Selected categories will hold the posts to display in blog page template. ( template : template_blog.php)', 'storeup' ),
									'id'	=> 'storeup_blog_cats',
									'std'	=> '',
									'type'	=> 'multicheck',
									'options'	=> $storeup_theme_ob->storeup_get_vars( 'categories' ),
								 );

				$storeup_options[] = array(
									'name'	=> esc_html__( 'About Author', 'storeup' ),
									'desc'	=> esc_html__( 'Check this if you wish to disable the Author Info in post single page', 'storeup' ),
									'id'	=> 'storeup_aboutauthor',
									'std'	=> '',
									'type'	=> 'checkbox',
								);

				$storeup_options[] = array(
									'name'	=> esc_html__( 'Related Posts', 'storeup' ),
									'desc'	=> esc_html__( 'Check this if you wish to disable the related posts in post single page (based on tags).', 'storeup' ),
									'id'	=> 'storeup_relatedposts',
									'std'	=> '',
									'type'	=> 'checkbox',
								);

				$storeup_options[] = array(
									'name'	=> esc_html__( 'Post Pagination', 'storeup' ),
									'desc'	=> wp_kses( __( 'Check this if you wish to disable <strong>Next / Previous</strong> Post Pagination', 'storeup' ), $options_array_allowed_html ),
									'id'	=> 'storeup_singlenavigation',
									'std'	=> '',
									'type'	=> 'checkbox',
								);

				$storeup_options[] = array(
									'name'	=> esc_html__( 'Single Page Featured Image', 'storeup' ),
									'desc'	=> esc_html__( 'Check this if you wish to disable Featured Image on Post Single Page', 'storeup' ),
									'id'	=> 'storeup_blogfeaturedimg',
									'std'	=> '',
									'type'	=> 'checkbox',
								);

				$storeup_options[] = array(
									'name'	=> esc_html__( 'Blog Post Meta', 'storeup' ),
									'desc'	=> esc_html__( 'Check this if you wish to disable Meta Data in Blog Posts and Single Page', 'storeup' ),
									'id'	=> 'storeup_postmeta',
									'std'	=> '',
									'type'	=> 'checkbox',
								);

				// C U S T O M   S I D E B A R
				//------------------------------------------------------------------------
				$storeup_options[] = array(
									'name'	=> esc_html__( 'Sidebars','storeup' ),
									'icon'	=> 'fa-columns',
									'type'	=> 'heading',
								);

				$storeup_options[] = array(
									'name'	=> esc_html__( 'Custom Sidebars', 'storeup' ),
									'desc'	=> esc_html__( 'Create the custom sidebars and go to <strong>Appearance > Widgets</strong> to see the newly sidebar you have created. After assigning the widgets in the prefered sidebar you can assign specific sidebar to specific pages/posts in Options below the wordpress content editor of each page/post.', 'storeup' ),
									'id'	=> 'storeup_customsidebar',
									'std'	=> '',
									'type'	=> 'customsidebar',
								);

				$storeup_options[] = array(
									'name' => esc_html__( 'Sidebars Layout', 'storeup' ),
									'desc' 			=> esc_html__( 'Select the Layout style you wish to use for the page, Left Sidebar, Right Sidebar or Full Width.', 'storeup' ),
									'id' 			=> 'storeup_defaultlayout',
									'std' 			=> 'rightsidebar',
									'type'  		=> 'images',
									'options' 		=> array(
										   'rightsidebar'	=> STOREUP_FRAMEWORK_URI . 'admin/images/columns/rightsidebar.png',
										   'leftsidebar' 	=> STOREUP_FRAMEWORK_URI . 'admin/images/columns/leftsidebar.png',
										   'fullwidth'  	=> STOREUP_FRAMEWORK_URI . 'admin/images/columns/fullwidth.png',
									   ),
									);

				// F O O T E R
				//------------------------------------------------------------------------
				$storeup_options[] = array(
									'name'	=> esc_html__( 'Footer', 'storeup' ),
									'icon'	=> 'fa-columns',
									'type'	=> 'heading',
								);

				$storeup_options[] = array(
									'name'	=> esc_html__( 'Footer Sidebar', 'storeup' ),
									'desc'	=> esc_html__( 'Check this if you wish to disable the Footer Sidebar', 'storeup' ),
									'id'	=> 'storeup_footer_sidebar',
									'std'	=> '',
									'type'	=> 'checkbox',
								);

				$storeup_options[] = array(
									'name' => esc_html__( 'Footer Columns', 'storeup' ),
									'desc' => wp_kses( __( 'Select the Columns Layout Style from the styles shown to display footer sidebar area. After selecting save the options and go to your <strong>Appearance > Widgets</strong> to assign the widgets in each footer column.', 'storeup' ), $options_array_allowed_html ),
									'id'   => 'storeup_footerwidgetcount',
									'std'  => '4',
									'type' => 'images',
									'options' => array(
													'1' => STOREUP_ADMIN_URI . '/images/columns/1col.png',
													'2' => STOREUP_ADMIN_URI . '/images/columns/2col.png',
													'3' => STOREUP_ADMIN_URI . '/images/columns/3col.png',
													'4' => STOREUP_ADMIN_URI . '/images/columns/4col.png',
													'5' => STOREUP_ADMIN_URI . '/images/columns/5col.png',
													'6' => STOREUP_ADMIN_URI . '/images/columns/6col.png',
													'half_one_half'		=> STOREUP_ADMIN_URI . '/images/columns/half_one_half.png',
													'half_one_third'	=> STOREUP_ADMIN_URI . '/images/columns/half_one_third.png',
													'one_half_half'		=> STOREUP_ADMIN_URI . '/images/columns/one_half_half.png',
													'one_third_half'	=> STOREUP_ADMIN_URI . '/images/columns/one_third_half.png',
												),
										);
				// Footer Area Top
				$storeup_options[] = array(
										'name'	=> esc_html__( 'Footer Area Top Enable / Disable', 'storeup' ),
										'desc'	=> esc_html__( 'Check this if you wish to disable the Footer area top', 'storeup' ),
										'id'	=> 'storeup_footer_area_top',
										'std'	=> '',
										'type'	=> 'checkbox',
								);
				$storeup_options[] = array(
									'name'	=> esc_html__( 'Footer Area Top Background Color', 'storeup' ),
									'desc'	=> esc_html__( 'This will apply color to the footer area top of theme.', 'storeup' ),
									'id'	=> 'storeup_footer_area_top_bg_color',
									'std'	=> '',
									'type'	=> 'color',
				);
				$storeup_options[] = array(
									'name'	=> esc_html__( 'Footer Area Top Text Color', 'storeup' ),
									'desc'	=> esc_html__( 'This will apply color to the footer area top of theme.', 'storeup' ),
									'id'	=> 'storeup_footer_area_top_text_color',
									'std'	=> '',
									'type'	=> 'color',
				);
				$storeup_options[] = array(
									'name'	=> esc_html__( 'Footer Area Top Link Color', 'storeup' ),
									'desc'	=> esc_html__( 'Footer Area Top content containing any links color. (link color)..', 'storeup' ),
									'id'	=> 'storeup_footer_area_top_link_color',
									'std'	=> '',
									'type'	=> 'color',
				);
				$storeup_options[] = array(
									'name'	=> esc_html__( 'Footer Area Top Link Hover Color', 'storeup' ),
									'desc'	=> esc_html__( 'Footer Area Top content containing any links hover color. (link color)..', 'storeup' ),
									'id'	=> 'storeup_footer_area_top_link_hover_color',
									'std'	=> '',
									'type'	=> 'color',
				);
				// Footer Area Bottom
				$storeup_options[] = array(
										'name'	=> esc_html__( 'Footer Area Bottom Enable / Disable', 'storeup' ),
										'desc'	=> esc_html__( 'Check this if you wish to disable the Footer area bottom', 'storeup' ),
										'id'	=> 'storeup_footer_area_bottom',
										'std'	=> '',
										'type'	=> 'checkbox',
								);
				$storeup_options[] = array(
									'name'	=> esc_html__( 'Footer Area Bottom Background Color', 'storeup' ),
									'desc'	=> esc_html__( 'This will apply color to the footer area bottom of theme.', 'storeup' ),
									'id'	=> 'storeup_footer_area_bottom_bg_color',
									'std'	=> '',
									'type'	=> 'color',
				);
				$storeup_options[] = array(
									'name'	=> esc_html__( 'Footer Area Bottom Text Color', 'storeup' ),
									'desc'	=> esc_html__( 'This will apply color to the footer area bottom of theme.', 'storeup' ),
									'id'	=> 'storeup_footer_area_bottom_text_color',
									'std'	=> '',
									'type'	=> 'color',
				);
				$storeup_options[] = array(
									'name'	=> esc_html__( 'Footer Area Bottom Link Color', 'storeup' ),
									'desc'	=> esc_html__( 'Footer Area Bottom content containing any links color. (link color)..', 'storeup' ),
									'id'	=> 'storeup_footer_area_bottom_link_color',
									'std'	=> '',
									'type'	=> 'color',
				);
				$storeup_options[] = array(
									'name'	=> esc_html__( 'Footer Area Bottom Link Hover Color', 'storeup' ),
									'desc'	=> esc_html__( 'Footer Area Bottom content containing any links hover color. (link color)..', 'storeup' ),
									'id'	=> 'storeup_footer_area_bottom_link_hover_color',
									'std'	=> '',
									'type'	=> 'color',
				);
				// S O C I A B L E S
				//------------------------------------------------------------------------
				$storeup_options[] = array(
								'name'	=> esc_html__( 'Sociables', 'storeup' ),
								'icon'	=> 'fa-share-alt',
								'type'	=> 'heading',
							);

				$storeup_options[] = array(
										'name'	=> esc_html__( 'Sociables', 'storeup' ),
										'desc'	=> esc_html__( 'Click Add New to add sociables where you can add / delete. If you wish to use in widgets then us the shortcode as [sociable color="black/white"]', 'storeup' ),
										'id'	=> 'storeup_social_bookmark',
										'std'	=> '',
										'type'	=> 'custom_socialbook_mark',
									);
				//Sticky Bar
				// -----------------------------------------------------------------------

					$storeup_options[] = array(
									'name'	=> esc_html__( 'Sticky Bar', 'storeup' ),
									'icon'	=> 'fa-thumb-tack',
									'type'	=> 'heading',
								);

					$storeup_options[] = array(
										'name'	=> esc_html__( 'Sticky Notice Bar', 'storeup' ),
										'desc'	=> esc_html__( 'Check this if you wish to hide the sticky bar on top.', 'storeup' ),
										'id'	=> 'storeup_stickybar',
										'std'	=> '',
										'type'	=> 'checkbox',
									);

					$storeup_options[] = array(
										'name'	=> esc_html__( 'Sticky Bar Background Color', 'storeup' ),
										'desc'	=> esc_html__( 'Select the color you want to assign for the Sticky Bar', 'storeup' ),
										'id'	=> 'storeup_stickybarcolor',
										'std'	=> '',
										'type'	=> 'color',
									);

					$storeup_options[] = array(
										'name'	=> esc_html__( 'Sticky Bar Text Color', 'storeup' ),
										'desc'	=> esc_html__( 'Select the text color you want to assign for the Sticky Bar', 'storeup' ),
										'id'	=> 'storeup_stickybartext',
										'std'	=> '',
										'type'	=> 'color',
									);

					//Sharelink Options
					//--------------------------------------------------------------------------------------------------
					$storeup_options[] = array( 'name' => esc_html__( 'Sharelinks', 'storeup' ), 'icon' => 'fa-share', 'type' => 'heading' );
					//--------------------------------------------------------------------------------------------------
					$storeup_options[] = array(
											'name'	=> esc_html__( 'Google+', 'storeup' ),
											'desc'	=> esc_html__( 'Check this to enable Google+ Icon for Post Sharing', 'storeup' ),
											'id'	=> 'storeup_google_enable',
											'std'	=> '',
											'type'	=> 'checkbox',
										);
					$storeup_options[] = array(
											'name'	=> esc_html__( 'Facebook', 'storeup' ),
											'desc'	=> esc_html__( 'Check this to enable Facebook Icon for Post Sharing', 'storeup' ),
											'id'	=> 'storeup_facebook_enable',
											'std'	=> '',
											'type'	=> 'checkbox',
										);

					$storeup_options[] = array(
											'name'	=> esc_html__( 'LinkedIn', 'storeup' ),
											'desc'	=> esc_html__( 'Check this to enable LinkedIn Icon for Post Sharing', 'storeup' ),
											'id'	=> 'storeup_linkedIn_enable',
											'std'	=> '',
											'type'	=> 'checkbox',
										);

					$storeup_options[] = array(
											'name'	=> esc_html__( 'Digg', 'storeup' ),
											'desc'	=> esc_html__( 'Check this to enable Digg Icon for Post Sharing', 'storeup' ),
											'id'	=> 'storeup_digg_enable',
											'std'	=> '',
											'type'	=> 'checkbox',
										);

					$storeup_options[] = array(
											'name'	=> esc_html__( 'StumbleUpon', 'storeup' ),
											'desc'	=> esc_html__( 'Check this to enable StumbleUpon Icon for Post Sharing', 'storeup' ),
											'id'	=> 'storeup_stumbleupon_enable',
											'std'	=> '',
											'type'	=> 'checkbox',
										);

					$storeup_options[] = array(
											'name'	=> esc_html__( 'Pinterest', 'storeup' ),
											'desc'	=> esc_html__( 'Check this to enable Pinterest Icon for Post Sharing', 'storeup' ),
											'id'	=> 'storeup_pinterest_enable',
											'class'	=> 'pinterest_sharing',
											'std'	=> '',
											'type'	=> 'checkbox',
										);

					$storeup_options[] = array(
											'name'	=> esc_html__( 'Twitter', 'storeup' ),
											'desc'	=> esc_html__( 'Check this to enable Twitter Icon for Post Sharing', 'storeup' ),
											'id'	=> 'storeup_twitter_enable',
											'std'	=> '',
											'type'	=> 'checkbox',
										);

					$storeup_options[] = array(
											'name'	=> esc_html__( 'Tumblr', 'storeup' ),
											'desc'	=> esc_html__( 'Check this to enable Tumblr Icon for Post Sharing', 'storeup' ),
											'id'	=> 'storeup_tumblr_enable',
											'std'	=> '',
											'type'	=> 'checkbox',
										);
					$storeup_options[] = array(
											'name'	=> esc_html__( 'Email', 'storeup' ),
											'desc'	=> esc_html__( 'Check this to enable Email Icon for Post Sharing', 'storeup' ),
											'id'	=> 'storeup_email_enable',
											'std'	=> '',
											'type'	=> 'checkbox',
										);

					$storeup_options[] = array(
											'name'	=> esc_html__( 'Reddit', 'storeup' ),
											'desc'	=> esc_html__( 'Check this to enable reddit Icon for Post Sharing', 'storeup' ),
											'id'	=> 'storeup_reddit_enable',
											'std'	=> '',
											'type'	=> 'checkbox',
										);
					//Import and Export
					//---------------------------------------------------------------------------------------------------
					$storeup_options[] = array( 'name' => esc_html__( 'Import/Export', 'storeup' ), 'icon' => 'fa-floppy-o', 'type' => 'heading' );
					//---------------------------------------------------------------------------------------------------

					$storeup_options[] = array( 'name' => esc_html__( 'Options Backup', 'storeup' ), 'desc' => esc_html__( 'Import,Export Backup options.', 'storeup' ), 'type' => 'subsection' );

					$storeup_options[] = array(
										'name'	=> esc_html__( 'Export Backup Options', 'storeup' ),
										'desc'	=> esc_html__( 'Export Backup Options', 'storeup' ),
										'id'	=> 'storeup_export_backup_options',
										'std' 	=> '',
										'class' => 'atp-backup-options',
										'type'	=> 'export_backupoptions',
									);

					$storeup_options[] = array(
										'name'	=> esc_html__( 'Import Backup Options', 'storeup' ),
										'desc'	=> esc_html__( 'Import Backup Options', 'storeup' ),
										'id'	=> 'storeup_import_backup_options',
										'std'	=> '',
										'class' => 'atp-backup-options',
										'type'	=> 'import_backupoptions',
									);
					//-----------------------------------------------------------------------------------------------
					$storeup_options = apply_filters( 'custompost_themeoptions' , $storeup_options );
					//-----------------------------------------------------------------------------------------------
					$storeup_options = apply_filters( 'customlocalization_themeoptions', $storeup_options );
					//-----------------------------------------------------------------------------------------------
					return $storeup_options;
	}
} // End if().
