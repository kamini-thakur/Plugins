<?php
get_header();
?>
<div id="primary" class="pagemid">
	<div class="inner">
		<main class="content-area">
			<div class="entry-content-wrapper clearfix">

				<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>

				<div class="searchresults" id="post-<?php the_ID(); ?>">

					<div class="post_desc_holder">
						<div class="post_desc">
							<?php the_title( sprintf( '<h2 class="entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h2>' ); ?>
							<div class="entry-meta">
							<?php storeup_post_metadata(); ?>
							</div><!-- .entry-meta -->

							<a class="more-link" href="<?php echo esc_url( get_permalink() ) ?>"><?php esc_html_e( 'Read More', 'storeup' ); ?></a>

						</div><!-- .postmeta-->
					</div>

				</div><!-- #post-<?php the_ID();?> -->

				<?php endwhile; ?>

				<?php

				// Displays pagination
				if ( function_exists( 'storeup_pagination' ) ) {
					storeup_pagination();
				}?>

				<?php else : ?>

				<div class="iva-search-restult"><h2><?php esc_html_e( 'Not Found','storeup' ); ?></h2><?php esc_html_e( 'Apologies, but no results were found for the requested archive. Perhaps searching will help find a related post.', 'storeup' ); ?></div>

				<?php get_search_form(); ?>

				<?php endif; ?>

			</div>
		</main><!-- .content-area -->

		<?php get_sidebar();?>
		<!-- .pagemid -->

		<div class="clear"></div>

	</div><!-- .inner -->
</div><!-- .pagemid -->
<?php
get_footer();
