<?php
/**
 * Display an optional post thumbnail.
 *
 * Wraps the post thumbnail in an anchor element on index
 * views, or a div element when on single views.
 *
 */

if ( ! function_exists( 'storeup_post_metadata' ) ) {
	/**
	 * Print HTML with meta information for the current post-date/time and author.
	 */
	function storeup_post_metadata() {

		if ( is_sticky() && is_home() && ! is_paged() ) {
			echo '<span class="iva-pm-featured featured-post"><i class="fa fa-bookmark-o fa-lg fa-fw"></i></span>';
		}
		echo '<span class="iva-pm-poston">' . get_the_date() . '</span>';
		if ( get_the_category_list() ) {
			echo '<span class="iva-pm-postin">' . wp_kses_post( get_the_category_list( esc_html__( ' &bull; ', 'storeup' ) ) ) . '</span>';
		}
		echo '<span class="meta-likes">' . wp_kses_post( storeup_post_like( 'iva_like' ) ) . '</span>';
	}
}

if ( ! function_exists( 'storeup_pagination' ) ) :
	/**
	* Display navigation to next/previous set of posts when applicable.
	*
	*/
	function storeup_pagination() {
		// Don't print empty markup if there's only one page.
		if ( $GLOBALS['wp_query']->max_num_pages < 2 ) {
			return;
		}

		$paged        = get_query_var( 'paged' ) ? intval( get_query_var( 'paged' ) ) : 1;
		$pagenum_link = html_entity_decode( get_pagenum_link() );
		$query_args   = array();
		$url_parts    = explode( '?', $pagenum_link );

		if ( isset( $url_parts[1] ) ) {
			wp_parse_str( $url_parts[1], $query_args );
		}

		$pagenum_link = remove_query_arg( array_keys( $query_args ), $pagenum_link );
		$pagenum_link = trailingslashit( $pagenum_link ) . '%_%';

		$format  = $GLOBALS['wp_rewrite']->using_index_permalinks() && ! strpos( $pagenum_link, 'index.php' ) ? 'index.php/' : '';
		$format .= $GLOBALS['wp_rewrite']->using_permalinks() ? user_trailingslashit( 'page/%#%', 'paged' ) : '?paged=%#%';

		// Set up paginated links.
		$links = paginate_links( array(
			'base'     => $pagenum_link,
			'format'   => $format,
			'total'    => $GLOBALS['wp_query']->max_num_pages,
			'current'  => $paged,
			'mid_size' => 1,
			'add_args' => array_map( 'urlencode', $query_args ),
			'prev_text' => esc_html__( '&larr; Previous', 'storeup' ),
			'next_text' => esc_html__( 'Next &rarr;', 'storeup' ),
		) );

		if ( $links ) {
			$out = '<nav class="navigation paging-navigation">';
			$out .= '<div class="pagination loop-pagination">';
			$out .= $links;
			$out .= '</div>';
			$out .= '</nav>';
		}
		echo wp_kses_post( $out );
	}
endif;

if ( ! function_exists( 'storeup_body_class' ) ) {

	function storeup_body_class( $classes ) {
		if (
			is_tag() ||
			is_search() ||
			is_404() ||
			is_home()
		) {
			$storeup_frontpageid = '';
		} else {
			if ( class_exists( 'woocommerce' ) ) {
				if ( is_shop() ) {
					$storeup_frontpageid = get_option( 'woocommerce_shop_page_id' );
				} elseif ( is_cart( get_option( 'woocommerce_cart_page_id' ) ) ) {
					$storeup_frontpageid = get_option( 'woocommerce_cart_page_id' );
				} else {
					$storeup_frontpageid = get_the_ID();
				}
			} else {
				$storeup_frontpageid = get_the_ID();
			}
		}
		$storeup_pageslider 	= get_post_meta( $storeup_frontpageid, 'page_slider', true );
		$storeup_sidebar_layout = storeup_generator( 'storeup_sidebar_option', $storeup_frontpageid );
		$storeup_page_layout 	= get_post_meta( $storeup_frontpageid, 'storeup_page_layout', true );

		if ( '' !== $storeup_pageslider ) {
			$sliderclass = 'iva-page_slider';
		} else {
			$sliderclass = '';
		}

		$classes[] = $storeup_sidebar_layout;
		$classes[] = $sliderclass;
		$headerstyle = get_option('storeup_headerstyle','default');

		if( $headerstyle == 'verticalleftmenu' ) {
			$classes[]= 'vertical_leftmenu';
		}

		if( $storeup_page_layout == 'on' ) {
			$classes[]= 'boxed';
		} else {
			$classes[]= get_option( 'storeup_layoutoption' ) ? get_option( 'storeup_layoutoption' ) : 'stretched';
		}

		return $classes;
	}
}
add_filter( 'body_class', 'storeup_body_class' );
// post class
function storeup_post_classes( $classes, $class, $post_id ) {

	if ( is_single() ) {
		$classes[] = 'singlepost';
	}

	if ( is_singular( 'gallery' ) ) {
		$classes[] = 'custompost-single';
	}

	if ( is_singular( 'slider' ) ) {
		$classes[] = 'post';
	}

	return $classes;
}
add_filter( 'post_class', 'storeup_post_classes', 10, 3 );

/**
 * Gallery Image lightbox
 */
if ( ! function_exists( 'storeup_gallery_add_rel_attribute' ) ) {
	function storeup_gallery_add_rel_attribute( $link ) {
		global $post;
		return str_replace( '<a href', '<a data-rel="prettyPhoto[pp_default]" href', $link );
	}
	add_filter( 'wp_get_attachment_link', 'storeup_gallery_add_rel_attribute' );
}
