<?php
/*
Template Name: Sub Navigation
*/
?>
<?php get_header(); ?>
	<div id="primary" class="pagemid">
		<div class="inner">
			<main class="content-area" role="main">
				<div class="entry-content-wrapper clearfix">

					<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>

					<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

						<?php the_content(); ?>

						<?php wp_link_pages( array( 'before' => '<div class="page-link">' . esc_html__( 'Pages:', 'storeup' ), 'after' => '</div>' ) ); ?>

					</div><!-- #POST-<?php the_ID(); ?> -->

					<?php endwhile; ?>
					<?php endif; ?>

					<div class="clear"></div>
					<?php edit_post_link( esc_html__( 'Edit', 'storeup' ), '<span class="edit-link">', '</span>' ); ?>

					<?php comments_template( '', true ); ?>
				</div>
			</main><!-- .content-area -->

			<div id="sidebar">
				<div class="content widget-area">
				<?php
				if ( $post->post_parent ) {
					$storeup_ancestors = get_post_ancestors( $post->ID );
					$storeup_root 	= count( $storeup_ancestors ) - 1;
					$storeup_parent = $storeup_ancestors[ $storeup_root ];
				} else {
					$storeup_parent = $post->ID;
				}

				$storeup_children = wp_list_pages( 'title_li=&child_of=' . $storeup_parent . '&echo=0' );

				if ( $storeup_children ) { ?>
					<ul class="sub_nav"><?php echo wp_kses_post( $storeup_children ); ?></ul>
				<?php } ?>
				</div>
			</div>
			<!-- .sidebar -->
			<div class="clear"></div>
		</div><!-- .inner -->
	</div><!-- .pagemid -->
<?php
get_footer();
