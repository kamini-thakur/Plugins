<?php
/**
 * The template for displaying the header
 * @package WordPress
 * @subpackage storeup
 * @since storeup 1.0
 */
?><!DOCTYPE html>
<html <?php language_attributes(); ?> class="no-js">
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0">
	<link rel="profile" href="http://gmpg.org/xfn/11">
	<?php
	// Adds site icon with a fallback
	if ( ! ( function_exists( 'has_site_icon' ) && has_site_icon() ) ) {
		if ( get_option( 'storeup_custom_favicon' ) ) {
			echo '<link rel="shortcut icon" href="' . esc_url( get_option( 'storeup_custom_favicon' ) ) . '" type="image/x-icon">';
		}
	}?>
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php
	// Pulls an frontpage id ID for page slider
if (
	is_tag() ||
	is_search() ||
	is_404() ||
	is_home()
) {
	$storeup_frontpageid = '';
} else {
	$storeup_frontpageid = get_the_ID();
}
$storeup_pageslider = get_post_meta( $storeup_frontpageid, 'storeup_page_slider', true );

// General Preloader
$storeup_page_preloader = get_option( 'storeup_page_preloader' ) ? get_option( 'storeup_page_preloader' ) : '';
if ( 'on' !== $storeup_page_preloader ) {
	$storeup_custom_preloader_img = get_option( 'storeup_custom_preloader_img' ) ? get_option( 'storeup_custom_preloader_img' ) : '';
	echo '<div class="storeup_page_loader">';
	if ( ! empty( $storeup_custom_preloader_img ) ) {
		echo '<span class="storeup_blink_me"></span>';
	}
	echo '</div>';
}
?>
	<div class="bodyoverlay"></div>

	<?php if ( get_option( 'storeup_stickybar' ) !== 'on' &&  is_active_sidebar( 'storeup_stickycontent' ) ) {  ?>
		<div id="trigger" class="tarrow"><i class="fa fa-arrow-circle-o-down fa-lg"></i></div>
		<div id="sticky">
		<?php
		if ( is_active_sidebar( 'storeup_stickycontent' ) ) :
			dynamic_sidebar( 'storeup_stickycontent' );
		endif; ?>
		</div>
	<?php } ?>

	<div id="wrapper">
		<?php
		// Switch Headers
		$storeup_headerstyle = get_option( 'storeup_headerstyle' ) ? get_option( 'storeup_headerstyle' ) : 'headerstyle1';

		// Switch Headers
		switch ( $storeup_headerstyle ) {
			case 'headerstyle1':
				get_template_part( 'headers/header','style1' );
				break;
			case 'headerstyle2':
				get_template_part( 'headers/header','style2' );
				break;
			case 'headerstyle3':
				get_template_part( 'headers/header','style3' );
				break;
			case 'headerstyle4':
				get_template_part( 'headers/header','style4' );
				break;
			case 'headerstyle5':
				get_template_part( 'headers/header','style5' );
				break;
			case 'fixedheader':
				get_template_part( 'headers/header','fixed' );
				break;
			case 'verticalleftmenu':
				get_template_part( 'headers/vertical','leftmenu' );
				break;
			default:
				get_template_part( 'headers/header','style5' );
		}

		if ( is_front_page() || ('' !== $storeup_pageslider) ) {
			// Get Slider based on the option selected in theme options panel
			if ( 'on' !== get_option( 'storeup_slidervisble' ) ) {

				if ( '' === $storeup_pageslider ) {
					$storeup_chooseslider = get_option( 'storeup_slider' );
				} else {
					$storeup_chooseslider = $storeup_pageslider;
				}
				switch ( $storeup_chooseslider ) :
					case 'static_image':
							get_template_part( 'slider/static', 'slider' );
							break;
					case 'flexslider':
							get_template_part( 'slider/flex', 'slider' );
							break;
					case 'owlslider':
							get_template_part( 'slider/owlcarousel', 'slider' );
							break;
					case 'customslider':
							get_template_part( 'slider/custom', 'slider' );
							break;
					default:
							get_template_part( 'slider/default', 'slider' );
				endswitch;
			}
		} else {
			if ( ! is_404() ) {
				storeup_generator( 'storeup_subheader', $storeup_frontpageid );
			}
		}
		// Conditional code for ending div for header style 4 and 5
		// starting div can be found in header-style4.php and header-style5.php
		if (
			( ! is_front_page() && '' !== $storeup_pageslider ) ) ||
			( ( ! is_front_page() || '' !== $storeup_pageslider ) && 'headerstyle4' === $storeup_headerstyle ) ||
			( ( ! is_front_page() || '' !== $storeup_pageslider ) && 'headerstyle5' === $storeup_headerstyle )
		) {
			// Adds div for the header style 4 and 5
			// starting div can be found in header-style4.php and header-style5.php
			echo '</div>';
		}
		$sub_disabled = get_post_meta( $storeup_frontpageid, 'storeup_subheader_teaser_options', true );
		if ( 'disable' === $sub_disabled ) {
			echo wp_kses_post( storeup_generator( 'storeup_breadcrumb', $storeup_frontpageid ) );
		}
		?>
<div id="main">
<?php
