<?php
/*
Template Name: Gallery
*/

/**
 * The Header for our theme.
 * Includes the header.php template file.
 */

get_header(); ?>
<div id="primary" class="pagemid">
	<div class="inner">

		<main class="content-area">

		<div class="entry-content-wrapper clearfix">

			<?php while ( have_posts() ) : the_post(); ?>
			<?php the_content(); ?>
			<?php endwhile; ?>

			<?php
			//Columns for Gallery Thumbs
			$storeup_column_index = 0;
			$storeup_columns = get_option( 'storeup_gallery_columns' ) ? get_option( 'storeup_gallery_columns' ) : 3 ;

			if ( '2' == $storeup_columns ) { $storeup_class = 'col_half'; }
			if ( '3' == $storeup_columns ) { $storeup_class = 'col_third'; }
			if ( '4' == $storeup_columns ) { $storeup_class = 'col_fourth'; }
			if ( '5' == $storeup_columns ) { $storeup_class = 'col_fifth'; }

			//Full Width Gallery Image Sizes
			$storeup_width = '470';
			$storeup_height = '320';

			$storeup_orderby = get_option( 'storeup_gallery_orderby' ) ? get_option( 'storeup_gallery_orderby' ) : 'date';
			$storeup_order   = get_option( 'storeup_gallery_order' ) ? get_option( 'storeup_gallery_order' ) : 'ASC';

			if ( get_query_var( 'paged' ) ) {
				$paged = get_query_var( 'paged' );
			} elseif ( get_query_var( 'page' ) ) {
				$paged = get_query_var( 'page' );
			} else {
				$paged = 1;
			}

			$storeup_pagination = get_option( 'storeup_gallery_pagination' );
			if ( 'on' === $storeup_pagination ) {
				$storeup_gallery_limit = get_option( 'storeup_gallery_limits' );
			} else {
				$storeup_gallery_limit = '-1' ;
			}

			$args = array(
				'post_type' 	 => 'gallery',
				'posts_per_page' => $storeup_gallery_limit,
				'paged' 		 => $paged,
				'orderby'		 => $storeup_orderby,
				'order'			 => $storeup_order,
			);
			$wp_query = new WP_Query( $args );

			if ( $wp_query->have_posts() ) : while ( $wp_query->have_posts() ) :  $wp_query->the_post();

					$storeup_gallery_venue			= get_post_meta( $post->ID, 'gallery_venue', true );
					$storeup_gallery_upload			= get_post_meta( $post->ID, 'gallery_upload', true );
					$storeup_img_alt_title 			= get_the_title();

					$storeup_column_index++;

					$storeup_last = ( $storeup_column_index == $storeup_columns && 1 != $storeup_columns ) ? 'end ' : '';
				?>
				<div class="gallery-list col_third <?php echo esc_attr( $storeup_class ) . ' ' . esc_attr( $storeup_last ); ?>">

					<div class="custompost_entry">
						<?php
						if ( has_post_thumbnail() ) {
							echo '<div class="custompost_thumb port_img">';
							echo '<a href="' . esc_url( get_permalink( get_the_id() ) ) . '" title="' . get_the_title() . '"><figure>';
							echo storeup_img_resize( $post->ID, '', $storeup_width, $storeup_height, '', $storeup_img_alt_title );
							echo '</figure></a>';
							echo '</div>';
							echo '<span class="imgoverlay"></span>';
						} ?>
					</div><!-- .custompost_thumb -->

					<div class="gallery-desc">
						<h2 class="entry-title"><a href="<?php echo esc_url( get_permalink() ) ?>" rel="bookmark" title="<?php printf( esc_attr_e( 'Permanent Link to %s', 'storeup' ), get_the_title() ); ?>"><?php the_title(); ?></a></h2>
						<?php
						if ( '' !== $storeup_gallery_venue ) {
							echo '<span>' . esc_html( $storeup_gallery_venue ) . '</span>';
						}?>
					</div><!-- .gallery_desc -->

				</div><!--.gallery-list -->

				<?php
				if ( $storeup_column_index === $storeup_columns ) {
					$storeup_column_index = 0;
					echo '<div class="clear"></div>';
				}
				?>

				<?php endwhile; ?>

				<div class="clear"></div>

				<?php
				if ( 'on' === $storeup_pagination ) {
					storeup_pagination();
				}?>

				<?php wp_reset_postdata(); ?>

				<?php else : ?>

				<p><?php esc_html_e( 'Apologies, but no results were found for the requested archive. Perhaps searching will help find a related post.', 'storeup' ); ?></p>

				<?php get_search_form(); ?>

				<?php endif;?>

			</div><!-- .entry-content-wrapper -->
		</main><!-- .content-area -->

		<?php if ( storeup_generator( 'storeup_sidebar_option', $post->ID ) !== 'fullwidth' ) { get_sidebar(); } ?>

	</div><!-- inner -->
	</div><!-- #primary.pagemid -->

<?php 
get_footer();
