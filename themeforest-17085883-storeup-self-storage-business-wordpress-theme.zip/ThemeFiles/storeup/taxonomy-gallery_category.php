<?php

/**
 * The Header for our theme.
 * Includes the header.php template file.
 */

get_header(); ?>


	<div id="primary" class="pagemid">
		<div class="inner">

			<main class="content-area">
				<div class="entry-content-wrapper clearfix">

			<?php
			$orderby 	= get_option( 'storeup_gallery_orderby' ) ? get_option( 'storeup_gallery_orderby' ) : 'date';
			$order   	= get_option( 'storeup_gallery_order' ) ? get_option( 'storeup_gallery_order' ) : 'ASC';
			$pagination = get_option( 'storeup_gallery_pagination' );
			$columns 	= get_option( 'storeup_gallery_columns' )?get_option( 'storeup_gallery_columns' ) : '4';

			$column_index = 0;

			if ( $columns == '4' ) { $class = 'col_fourth'; }
			if ( $columns == '3' ) { $class = 'col_third'; }

			//Full Width Gallery Image Sizes
			if ( $columns == '4' ) { $width = '470'; $height = '470' ; }
			if ( $columns == '3' ) { $width = '470'; $height = '470' ; }

			if ( get_query_var( 'paged' ) ) {
				$paged = get_query_var( 'paged' );
			} elseif ( get_query_var( 'page' ) ) {
				$paged = get_query_var( 'page' );
			} else {
				$paged = 1;
			}
			if ( $pagination == 'on' ) {
				$gallery_limit = get_option( 'storeup_gallery_limits' );
			} else {
				$gallery_limit = '-1' ;
			}
			$taxonomy_gallery_obj = $wp_query->get_queried_object();

			if ( $taxonomy_gallery_obj ) {
				$args = array(
					'post_type'	=> 'gallery',
					'posts_per_page' => $gallery_limit,
					'tax_query' => array(
							array(
								'taxonomy' => 'gallery_category',
								'field' => 'id',
								'terms' => $taxonomy_gallery_obj->term_id,
							),
					),
					'paged'		=> $paged,
					'orderby'	=> $orderby,
					'order'		=> $order,
				);
			}

			$storeup_gallery_query = new WP_Query( $args );

			if ( $storeup_gallery_query->have_posts() ) : while (  $storeup_gallery_query->have_posts() ) :  $storeup_gallery_query->the_post();

					$gallery_venue		= get_post_meta( $post->ID, 'storeup_gallery_venue', true );
					$gallery_upload		= get_post_meta( $post->ID, 'storeup_gallery_upload', true );
					$img_alt_title 		= get_the_title();
					$permalink			= get_permalink( get_the_id() );
					$column_index++;

					$last = ( $column_index == $columns && $columns != 1 ) ? 'end ' : '';
				?>

				<div class="gallery-list <?php echo esc_attr( $class . ' ' . $last ); ?>">
					<div class="custompost_entry">
					<?php
					if ( has_post_thumbnail() ) {
						echo '<div class="custompost_thumb port_img">';
						echo '<a href="' . esc_url( $permalink ) . '" title="' . get_the_title() . '"><figure>';
						echo wp_kses_post( storeup_img_resize( $post->ID, '', $width, $height, '', $img_alt_title ) );
						echo '</figure></a>';
						echo '</div>';
						echo '<span class="imgoverlay"></span>';
					}
					?>
					<div class="gallery-desc">
						<h2 class="entry-title"><a href="<?php esc_url( the_permalink() ) ?>" rel="bookmark" title="<?php printf( esc_attr_e( 'Permanent Link to %s', 'storeup' ), get_the_title() ); ?>"><?php the_title(); ?></a></h2>
						<?php
						if ( $gallery_venue != '' ) {
							echo '<span>' . esc_html( $gallery_venue ) . '</span>';
						}?>
					</div><!-- .gallery_desc -->
						</div>
				</div><!--.gallery-list -->

				<?php
				if ( $column_index == $columns ) {
					$column_index = 0;
					echo '<div class="clear"></div>';
				}
				?>

			<?php endwhile; ?>

			<?php wp_reset_postdata(); ?>

			<div class="clear"></div>

			<?php
			if ( $pagination == 'on' ) {
				if ( function_exists( 'storeup_pagination' ) ) {
					storeup_pagination();
				}
			} ?>

			<?php else : ?>

			<p><?php esc_html_e( 'Apologies, but no results were found for the requested archive. Perhaps searching will help find a related post.', 'storeup' ); ?></p>

			<?php get_search_form(); ?>

			<?php endif;?>

			</div><!-- .entry-content-wrapper-->
			</main><!-- .content-area -->

			<?php get_sidebar(); ?>

		</div><!-- inner -->
	</div><!-- #primary.pagemid -->

<?php
get_footer();
