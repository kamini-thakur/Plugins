<?php
/**
 * The template for displaying the header
 * @package WordPress
 * @subpackage storeup
 * @since storeup 1.0
 */
?><!DOCTYPE html>
<html <?php language_attributes(); ?> class="no-js">
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0">
	<link rel="profile" href="http://gmpg.org/xfn/11">
	<?php if ( get_option( 'storeup_custom_favicon' ) ) { ?>
	<link rel="shortcut icon" href="<?php echo esc_url( get_option( 'storeup_custom_favicon' ) ); ?>" type="image/x-icon" />
<?php } ?>
<?php
wp_head();
?>
</head>
<body <?php body_class(); ?>>
<div class="wrap404">
	<div class="error_404">
		<i calss="fa fa-traffic-cone"></i>
		<?php
		echo '<h2>'. esc_html__( '404', 'storeup' ).'</h2>';
		echo '<h5>'. esc_html__( 'SORRY - PAGE NOT FOUND!', 'storeup' ).'</h5>';
		echo '<p>'. esc_html__( 'The page you are looking for was moved, removed, or does not exist.', 'storeup' ).'</p>';
		echo '<h6><a class="btn green small" href="'. esc_url( site_url() ).'">'.esc_html__( 'Go To HomePage', 'storeup' ).'</a></h6>';
		?>
	</div>
</div>
</body>
</html>
<?php
