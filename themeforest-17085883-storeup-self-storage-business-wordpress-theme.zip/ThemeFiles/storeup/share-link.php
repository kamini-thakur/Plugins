<?php
// if this post has a featured image
if ( has_post_thumbnail( $post->ID ) ) {
	// get the featured image
	$storeup_admin_img_uri_post_thumb = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'full' );
	$storeup_admin_img_uri_post_thumb = $storeup_admin_img_uri_post_thumb[0];
} else {
	$storeup_admin_img_uri_post_thumb = '';
}

$out = '';
// Google+
if ( get_option( 'storeup_google_enable' ) === 'on' ) {
	$out .= '<li><a class="iva_tip" target="_blank" href="http://plus.google.com/share?url=' . esc_url( get_permalink( $post->ID ) ) . '&amp;title=' . get_the_title() . '&amp;annotation=' . get_the_title() . '"  title="' . esc_html__( 'googleplus', 'storeup' ) . '"><i class="fa fa-google-plus fa-lg"></i><span class="ttip">' . esc_html__( 'Google+', 'storeup' ) . '</span></a></li>';
}
// Facebook
if ( get_option( 'storeup_facebook_enable' ) === 'on' ) {
	$out .= '<li><a class="iva_tip" href="http://www.facebook.com/sharer.php?u=' . esc_url( get_permalink( $post->ID ) ) . '&amp;title=' . get_the_title() . '" title="' . esc_html__( 'facebook','storeup' ) . '" target="_blank"><i class="fa fa-facebook fa-lg"></i><span class="ttip">' . esc_html__( 'Facebook', 'storeup' ) . '</span></a></li>';
}
// Twitter
if ( get_option( 'storeup_twitter_enable' ) === 'on' ) {
	$out .= '<li><a class="iva_tip" href="http://twitter.com/share?url=' . esc_url( get_permalink( $post->ID ) ) . '&amp;text=' . get_the_title() . '" title="' . esc_html__( 'twitterbird', 'storeup' ) . '" target="_blank"><i class="fa fa-twitter fa-lg"></i><span class="ttip">' . esc_html__( 'Twitter', 'storeup' ) . '</span></a></li>';
}
// Reddit
if ( get_option( 'storeup_reddit_enable' ) === 'on' ) {
	$out .= '<li><a class="iva_tip" href="http://reddit.com/submit?url=' . esc_url( get_permalink( $post->ID ) ) . '&amp;title=' . get_the_title() . '" title="' . esc_html__( 'reddit', 'storeup' ) . '" target="_blank"><i class="fa fa-reddit fa-lg"></i><span class="ttip">' . esc_html__( 'Reddit', 'storeup' ) . '</span></a></li>';
}
// Linkdedin
if ( get_option( 'storeup_linkedIn_enable' ) === 'on' ) {
	$out .= '<li><a class="iva_tip" href="http://www.linkedin.com/shareArticle?mini=true&amp;url=' . esc_url( get_permalink( $post->ID ) ) . '&amp;title=' . get_the_title() . '" title="' . esc_html__( 'linkedin', 'storeup' ) . '" target="_blank"><i class="fa fa-linkedin fa-lg"></i><span class="ttip">' . esc_html__( 'LinkedIn', 'storeup' ) . '</span></a></li>';
}
// Digg
if ( get_option( 'storeup_digg_enable' ) === 'on' ) {
	$out .= '<li><a class="iva_tip" href="http://www.digg.com/submit?url=' . esc_url( get_permalink( $post->ID ) ) . '&amp;title=' . get_the_title() . '" title="' . esc_html__( 'digg', 'storeup' ) . '" target="_blank"><i class="fa fa-digg fa-lg"></i><span class="ttip">' . esc_html__( 'Digg', 'storeup' ) . '</span></a></li>';
}
// Tumblr
if ( get_option( 'storeup_tumblr_enable' ) === 'on' ) {
	$out .= '<li><a class="iva_tip" href="http://www.tumblr.com/share/link?url=' . urlencode( get_permalink( $post->ID ) ) . '&amp;name=' . urlencode( $post->post_title ) . '&amp;description=' . urlencode( get_the_excerpt() ) . '" title="' . esc_html__( 'tumblr', 'storeup' ) . '" target="_blank"><i class="fa fa-tumblr fa-lg"></i><span class="ttip">' . esc_html__( 'Tumblr', 'storeup' ) . '</span></a></li>';
}
// Pinterest
if ( get_option( 'storeup_pinterest_enable' ) === 'on' ) {
	if ( '' !== $storeup_admin_img_uri_post_thumb ) {
		$out .= '<li><a class="iva_tip" href="http://pinterest.com/pin/create/button/?url=' . esc_url( get_permalink( $post->ID ) ) . '&media=' . esc_url( $storeup_admin_img_uri_post_thumb ) . '&description=' . get_the_title() . '" title="' . esc_html__( 'pinterest', 'storeup' ) . '" target="_blank"><i class="fa fa-pinterest-p fa-lg"></i><span class="ttip">' . esc_html__( 'Pinterest', 'storeup' ) . '</span></a></li>';
	} else {
		$out .= '<li><a class="iva_tip" href="http://pinterest.com/pin/create/button/?url=' . esc_url( get_permalink( $post->ID ) ) . '&description=' . get_the_title() . '" title="' . esc_html__( 'pinterest', 'storeup' ) . '" target="_blank"><i class="fa fa-pinterest-p fa-lg"></i><span class="ttip">' . esc_html__( 'Pinterest', 'storeup' ) . '</span></a></li>';
	}
}
// StumbleUpon
if ( get_option( 'storeup_stumbleupon_enable' ) === 'on' ) {
	$out .= '<li><a class="iva_tip" href="http://www.stumbleupon.com/submit?url=' . esc_url( get_permalink( $post->ID ) ) . '&amp;title=' . get_the_title() . '" title="' . esc_html__( 'stumbleupon', 'storeup' ) . '" target="_blank"><i class="fa fa-stumbleupon fa-lg"></i><span class="ttip">' . esc_html__( 'StumbleUpon', 'storeup' ) . '</span></a></li>';
}
// Email
if ( get_option( 'storeup_email_enable' ) === 'on' ) {
	$out .= '<li class="email"><a class="iva_tip" href="mailto:?subject=' . get_the_title() . '&amp;body=' . esc_url( get_permalink() ) . '" title="' . esc_html__( 'email', 'storeup' ) . '" target="_blank"><i class="fa fa-envelope fa-lg"></i><span class="ttip">' . esc_html__( 'Email', 'storeup' ) . '</span></a></li>';
}
if ( ! empty( $out ) ) {
	$output = '<div class="sharing-box">';
	$output .= '<h4>' . esc_html__( 'Share','storeup' ) . '</h4>';
	$output .= '<ul class="sharing-box-ico">';
	$output .= $out;
	$output .= '</ul>';
	$output .= '</div>';
	echo wp_kses_post( $output );
}
