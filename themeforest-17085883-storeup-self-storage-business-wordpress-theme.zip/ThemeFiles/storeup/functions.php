<?php
/**
 * register and enqueue scripts.
 */

if ( ! function_exists( 'storeup_theme_enqueue_scripts' ) ) {
	function storeup_theme_enqueue_scripts() {

		global $post, $storeup_theme_version;

		// Enqueue scripts.
		wp_enqueue_script( 'hoverintent', STOREUP_THEME_JS . '/hoverIntent.js',array( 'jquery' ),'', true );
		wp_enqueue_script( 'superfish', STOREUP_THEME_JS . '/superfish.js',array( 'jquery' ),'',true );

		if ( is_singular( 'gallery' ) || ( is_a( $post, 'WP_Post' ) && has_shortcode( $post->post_content, 'gallery' ) )  || is_page_template( 'template-blog.php' ) ) {
			wp_enqueue_script( 'prettyphoto', STOREUP_THEME_JS . '/jquery.prettyPhoto.js','','',true );
			wp_enqueue_style( 'prettyphoto', STOREUP_THEME_CSS . '/prettyPhoto.css', array(), $storeup_theme_version, false );
		}

		wp_enqueue_script( 'fitvids', STOREUP_THEME_JS . '/jquery.fitvids.js',array( 'jquery' ), $storeup_theme_version ,true );
		wp_enqueue_script( 'storeup-customjs', STOREUP_THEME_JS . '/storeup-custom.js', array( 'jquery' ), $storeup_theme_version , true );

		if ( is_singular() ) {
			wp_enqueue_script( 'comment-reply' );
		}

		// AJAX URL

		$storeup_data['ajaxurl'] = admin_url( 'admin-ajax.php' );

		// HOME URL
		$storeup_data['home_url'] = get_home_url();

		// Directory URI
		$tq_page = esc_url( get_permalink( get_option( 'storeup_bk_thankyou_page' ) ) );

		$storeup_data['directory_uri'] = get_template_directory_uri();

		$storeup_data['thankyou_page'] =  $tq_page;

		// Pass data to javascript
		$storeup_params = array(
			'l10n_print_after' => 'storeup_localize_script_param = ' . wp_json_encode( $storeup_data ) . ';',
		);
		wp_localize_script( 'jquery', 'storeup_localize_script_param', $storeup_params );

		// Enqueue styles.
		wp_enqueue_style( 'storeup-theme', get_stylesheet_uri() );
		wp_enqueue_style( 'font-awesome', STOREUP_THEME_CSS . '/fontawesome/css/font-awesome.css' );
		wp_enqueue_style( 'fontello', STOREUP_THEME_CSS . '/fontello/css/aicon_.css' );
		wp_enqueue_style( 'fontello-animation', STOREUP_THEME_CSS . '/fontello/css/animation.css' );
		wp_enqueue_style( 'pe-icon-7-stroke', STOREUP_THEME_CSS . '/pe-icon-7-stroke/css/pe-icon-7-stroke.css' );
		wp_enqueue_style( 'storeup-responsive', STOREUP_THEME_CSS . '/responsive.css',array( 'storeup-niche-style' ), $storeup_theme_version, 'all' );

		if ( '0' !== get_option( 'storeup_custom_skin' ) ) {
			$storeup_custom_skin = get_option( 'storeup_custom_skin' );
			wp_enqueue_style( 'storeup-presets', STOREUP_THEME_URI . '/colors/' . $storeup_custom_skin );
		}
	}
	add_action( 'wp_enqueue_scripts','storeup_theme_enqueue_scripts' );
} // End if().
/**
 * Flex Slider Enqueue Scripts
 */
if ( ! function_exists( 'storeup_flexslider_enqueue_scripts' ) ) {
	add_action( 'storeup_theme_flexslider','storeup_flexslider_enqueue_scripts' );
	function storeup_flexslider_enqueue_scripts() {
		$fs_slidespeed 	= get_option( 'storeup_flexslidespeed' ) ? get_option( 'storeup_flexslidespeed' ) : '3000';
		$fs_slideeffect = get_option( 'storeup_flexslideeffect' ) ? get_option( 'storeup_flexslideeffect' ) : 'fade';
		$fs_slidednav 	= get_option( 'storeup_flexslidednav' ) ? get_option( 'storeup_flexslidednav' ) : 'true';
		$flexslider_args = array(
							'slideeffect' => $fs_slideeffect,
							'slidespeed'  => $fs_slidespeed,
							'slidednav'	  => $fs_slidednav,
						);
		wp_enqueue_script( 'flexslider', STOREUP_THEME_JS . '/jquery.flexslider-min.js', array( 'jquery' ), '', true );
		wp_enqueue_script( 'easing', STOREUP_THEME_JS . '/jquery.easing.1.3.js',array( 'jquery' ), '', true );
		wp_localize_script( 'flexslider', 'flexslider_args', $flexslider_args );
		wp_enqueue_style( 'flexslider-style', STOREUP_THEME_CSS . '/flexslider.css' );
	}
}

if ( ! function_exists( 'storeup_owlcarousel_enqueue_scripts' ) ) {
	add_action( 'storeup_theme_owlcarouselslider','storeup_owlcarousel_enqueue_scripts' );
	function storeup_owlcarousel_enqueue_scripts() {
		$owl_slidespeed 	 = get_option( 'storeup_owlslidespeed' ) ? get_option( 'storeup_owlslidespeed' ) : '3000';
		$owl_slidelimit 	 = get_option( 'storeup_owlslidelimit' ) ? get_option( 'storeup_owlslidelimit' ) : '5';
		$owl_slidenavigation = get_option( 'storeup_owlslidernavigation' ) ? get_option( 'storeup_owlslidernavigation' ) : 'false';
		$owlslider_args = array(
							'slidelimit' 	  => $owl_slidelimit,
							'slidespeed'  	  => $owl_slidespeed,
							'slidenavigation' => $owl_slidenavigation,
						);
		if ( ! wp_script_is( 'owl-carousel', $list = 'enqueued' ) ) {
			wp_enqueue_script( 'owl-carousel', STOREUP_THEME_JS . '/owl.carousel.js', array( 'jquery' ), '', true );
			wp_enqueue_style( 'owl-style', STOREUP_THEME_CSS . '/owl.carousel.css' );
			wp_enqueue_style( 'owl-theme', STOREUP_THEME_CSS . '/owl.theme.css' );
		}
		wp_localize_script( 'owl-carousel', 'owlslider_args', $owlslider_args );
	}
}

/*
 * Theme functions for common usage
 * storeup_post_classes()
 * storeup_body_class()
 * storeup_pagination()
 * storeup_post_metadata()
 */
require_once( get_template_directory() . '/theme-functions.php' );

// Post Likes
require_once( get_template_directory() . '/framework/common/iva-post-like.php' );

/* Options Importer */
require_once( get_template_directory() . '/framework/admin/options-importer/ob-import-export.php' );

$storeup_theme_data	 	= wp_get_theme();
$storeup_theme_version  = $storeup_theme_data->get( 'Version' );
$storeup_theme_name   	= $storeup_theme_data->get( 'Name' );

/**
 * Storeup_Theme_Functions class.
 */
if ( ! class_exists( 'Storeup_Theme_Functions' ) ) {

	class Storeup_Theme_Functions {
		public $storeup_meta_box;

		public function __construct() {
			$this->storeup_theme_constants();
			$this->storeup_theme_support();
			$this->storeup_theme_admin_scripts();
			$this->storeup_theme_admin_interface();
			$this->storeup_theme_custom_widgets();
			$this->storeup_theme_custom_meta();
			$this->storeup_theme_meta_generator();
			$this->storeup_theme_extras();
		}

		function storeup_theme_constants() {

			// framework general variables and directory paths.
		 	$storeup_theme_data	 = wp_get_theme();
			$storeup_theme_version  = $storeup_theme_data->get( 'Version' );

			/**
			 * Set the file path based on whether the Options
			 * Framework is in a parent theme or child theme
			 * Directory Structure
			 */
			define( 'STOREUP_FRAMEWORK', '2.0' );
			define( 'STOREUP_THEME_NAME', 'storeup' );
			define( 'STOREUP_THEME_VERSION', $storeup_theme_version );
			define( 'STOREUP_THEME_URI', get_template_directory_uri() );
			define( 'STOREUP_THEME_DIR', get_template_directory() );
			define( 'STOREUP_THEME_JS', STOREUP_THEME_URI . '/js' );
			define( 'STOREUP_THEME_CSS', STOREUP_THEME_URI . '/css' );
			define( 'STOREUP_FRAMEWORK_DIR', STOREUP_THEME_DIR . '/framework/' );
			define( 'STOREUP_FRAMEWORK_URI', STOREUP_THEME_URI . '/framework/' );
			define( 'STOREUP_ADMIN_URI',  STOREUP_FRAMEWORK_URI . 'admin' );
			define( 'STOREUP_ADMIN_DIR',  STOREUP_FRAMEWORK_DIR . 'admin' );
			define( 'STOREUP_THEME_WIDGETS',  STOREUP_FRAMEWORK_DIR . 'widgets/' );
			define( 'STOREUP_THEME_CUSTOM_META',  STOREUP_FRAMEWORK_DIR . 'custom-meta/' );
		}

		/**
		 * allows a theme to register its support of a certain features
		 */
		function storeup_theme_support() {
			add_theme_support( 'post-formats', array(
				'aside',
				'audio',
				'link',
				'image',
				'gallery',
				'quote',
				'status',
				'video',
				'event',
			));

			add_theme_support( 'post-thumbnails' );
			add_theme_support( 'automatic-feed-links' );
			add_editor_style( 'editor-style.css' );
			add_theme_support( 'menus' );
			add_theme_support( 'title-tag' );

			// Register menu.
			register_nav_menus( array(
				'primary-menu' => esc_html__( 'Primary Menu', 'storeup' ),
			));

			// Define content width.
			if ( ! isset( $content_width ) ) {
				$content_width = 1100;
			}
		}

		/**
		 * Scripts and Styles enqueue .
		 */
		function storeup_theme_admin_scripts() {
			require_once( STOREUP_FRAMEWORK_DIR . 'common/admin-scripts.php' );
		}

		/**
		 * Admin Interface .
		 */
		function storeup_theme_admin_interface() {
			require_once( STOREUP_FRAMEWORK_DIR . 'common/iva-googlefont.php' );
			require_once( STOREUP_FRAMEWORK_DIR . 'admin/admin-interface.php' );
			require_once( STOREUP_FRAMEWORK_DIR . 'admin/theme-options.php' );
		}

		/**
		 * Widgets .
		 */
		function storeup_theme_custom_widgets() {
			require_once( STOREUP_THEME_WIDGETS . '/register-widget.php' );
			require_once( STOREUP_THEME_WIDGETS . '/contactinfo.php' );
			require_once( STOREUP_THEME_WIDGETS . '/sociable.php' );
			require_once( STOREUP_THEME_WIDGETS . '/recentpost.php' );
			require_once( STOREUP_THEME_WIDGETS . '/icon-box.php' );
			require_once( STOREUP_THEME_WIDGETS . '/button.php' );
		}

		/** load meta generator templates
		 * @files slider, Menus, page, posts,
		 */
		function storeup_theme_custom_meta() {
			require_once( STOREUP_THEME_CUSTOM_META . '/page-meta.php' );
			require_once( STOREUP_THEME_CUSTOM_META . '/post-meta.php' );
			require_once( STOREUP_THEME_CUSTOM_META . '/slider-meta.php' );
			require_once( STOREUP_THEME_CUSTOM_META . '/testimonial-meta.php' );
			require_once( STOREUP_THEME_CUSTOM_META . '/gallery-meta.php' );
		}

		function storeup_theme_meta_generator() {
			require_once( STOREUP_THEME_CUSTOM_META . '/meta-generator.php' );
		}

		/**
		 * Theme Functions
		 * @uses skin generator
		 * @uses pagination
		 * @uses sociables
		 * @uses Aqua imageresize // Credits : http://aquagraphite.com/
		 * @uses plugin activation class
		 */
		function storeup_theme_extras() {
			require_once( STOREUP_THEME_DIR . '/css/skin.php' );
			require_once( STOREUP_FRAMEWORK_DIR . 'includes/mega-menu.php' );
			require_once( STOREUP_FRAMEWORK_DIR . 'common/iva-generator.php' );
			require_once( STOREUP_FRAMEWORK_DIR . 'common/sociables.php' );
			require_once( STOREUP_FRAMEWORK_DIR . 'includes/image-resize.php' );
			require_once( STOREUP_FRAMEWORK_DIR . 'includes/class-activation.php' );
		}

		/**
		 * Custom switch case for fetching
		 * posts, post-types, custom-taxonomies, tags
		 */

		function storeup_get_vars( $type ) {
			$storeup_tax_options = array();
			switch ( $type ) {
				/**
				 * Get page titles.
				 */
				case 'pages':
					$storeup_get_pages = get_pages( 'sort_column=post_parent,menu_order' );
					if ( ! empty( $storeup_get_pages ) && ! is_wp_error( $storeup_get_pages ) ) {
						foreach ( $storeup_get_pages as $page ) {
							$storeup_tax_options[ $page->ID ] = $page->post_title;
						}
					}
					break;
				/**
				 * Get slider slug and name.
				 */
				case 'slider':
					$storeup_slider_cats = get_terms( 'slider_cat', 'orderby=name&hide_empty=0' );
					if ( ! empty( $storeup_slider_cats ) && ! is_wp_error( $storeup_slider_cats ) ) {
						foreach ( $storeup_slider_cats as $slider ) {
							$storeup_tax_options[ $slider->slug ] = $slider->name;
						}
					}
					break;

				/**
				 * Get posts slug and name.
				 */
				case 'posts':
					$storeup_post_cats = get_categories( 'hide_empty=0' );
					if ( ! empty( $storeup_post_cats ) && ! is_wp_error( $storeup_post_cats ) ) {
						foreach ( $storeup_post_cats as $cat ) {
							$storeup_tax_options[ $cat->slug ] = $cat->name;
						}
					}
					break;

				/**
				 * Get categories slug and name.
				 */
				case 'categories':
					$storeup_post_cats = get_categories( 'hide_empty=true' );
					if ( ! empty( $storeup_post_cats ) && ! is_wp_error( $storeup_post_cats ) ) {
						foreach ( $storeup_post_cats as $cat ) {
							$storeup_tax_options[ $cat->term_id ] = $cat->name;
						}
					}
					break;

				/**
				 * Get taxonomy tags.
				 */
				case 'tags':
					$storeup_tags = get_tags( array(
						'taxonomy' => 'post_tag',
					) );
					if ( ! empty( $storeup_tags ) && ! is_wp_error( $storeup_tags ) ) {
						foreach ( $storeup_tags as $tags ) {
							$storeup_tax_options[ $tags->slug ] = $tags->name;
						}
					}
					break;

				/**
				 * Slider arrays for theme options.
				 */
				case 'slider_type':
					$storeup_tax_options = array(
						'' 				=> esc_html__( 'Select Slider', 'storeup' ),
						'flexslider' 	=> esc_html__( 'Flex Slider', 'storeup' ),
						'owlslider' 	=> esc_html__( 'Owl Slider', 'storeup' ),
						'static_image' 	=> esc_html__( 'Static Image', 'storeup' ),
						'customslider'	=> esc_html__( 'Custom Slider', 'storeup' ),
					);
					break;
			} // End switch().

			return $storeup_tax_options;
		}
	}
} // End if().

/**
 * Defines Template directory path for seminar directory
 */
define( 'STOREUP_URI', get_template_directory_uri() . '/storeup-niche/' );
define( 'STOREUP_DIR', get_template_directory() . '/storeup-niche/' );

if ( ! defined( 'STOREUP_NICHE_DIR' ) ) {
	define( 'STOREUP_NICHE_DIR', get_template_directory() . '/storeup-niche/' );
}
if ( defined( 'STOREUP_NICHE_DIR' ) ) {
	require_once( STOREUP_NICHE_DIR . 'index.php' );
	add_action( 'after_setup_theme', 'storeup_theme_setup' );
} else {
	$storeup_theme_ob = new Storeup_Theme_Functions();
	add_action( 'after_setup_theme', 'storeup_theme_setup' );
}
if ( ! function_exists( 'storeup_theme_setup' ) ) {

	function storeup_theme_setup() {

		load_theme_textdomain( 'storeup', get_template_directory() . '/languages' );
		// This theme uses its own gallery styles.
		add_filter( 'use_default_gallery_style', '__return_false' );
	}
	add_action( 'after_setup_theme', 'storeup_theme_setup' );
}
/**
 * function storeup_custom_login_logo
 */
if ( ! function_exists( 'storeup_custom_login_logo' ) ) {
	add_action( 'login_head', 'storeup_custom_login_logo' );
	function storeup_custom_login_logo() {
		if ( get_option( 'storeup_admin_logo' ) ) {
			echo '<style type="text/css">.login h1 a { background-image:url(' . esc_url( get_option( 'storeup_admin_logo' ) ) . ') !important; }</style>';
		}
	}
}

/**
* generates the html pingback head tag
* @return string the pingback head tag
*/
if ( ! function_exists( 'storeup_set_pingback_tag' ) ) {
	function storeup_set_pingback_tag( $echo = true ) {
		$output = apply_filters( 'storeup_pingback_head_tag', '<link rel="pingback" href="' . get_bloginfo( 'pingback_url' ) . '" />' . "\n" );
		echo wp_kses( $output ,  array(
			'link' => array(
				'href' => true,
				'rel' => true,
			),
		));
	}

	add_action( 'wp_head', 'storeup_set_pingback_tag', 10, 0 );
}
if ( ! function_exists( 'storeup_get_js_defaultdate' ) ) {
	function storeup_get_js_defaultdate() {
		$storeup_default_date = get_option( 'storeup_date_format' ) ? get_option( 'storeup_date_format' ) :'Y/m/d';
		switch ( $storeup_default_date ) {
			case 'Y/m/d':
					$storeup_js_defaultdate = 'yy/mm/dd';
					break;
			case 'm/d/Y':
					$storeup_js_defaultdate = 'mm/dd/yy';
					break;
			case 'd-m-Y':
					$storeup_js_defaultdate = 'dd-mm-yy';
					break;
			default:
					$storeup_js_defaultdate = 'yy/mm/dd';
					break;
		}
		return $storeup_js_defaultdate;
	}
}
if ( ! function_exists( 'storeup_get_attachment_id_from_src' ) ) {
	function storeup_get_attachment_id_from_src( $image_src ) {
		global $wpdb;
		$id = $wpdb->get_var( $wpdb->prepare( "SELECT * FROM $wpdb->posts WHERE guid = %s", $image_src ) );
		return $id;
	}
}

// Theme Demo Importer
function storeup_ocdi_import_files() {
	return array(
		array(
			'import_file_name'         => esc_html__( 'Main Demo','storeup' ),
			'local_import_file'        => trailingslashit( get_template_directory() ) . '/theme-demo/main-demo/Sample-Data.xml',
			'local_import_widget_file' => trailingslashit( get_template_directory() ) . '/theme-demo/main-demo/widget_data.wie',
			'import_preview_image_url' => trailingslashit( get_template_directory_uri() ) . 'screenshot.png',
			'import_notice'            => esc_html__( 'After you import this demo, you will have to setup the slider separately.', 'storeup' ),
		),
	);
}
add_filter( 'pt-ocdi/import_files', 'storeup_ocdi_import_files' );

function storeup_ocdi_after_import_setup() {
	// Assign menus to their locations.
	$main_menu = get_term_by( 'name', 'Menu Main', 'nav_menu' );

	set_theme_mod( 'nav_menu_locations', array(
			'primary-menu' => $main_menu->term_id,
		)
	);

	// Assign front page and posts page (blog page).
	$front_page_id = get_page_by_title( 'Frontpage' );
	$blog_page_id  = get_page_by_title( 'Blog' );

	update_option( 'show_on_front', 'page' );
	update_option( 'page_on_front', $front_page_id->ID );
	update_option( 'page_for_posts', $blog_page_id->ID );

}
add_action( 'pt-ocdi/after_import', 'storeup_ocdi_after_import_setup' );

// Woocommerce Config File
if ( class_exists( 'woocommerce' ) ) {
	require_once( get_template_directory() . '/woocommerce/wc-config.php' );
}