<?php
/* Header Style5 */
$storeup_sh_inline_style = $storeup_sh_style_prop = $storeup_sh_bg_props = $storeup_frontpageid = '';
if ( is_tag() || is_search() || is_404() || is_home() ) {

} else {
	$storeup_sh_bg_props = get_post_meta( $post->ID,'storeup_subheader_img', true );
	$storeup_frontpageid = $post->ID;
}
if ( is_array( $storeup_sh_bg_props ) && ! empty( $storeup_sh_bg_props['0']['image'] ) ) {
	$storeup_sh_style_prop = 'background:url(' . $storeup_sh_bg_props['0']['image'] . ') ' . $storeup_sh_bg_props['0']['position'] . ' ' . $storeup_sh_bg_props['0']['repeat'] . ' ' . $storeup_sh_bg_props['0']['attachement'] . ' ' . $storeup_sh_bg_props['0']['color'] . ';';
} elseif ( is_array( $storeup_sh_bg_props ) && ! empty( $storeup_sh_bg_props['0']['color'] ) ) {
	$storeup_sh_style_prop = 'background-color:' . $storeup_sh_bg_props['0']['color'] . ';';
} elseif ( ! is_array( $storeup_sh_bg_props )  && $storeup_sh_bg_props != '' ) {
	$storeup_sh_style_prop  = 'background:url(' . $storeup_sh_bg_props . ');';
}
$storeup_sh_inline_style 	= ( $storeup_sh_style_prop != '' ) ? ' style="' . $storeup_sh_style_prop . '"' : '';
$storeup_header_light_logo  = get_option( 'storeup_header_light_logo' );
$storeup_header_dark_logo   = get_option( 'storeup_header_dark_logo' );
$storeup_page_slider 		= get_post_meta( $storeup_frontpageid, 'storeup_page_slider', true );

if ( ! is_front_page() || $storeup_page_slider != '' ) {
	echo '<div class="header_section">';
	if ( $storeup_sh_style_prop != '' ) {
		echo '<div class="header_section_bg"></div>';
		echo '<div class="header_section_bg_overlay"></div>';
	}
}?>
	<div class="header_wrapper">
		<header class="header-style5">
			<div class="header">
				<div class="header-area">

					<div class="logo">
					<?php
					echo '<div class="iva-light-logo">';
					storeup_generator( 'storeup_logo', 'storeup_header_light_logo');
					echo '</div>';
					echo '<div class="iva-dark-logo">';
					storeup_generator( 'storeup_logo', 'storeup_header_dark_logo');
					echo '</div>';
					?>
					</div><!-- /logo -->

					<div class="header-rightpart">

						<div class="icn_wrap_align">
							<div id="ivaSearch" class="ivaSearch icnalign"><i class="fa fa-search fa-1"></i></div>
						</div>

						<div class="primarymenu menuwrap">
							<?php storeup_generator( 'storeup_primary_menu' ); ?>
						</div>

						<?php  if ( is_active_sidebar( 'header_widget_area_1' ) ) : dynamic_sidebar( 'header_widget_area_1' );  endif; ?>

					</div>
					<?php 
					if ( has_nav_menu( 'primary-menu' ) ) {  ?>
						<div id="iva-mobile-nav-icon" class="iva-mobile-dropdown"><span></span><span></span><span></span><span></span></div>
					<?php } ?>
				</div> <!-- #header-area end -->
			</div><!-- .header end -->
		</header><!-- .header-style5 -->

		<?php storeup_generator( 'storeup_mobile_menu' ); ?>

		<div id="ivaSearchbar" class="act">
			<div class="inner">
				<form  method="get" id="searchform" action="<?php echo esc_url( home_url( '/' ) ); ?>">
					<input type="text" value="" name="s" id="s" placeholder="<?php echo esc_html__( 'Search here...', 'storeup' ); ?>" class="ivaInput headerSearch" />
					<span class="search-close"><i class="fa fa-close fa-1"></i></span>
				</form>
			</div>
		</div>
	</div><!-- .header_wrapper-->
<?php
