<?php
/* vertical Side Menu */
?>

<header class="sidemenu">
	<div class="header-area">
		<div class="logo"><?php storeup_generator( 'storeup_logo', 'storeup_header_dark_logo' ); ?></div>
		<div class="primarymenu menuwrap">
			<?php storeup_generator( 'storeup_vertical_menu' ); ?>
			<?php 
			if ( has_nav_menu( 'primary-menu' ) ) {  ?>
				<div id="iva-mobile-nav-icon" class="iva-mobile-dropdown"><span></span><span></span><span></span><span></span></div>
			<?php } ?>
		</div>
	</div>

	<?php if ( is_active_sidebar( 'vertical-menu-footer' ) ) { ?>
	<div class="vertical_footerbar">
		<div class="inner">	
		<?php  if ( is_active_sidebar( 'vertical-menu-footer' ) ) : dynamic_sidebar( 'vertical-menu-footer' );  endif; ?>
		</div>
	</div>
	<?php } ?>	

</header><!-- #header -->

<?php storeup_generator( 'storeup_mobile_menu' ); ?>

<div class="sidebar-left">
	<?php
	if ( get_option('storeup_topbar') != 'on' ) {
		if ( is_active_sidebar( 'topbarleft' ) || is_active_sidebar( 'topbarright' ) ) { ?>
			<div class="topbar">
				<div class="inner">
					<div class="topbar-left">
						<?php  if ( is_active_sidebar( 'topbarleft' ) ) : dynamic_sidebar( 'topbarleft' );  endif; ?>
					</div><!-- /one_half -->
					<div class="topbar-right">
						<?php  if ( is_active_sidebar( 'topbarright' ) ) : dynamic_sidebar( 'topbarright' );  endif; ?>
					</div><!-- /one_half last -->
				</div><!-- /inner -->
			</div><!-- /topbar -->
		<?php
		}
	}
	?>
