<?php
/* Header Style2 */

if ( get_option( 'storeup_topbar' ) != 'on' ) {
	if ( is_active_sidebar( 'topbarleft' ) || is_active_sidebar( 'topbarright' ) ) { ?>
		<div class="topbar">
			<div class="inner">
			<div class="topbar-left">
				<?php  if ( is_active_sidebar( 'topbarleft' ) ) : dynamic_sidebar( 'topbarleft' );  endif; ?>
			</div><!-- /one_half -->
			<div class="topbar-right">
				<?php  if ( is_active_sidebar( 'topbarright' ) ) : dynamic_sidebar( 'topbarright' );  endif; ?>
			</div><!-- /one_half last -->
		</div><!-- /inner -->
		</div><!-- /topbar -->
		<div class="clear"></div>
	<?php
	}
} ?>

<header class="header-style2">
	<div class="header">
		<div class="header-area">
			<div class="widget-left-s2">
				<?php
				if ( is_active_sidebar( 'header_widget_area_left' ) ) :
					dynamic_sidebar( 'header_widget_area_left' );
				endif; ?>
			</div>
			<div class="logo">
				<?php storeup_generator( 'storeup_logo', 'storeup_header_dark_logo' ); ?>
			</div>
			<div class="widget-right-s2">
				<?php
				if ( is_active_sidebar( 'header_widget_area_right' ) ) :
					dynamic_sidebar( 'header_widget_area_right' );
				endif; ?>
			</div>
			<?php 
			if ( has_nav_menu( 'primary-menu' ) ) {  ?>
				<div id="iva-mobile-nav-icon" class="iva-mobile-dropdown"><span></span><span></span><span></span><span></span></div>
			<?php } ?>
		</div>
		<div class="primarymenu menuwrap">
			<div class="menu-inner"><?php storeup_generator( 'storeup_primary_menu' ); ?></div>
		</div><!-- primarymenu -->
		<?php
		// Mobile menu
		storeup_generator( 'storeup_mobile_menu' );
		?>
		<div class="widget-left-s3-mobile">
			<div class="widget-left-s3">
					<?php
					if ( is_active_sidebar( 'header_widget_area_left' ) ) :
						dynamic_sidebar( 'header_widget_area_left' );
					endif; ?>
					<?php
					if ( is_active_sidebar( 'header_widget_area_right' ) ) :
						dynamic_sidebar( 'header_widget_area_right' );
					endif; ?>
			</div>
		</div>
	</div>
</header><!-- /header-S2 -->
<?php
