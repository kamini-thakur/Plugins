<?php
/* Header Style1 */
?>
<?php
if ( get_option('storeup_topbar') != 'on' ) {
	if ( is_active_sidebar( 'topbarleft') || is_active_sidebar( 'topbarright') ){ ?>
		<div class="topbar">
			<div class="inner">
			<div class="topbar-left">
				<?php  if ( is_active_sidebar( 'topbarleft' ) ) : dynamic_sidebar('topbarleft');  endif; ?>
			</div><!-- /one_half -->
			<div class="topbar-right">
				<?php  if ( is_active_sidebar( 'topbarright' ) ) : dynamic_sidebar('topbarright');  endif; ?>
			</div><!-- /one_half last -->
			</div>
		</div><!-- /topbar -->
	<?php
	}
} ?>
<header class="header-style1">
	<div class="header">
		<div class="header-area">
			<div class="logo">
				<?php storeup_generator( 'storeup_logo', 'storeup_header_dark_logo' ); ?>
			</div><!-- /logo -->

			<div class="primarymenu menuwrap">
				<?php storeup_generator( 'storeup_primary_menu' ); ?>
				<?php if (has_nav_menu( 'primary-menu' ) ) {  ?>
					<div id="iva-mobile-nav-icon" class="iva-mobile-dropdown"><span></span><span></span><span></span><span></span></div>
				 <?php } ?>
			</div>

			<!-- Header Widget Area -->
			<?php  if ( is_active_sidebar( 'header_widget_area_1' ) ) : dynamic_sidebar('header_widget_area_1');  endif; ?>

			<div class="icn_wrap">
				<div id="ivaSearch" class="ivaSearch icnalign"><i class="fa fa-search fa-1"></i></div>
			</div>
		</div>

		<div id="ivaSearchbar" class="act">
			<div class="inner">
				<form  method="get" id="searchform" action="<?php echo esc_url( home_url( '/' ) ); ?>">
					<input type="text" value="" name="s" id="s" placeholder="<?php echo esc_html__( 'Search here...', 'storeup' ); ?>" class="ivaInput headerSearch" />
					<span class="search-close"><i class="fa fa-close fa-1"></i></span>
				</form>
			</div>
		</div>
	<?php
	// Mobile menu
	storeup_generator( 'storeup_mobile_menu' );
	?>
	</div>
</header><!-- #header -->
<?php
