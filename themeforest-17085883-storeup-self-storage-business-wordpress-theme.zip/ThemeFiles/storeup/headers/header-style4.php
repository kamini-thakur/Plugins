<?php
/* Header Style4 */
$storeup_sh_inline_style = $storeup_sh_style_prop = $storeup_sh_bg_props = $storeup_frontpageid = '';
if ( is_tag() || is_search() || is_404() || is_home() ) {

} else {
	$storeup_sh_bg_props = get_post_meta( $post->ID,'storeup_subheader_img', true );
	$storeup_frontpageid = $post->ID;
}

if ( is_array( $storeup_sh_bg_props ) && ! empty( $storeup_sh_bg_props['0']['image'] ) ) {
	$storeup_sh_style_prop = 'background:url(' . $storeup_sh_bg_props['0']['image'] . ') ' . $storeup_sh_bg_props['0']['position'] . ' ' . $storeup_sh_bg_props['0']['repeat'] . ' ' . $storeup_sh_bg_props['0']['attachement'] . ' ' . $storeup_sh_bg_props['0']['color'] . ';';
} elseif ( is_array( $storeup_sh_bg_props ) && ! empty( $storeup_sh_bg_props['0']['color'] ) ) {
	$storeup_sh_style_prop = 'background-color:' . $storeup_sh_bg_props['0']['color'] . ';';
} elseif ( ! is_array( $storeup_sh_bg_props )  && $storeup_sh_bg_props !='' ) {
	$storeup_sh_style_prop  = 'background:url(' . $storeup_sh_bg_props . ');';
}

$storeup_sh_inline_style 	= ( $storeup_sh_style_prop != '' ) ? ' style="' . $storeup_sh_style_prop . '"' : '';
$storeup_page_slider 		= get_post_meta( $storeup_frontpageid, 'storeup_page_slider', true );

if ( ! is_front_page() || $storeup_page_slider != '' ) {
	echo '<div class="header_section">';
	if ( $storeup_sh_style_prop != '' ) {
		echo '<div class="header_section_bg"></div>';
		echo '<div class="header_section_bg_overlay"></div>';
	}
}?>

<div class="header_wrapper header-style4">
	<header class="header-style4">
		<?php
		if ( get_option('storeup_topbar') != 'on' ) {
			if ( is_active_sidebar( 'topbarleft' ) || is_active_sidebar( 'topbarright' ) ) { ?>
				<div class="topbar">
					<div class="inner">
						<div class="topbar-left">
							<?php  if ( is_active_sidebar( 'topbarleft' ) ) : dynamic_sidebar( 'topbarleft' );  endif; ?>
						</div><!-- /one_half -->
						<div class="topbar-right">
							<?php  if ( is_active_sidebar( 'topbarright' ) ) : dynamic_sidebar( 'topbarright' );  endif; ?>
						</div><!-- /one_half last -->
					</div><!-- /inner -->
				</div><!-- /topbar -->
			<?php
			}
		}
		?>
		<div class="header">
			<div class="header-area">
				<div class="logo">
					<?php storeup_generator( 'storeup_logo', 'storeup_header_dark_logo' ); ?>
				</div><!-- /logo -->
				<div class="primarymenu menuwrap">
					<?php storeup_generator( 'storeup_primary_menu' ); ?>
					<?php 
					if ( has_nav_menu( 'primary-menu' ) ) {  ?>
						<div id="iva-mobile-nav-icon" class="iva-mobile-dropdown"><span></span><span></span><span></span><span></span></div>
					<?php } ?>
				</div>
			</div> <!-- #header-area2 end -->
				<?php
				// Mobile menu
				storeup_generator( 'storeup_mobile_menu' );
				?>
		</div><!-- .header end -->
	</header><!-- .header-style4 -->
</div><!-- .header_wrapper-->
<?php
