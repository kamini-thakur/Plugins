<?php
/**
 * The template for displaying posts in the Aside post format
 * @package WordPress
 */
?>
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

	<div class="entry-content">
	<?php
	if ( has_excerpt() && ! is_single() ) {
		the_excerpt();
	} else {
		echo '<div class="iva-aside">';
		the_content( esc_html__( 'Read More', 'storeup' ) );
		echo '</div>';

		wp_link_pages( array(
			'before'      => '<div class="page-links"><span class="page-links-title">' . esc_html__( 'Pages:', 'storeup' ) . '</span>',
			'after'       => '</div>',
			'link_before' => '<span>',
			'link_after'  => '</span>',
		));
	} ?>
	<?php if ( is_single() ) { the_tags(); } ?>
	</div><!-- .entry-content -->
</article><!-- /post-<?php the_ID();?> -->
<?php
