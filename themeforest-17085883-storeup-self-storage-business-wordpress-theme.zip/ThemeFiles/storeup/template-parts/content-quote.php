<?php
/**
 * The template for displaying quotes post format
 * @package WordPress
 */
?>
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<div class="entry-content">
		<?php
		if ( has_excerpt() && ! is_single() ) {
			the_excerpt();
			echo '<a class="more-link" href="'. esc_url( get_permalink() ) .'">'. esc_html__( 'Read More','storeup' ) .'</a>';
		} else {
			the_content( esc_html__( 'Read More', 'storeup' ) );

			wp_link_pages( array(
				'before'      => '<div class="page-links"><span class="page-links-title">' . esc_html__( 'Pages:', 'storeup' ) . '</span>',
				'after'       => '</div>',
				'link_before' => '<span>',
				'link_after'  => '</span>',
			));
		} ?>
		<?php if ( is_single() ) { the_tags(); } ?>

		<?php if ( get_option( 'storeup_postmeta' ) !== 'on' ) { ?>
			<div class="entry-meta">
				<?php storeup_post_metadata(); ?>
			</div><!-- .entry-meta -->
		<?php } ?>

	</div><!-- .entry-content -->
</article><!-- /post-<?php the_ID();?> -->
<?php
