<?php
/**
 * The template for displaying posts in the Image post format
 * @package WordPress
 */
?>
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<?php
	if ( is_single() ) {
		if ( has_post_thumbnail() && get_option( 'storeup_blogfeaturedimg' ) !== 'on' ) { ?>
			<div class="postimg">
				<?php echo '<figure>' . wp_kses( storeup_img_resize( $post->ID, '', '1100', '550', '', '' ), array(
					'img' => array(
						'alt' => true,
						'src' => true,
						'class' => true,
						'width' => true,
						'height' => true,
					),
				) ) . '</figure>'; ?>
			</div><?php
		}
	} else {
		if ( has_post_thumbnail() ) {  ?>
			<div class="postimg">
				<?php echo '<figure>' . wp_kses( storeup_img_resize( $post->ID, '', '700', '870', '', '' ), array(
					'img' => array(
						'alt' => true,
						'src' => true,
						'class' => true,
						'width' => true,
						'height' => true,
					),
				) ) . '</figure>'; ?>
			</div><?php
		}
	} ?>
	<div class="iva-post-content">
	<header class="entry-header">
		<?php if ( get_option( 'storeup_postmeta' ) !== 'on' ) { ?>
			<div class="entry-meta">
				<?php storeup_post_metadata(); ?>
			</div><!-- .entry-meta -->
		<?php } ?>
	<?php
	if ( is_single() ) {
		the_title( '<h2 class="entry-title">', '</h2>' );
	} else {
		the_title( '<h2 class="entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h2>' );
	}
	?>
	</header><!-- .entry-header -->

	<div class="entry-content">
	<?php
	if ( has_excerpt() && ! is_single() ) {
		the_excerpt();
		echo '<a class="more-link" href="' . esc_url( get_permalink() ) . '">' . esc_html__( 'Read More','storeup' ) . '</a>';
	} else {
		the_content( esc_html__( 'Read More', 'storeup' ) );

		wp_link_pages( array(
			'before'      => '<div class="page-links"><span class="page-links-title">' . esc_html__( 'Pages:', 'storeup' ) . '</span>',
			'after'       => '</div>',
			'link_before' => '<span>',
			'link_after'  => '</span>',
		));
	} ?>
	<?php if ( is_single() ) { the_tags(); } ?>
	</div><!-- .entry-content -->
	</div><!-- .iva-post-content -->
</article><!-- /post-<?php the_ID();?> -->
<?php
