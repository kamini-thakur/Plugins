<?php
/*
Template Name: Blog
*/
?>
<?php get_header(); ?>
	<div id="primary" class="pagemid">
		<div class="inner">
		<main class="content-area" role="main">
			<div class="entry-content-wrapper clearfix">

				<?php
				$storeup_blog_cats = '';
				if ( is_array( $storeup_blog_all_cats = get_option( 'storeup_blog_cats' ) ) && count( $storeup_blog_all_cats ) > 0 ) {
					$storeup_blog_cats = implode( ', ', $storeup_blog_all_cats );
				}
				if ( get_query_var( 'paged' ) ) {
					$paged = get_query_var( 'paged' );
				} elseif ( get_query_var( 'page' ) ) {
					$paged = get_query_var( 'page' );
				} else {
					$paged = 1;
				}
				global $wp_query;
				$temp = $wp_query;
				$wp_query = null;
				$storeup_blog_args = array(
					'cat'   => $storeup_blog_cats,
					'paged' => $paged,
				);
				$wp_query = new WP_Query( $storeup_blog_args );
				?>

				<?php if ( $wp_query->have_posts() ) : while ( $wp_query->have_posts() ) :  $wp_query->the_post(); ?>
				<?php get_template_part( 'template-parts/content', get_post_format() ); ?>
				<?php endwhile; ?>

				<?php
				if ( function_exists( 'storeup_pagination' ) ) {
					storeup_pagination();
				}?>

				<?php else : ?>

				<p><?php esc_html_e( 'Apologies, but no results were found for the requested archive. Perhaps searching will help find a related post.', 'storeup' ); ?></p>
				<?php get_search_form(); ?>

				<?php endif; ?>
				<?php wp_reset_postdata();  ?>

				</div>
			</main><!-- .content-area -->

			<?php if ( storeup_generator( 'storeup_sidebar_option', $post->ID ) !== 'fullwidth' ) { get_sidebar(); } ?>
			<!-- .sidebar -->

			<div class="clear"></div>

		</div><!-- .inner -->
	</div><!-- .pagemid -->
<?php
get_footer();
