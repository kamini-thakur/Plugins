<?php
// Search Input
?>
<div class="search-box">
	<form method="get" ="<?php echo esc_url( home_url( '/' ) ); ?>" role="search">
		<input type="text" size="15" class="search-field" name="s" id="s" value="<?php echo esc_attr( get_search_query() ); ?>" placeholder="<?php esc_html_e( 'Search here...', 'storeup' ); ?>"/>
	</form>
</div>
<?php
