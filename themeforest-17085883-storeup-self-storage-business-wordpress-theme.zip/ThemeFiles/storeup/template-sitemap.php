<?php
/*
Template Name: Site Map
*/
?>
<?php get_header(); ?>
	<div id="primary" class="pagemid">
		<div class="inner">
			<div class="content-area">

					<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
					<?php the_content(); ?>
					<?php endwhile; ?>
					<?php endif; ?>

					<div class="one_fourth">
						<h3><?php esc_html_e( 'Pages', 'storeup' ); ?></h3>
						<ul class="sitemap">
						<?php $storeup_args = array( 'title_li' => '', 'depth' => 0 ); ?>
						<?php wp_list_pages( $storeup_args ); ?>
						</ul>
					</div>

					<div class="one_fourth">
						<h3><?php esc_html_e( 'Feeds', 'storeup' ); ?></h3>
						<ul class="sitemap">
							<li><a title="<?php esc_attr_e( 'Main RSS', 'storeup' ); ?>" href="<?php bloginfo( 'rss2_url' ); ?>"><?php esc_html_e( 'Main RSS', 'storeup' ); ?></a></li>
							<li><a title="<?php esc_attr_e( 'Comment Feed', 'storeup' ); ?>" href="<?php bloginfo( 'comments_rss2_url' ); ?>"><?php esc_html_e( 'Comment Feed', 'storeup' ); ?></a></li>
						</ul>
					</div>

					<div class="one_fourth">
						<h3><?php esc_html_e( 'Categories', 'storeup' ); ?></h3>
						<ul class="sitemap">
						<?php $storeup_args = array( 'title_li' => '' ); ?>
						<?php wp_list_categories( $storeup_args ); ?>
						</ul>
					</div>

					<div class="one_fourth last">
						<h3><?php esc_html_e( 'Archives', 'storeup' ); ?></h3>
						<ul class="sitemap">
							<?php wp_get_archives( 'type=monthly&show_post_count=true' ); ?>
						</ul>
					</div>
			</div><!-- .content-area -->

			<?php if ( storeup_generator( 'storeup_sidebar_option',$post->ID ) !== 'fullwidth' ) { get_sidebar(); } ?>
			<!-- #sidebar -->

			<div class="clear"></div>

		</div><!-- .inner -->
	</div><!-- .pagemid -->
<?php 
get_ooter();
