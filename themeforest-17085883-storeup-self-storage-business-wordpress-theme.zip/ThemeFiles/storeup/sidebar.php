<?php
// Sidebar
?>
<div id="sidebar">
<div class="content widget-area">
<?php
$storeup_widget = '';
/**
 * Check if widget pages are there
 * then display opted widgets for that page's sidebar
 * else display default sidebar
 */
if ( ! is_archive() || ! is_search() ) {
	$storeup_widgets = get_post_meta( get_the_ID(), 'storeup_custom_widget', true );
	$storeup_widget = strtolower( preg_replace( '/\s+/', '-',$storeup_widgets ) );
	//loop through the widget pages
}
/**
 * If current page falls under widget pages
 * then display sidebar widgets accordingly
 * Otherwise display default widgets
 */

if ( $storeup_widget && is_active_sidebar( 'sidebar-' . $storeup_widget ) ) {
	dynamic_sidebar( 'sidebar-' . $storeup_widget );
} else {
	if ( is_active_sidebar( 'defaultsidebar' ) ) {
		dynamic_sidebar( 'defaultsidebar' );
	}
}
?>
</div><!-- .content widget-area -->
</div><!-- #sidebar -->
<?php
