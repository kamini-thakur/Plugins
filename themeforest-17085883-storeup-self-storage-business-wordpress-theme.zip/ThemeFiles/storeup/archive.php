<?php
/**
 * The template for displaying Archive pages
 *
 * Used to display archive-type pages if nothing more specific matches a query.
 * For example, puts together date-based pages if no date.php file exists.
 *
 * @link http://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 */

get_header(); ?>

	<div id="primary" class="pagemid">
		<div class="inner">

			<main class="content-area">
				<div class="entry-content-wrapper clearfix">

					<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
					<?php get_template_part( 'template-parts/content', get_post_format() );  ?>
					<?php endwhile; ?>

					<?php
					// Pagination
					if ( function_exists( 'storeup_pagination' ) ) {
						storeup_pagination();
					}
					?>

					<?php else : ?>

					<p><?php esc_html_e( 'Apologies, but no results were found for the requested archive. Perhaps searching will help find a related post.', 'storeup' ); ?></p>

					<?php get_search_form(); ?>

					<?php endif;?>

				</div><!-- .entry-content-wrapper-->
			</main><!-- .content-area -->

			<?php get_sidebar(); ?>

		</div><!-- inner -->
	</div><!-- #primary.pagemid -->

<?php
get_footer();
