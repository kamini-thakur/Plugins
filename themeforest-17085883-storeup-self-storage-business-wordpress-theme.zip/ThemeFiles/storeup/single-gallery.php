<?php
/**
 * The Header for our theme.
 * Includes the header.php template file.
 */

get_header(); ?>
	<div id="primary" class="pagemid">
	<div class="inner">

		<div class="content-area">
		<div class="entry-content-wrapper clearfix">

			<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>

				<div <?php post_class();?> id="post-<?php the_ID(); ?>">

				<?php
				$storeup_gallery_venue	= get_post_meta( $post->ID, 'storeup_gallery_venue', true );
				$storeup_gallery_list	= get_post_meta( $post->ID, 'storeup_gallery_upload', false );
				$storeup_gallery_caption = get_option( 'storeup_single_gallery_imagecaption' );
				$storeup_images_perpage = get_option( 'storeup_single_gallery_limits' ) ? get_option( 'storeup_single_gallery_limits' ) : '5';
				$storeup_pagination 	= get_option( 'storeup_single_gallery_pagination' );

				$out = '';
				$storeup_image_count = 0;
				$storeup_gallery_upload_img = array();

				echo '<div class="custompost_entry">';
				echo '<div class="custompost_details">';

				if ( has_post_thumbnail() ) {
					echo '<h2 class="gallery-title "><span>' . esc_html( $storeup_gallery_venue ) . '</span></h2>';
				}
				if ( ! empty( $storeup_gallery_list ) ) {
					foreach ( $storeup_gallery_list as $storeup_attachment_id ) {
						$storeup_image_attributes = wp_get_attachment_image_src( $storeup_attachment_id, 'full' ); // returns an array
						if ( ! empty( $storeup_image_attributes [0] ) ) {
							$storeup_image_count++;
							$storeup_gallery_upload_img[] = $storeup_attachment_id;
						}
					}
					if ( 'on' === $storeup_pagination ) {
						$storeup_page_count	 	= ceil( $storeup_image_count / $storeup_images_perpage );
						$storeup_page_gallery 	= isset( $_GET['page'] ) ? $_GET['page'] : '';
						$storeup_current_page 	= intval( $storeup_page_gallery );

						if ( get_query_var( 'paged' ) ) {
							$storeup_current_page = get_query_var( 'paged' );
						} elseif ( get_query_var( 'page' ) ) {
							$storeup_current_page = get_query_var( 'page' );
						} else {
							$storeup_current_page = 1;
						}
						if ( empty( $storeup_current_page ) || $storeup_current_page <= 0 ) {
							$storeup_current_page = 1;
						}

						$storeup_max_image = $storeup_current_page * $storeup_images_perpage;
						$storeup_min_image = ( $storeup_current_page - 1 ) * $storeup_images_perpage;

						if ( $storeup_page_count > 1 ) {
							$storeup_page_link		 = get_permalink();
							$storeup_page_link_perma = true;

							if ( false !== strpos( $storeup_page_link, '?' ) ) {
								$storeup_page_link_perma = false;
							}

							$storeup_gplist = '<div class="clear"></div><div class="pagination pagination2">' . esc_html__( 'Pages', 'storeup' ) . '&nbsp;';

							for ( $j = 1; $j <= $storeup_page_count; $j++ ) {
								if ( $j == $storeup_current_page ) {
									$storeup_gplist .= '<span class="current"> ' . $j . '</span>';
								} else {
									$storeup_gplist .= '<a class="inactive" href="' . esc_url( $storeup_page_link . ( ( $storeup_page_link_perma?'?':'&amp;' ) ) . 'page=' . $j ) . '">' . $j . '</a>';
								}
							}
							$storeup_gplist .= '</div>';
						} else {
							$storeup_gplist = '';
						}
						if ( $storeup_gallery_list != '' ) {
							$i = $k = 0;
							$out .= '<div class="gallery-postimg-wrap">';
							foreach ( $storeup_gallery_upload_img as $storeup_attachment_id ) {

								if ( $k >= $storeup_min_image && $k < $storeup_max_image ) {

									$storeup_attachment 		= get_post( $storeup_attachment_id );

									$storeup_image_attributes 	= wp_get_attachment_image_src( $storeup_attachment_id, 'full' ); // returns an array
									$storeup_alt 				= $storeup_attachment->post_title ;
									$storeup_caption 			= $storeup_attachment->post_excerpt ;

									$out .= '<div class="gallery-postimg port_img">';
									$out .= '<a  href="' . esc_url( $storeup_image_attributes[0] ) . '" title="' . $storeup_alt . '" data-rel="prettyPhoto[gal-mixed]">';
									$out .= storeup_img_resize( '', $storeup_image_attributes[0], '180', '180', '', $storeup_alt );
									$out .= '</a>';
									if ( $storeup_caption && 'on' === $storeup_gallery_caption ) {
										$out .= '<span class="gallery-caption">' . $storeup_caption . '</span>';
									}
									$out .= '</div>';
								}
								$k++;
							}
							$out .= '</div>';
						}
						$out .= $storeup_gplist;
					} else {
						if ( $storeup_gallery_list != '' ) {
							$out .= '<div class="gallery-postimg-wrap">';
							foreach ( $storeup_gallery_upload_img as $storeup_attachment_id ) {
								$storeup_attachment = get_post( $storeup_attachment_id );
								if ( count( $storeup_attachment ) > 0 ) {

									$storeup_image_attributes = wp_get_attachment_image_src( $storeup_attachment_id, 'full' ); // returns an array
									$storeup_alt			  = $storeup_attachment->post_title;
									$storeup_caption 		  = $storeup_attachment->post_excerpt;

									$out .= '<div class="gallery-postimg port_img">';
									$out .= '<a href="' . esc_url( $storeup_image_attributes[0] ) . '" title="' . $storeup_alt . '"  data-rel="prettyPhoto[gal-mixed]" >';
									$out .= storeup_img_resize( '',$storeup_image_attributes[0],'180','180','',$storeup_alt );
									$out .= '</a>';
									if ( $storeup_caption && $storeup_gallery_caption != 'on' ) {
										$out .= '<span class="gallery-caption">' . $storeup_caption . '</span>';
									}
									$out .= '</div>';
								}
							}
							$out .= '</div>';
						}
					}
					echo wp_kses( $out, array(
										'a'  => array(
											'href' => true,
											'data-rel' => true,
											'class' => true,
											'title' => true,
										),
										'img' => array(
											'src' => true,
											'alt' => true,
											'title' => true,
											'class' => true,
										),
										'div'    => array(
											'class' => true,
											'id' => true,
										),
										'span'    => array(
											'class' => true,
										),
					) );
					}
				echo '</div>'; //custompost_details
				echo '</div>'; //custompost_entry -->
				?>
				<div class="demospace" style="height:20px;"></div>

				<?php the_content(); ?>

				<?php echo get_template_part( 'share', 'link' ); ?>

				<div class="demospace" style="height:20px;"></div>

				</div>

				<!-- #post-<?php the_ID();?> -->
				<?php endwhile; ?>
				<?php else : ?>
				<?php '<p>' . esc_html__( 'Sorry, no projects matched your criteria.', 'storeup' ) . '</p>';?>
				<?php endif; ?>

			<?php comments_template( '', true ); ?>

			</div><!-- .entrycontent-wrapper -->
			</div><!-- .content-area -->

			<?php if ( storeup_generator( 'storeup_sidebar_option', $post->ID ) != 'fullwidth' ) { get_sidebar(); } ?>

	</div><!-- inner -->
	</div><!-- #primary.pagemid -->

<?php
get_footer();
