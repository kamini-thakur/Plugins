<?php
	/**
	 * defines custom sidebar widget based on custom option
	 */
	$storeup_default_date = get_option( 'storeup_date_format' ) ? get_option( 'storeup_date_format' ) :'Y/m/d';
	$this->meta_box[] = array(
		'id'		=> 'booking-meta-box',
		'title'		=> esc_html__( 'Booking Options', 'storeup' ),
		'context'	=> 'normal',
		'page'		=> array( 'booking' ),
		'priority'	=> 'core',
		'fields'	=> array(	
			array(
				'name'	=> esc_html__( 'Phone No', 'storeup' ),
				'desc'	=> esc_html__( 'Enter Phoneno.', 'storeup' ),
				'id'	=> 'storeup_bk_phoneno',
				'class' => '',
				'std'	=> '',
				'type'	=> 'text',
			),
			array(
				'name'	=> esc_html__( 'Email', 'storeup' ),
				'desc'	=> esc_html__( 'Enter Email.', 'storeup' ),
				'id'	=> 'storeup_bk_email',
				'class' => '',
				'std'	=> '',
				'type'	=> 'text',
			),
			array(
				'name'	=> esc_html__( 'Street Address', 'storeup' ),
				'desc'	=> esc_html__( 'Enter Address.', 'storeup' ),
				'id'	=> 'storeup_bk_address',
				'class' => '',
				'std'	=> '',
				'type'	=> 'textarea',
			),
			array(
				'name'	=> esc_html__( 'Zipcode', 'storeup' ),
				'desc'	=> esc_html__( 'Enter Zipcode.', 'storeup' ),
				'id'	=> 'storeup_bk_zipcode',
				'class' => '',
				'std'	=> '',
				'type'	=> 'text',
			),
			array(
				'name'	=> esc_html__( 'Location', 'storeup' ),
				'desc'	=> esc_html__( 'Enter Location.', 'storeup' ),
				'id'	=> 'storeup_bk_location',
				'std'	=> '',
				'class' => 'select300',
				'options'=> $this->storeup_get_vars( 'locations' ),
				'type'	=> 'text',
			),
			array(
				'name'	=> esc_html__( 'Units & Pricing', 'storeup' ),
				'desc'	=> esc_html__( 'Enter units & price.', 'storeup' ),
				'id'	=> 'storeup_bk_price',
				'std'	=> '',
				'type'	=> 'text'
			),
			array(
				'name'	=> esc_html__( 'Additional Notes','storeup' ),
				'desc'	=> esc_html__( 'Enter notes.', 'storeup' ),
				'id'	=> 'storeup_bk_message',
				'type'	=> 'textarea',
				'std'	=> '',
			),
			array(
				'name'	=> esc_html__( 'Booking Date', 'storeup' ),
				'desc'	=> esc_html__( 'Choose Offers.', 'storeup' ),
				'id'	=> 'storeup_bk_date',
				'std'	=> date( $storeup_default_date ),
				'type'	=> 'dateformat',
				'inputsize' => '',
			),
			array(
				'name'	=> esc_html__( 'Booking Status', 'storeup' ),
				'desc'	=> '',
				'id'	=> 'storeup_bk_status',
				'type'	=> 'select',
				'class'	=> 'select300',
				'std'	=> 'confirmed',
				'options'=> array(
					'unconfirmed'  => esc_html__( 'UnConfirmed', 'storeup' ),
					'confirmed'    => esc_html__( 'Confirmed', 'storeup' ),
					'cancelled'    => esc_html__( 'Cancelled', 'storeup' ),
				),
			),
		),
	);
?>