<?php
add_filter('add_units_pricing','storeup_units_pricing');
function storeup_units_pricing( $options ) {

	$output  = '<div class="at_units_pricing_wrap">';
	$output .= '<div class="at_units_pricing_count">';
	$output .= '<table id="at_units_table" class="widefat">';
	$output .= '<tbody>';

	if ( $options['meta'] == '' or empty( $options['meta'] ) ) {
		$output .= '<tr class="at-row-sort">';
		$output .= '<td><div class="at-units-pricing">';

		$output .= '<div class="at-field-row">';
		$output .= '<div class="at-field">
		<label>' . esc_html__( 'Item ID', 'storeup' ) . '</label>
		<input name="' . $options['field_id'] . '_item_id[]" class="at-item-id" type="text" value=""></div>';
		$output .= '<div class="at-field">
		<label>' . esc_html__( 'Height', 'storeup' ) . '</label>
		<input class="at-height" name="' . $options['field_id'] . '_height[]"  type="text" value=""></div>';
		$output .= '<div class="at-field">
		<label>' . esc_html__( 'Length', 'storeup' ) . '</label>
		<input class="at-length" name="' . $options['field_id'] . '_length[]" type="text" value=""></div>';
		$output .= '</div>';

		$output .= '<div class="at-field-row">';
		$output .= '<div class="at-field">
		<label>' . esc_html__( 'Rate', 'storeup' ) . '</label>
		<input name="' . $options['field_id'] . '_rate[]" class="at-rate" type="text" value=""></div>';
		$output .= '<div class="at-field">
		<label>' . esc_html__( 'Offer Rate', 'storeup' ) . '</label>
		<input name="' . $options['field_id'] . '_ofr_rate[]" class="at-ofr-rate" type="text" value=""></div>';
		$output .= '<div class="at-field">
		<label>' . esc_html__( 'Offer Description', 'storeup' ) . '</label>
		<input name="' . $options['field_id'] . '_ofr_desc[]" class="at-ofr-desc" type="text" value=""></div>';
		$output .= '</div>';

		$output .= '<div class="at-field-row">';
		$output .= '<div class="at-feature-field">
		<label>' . esc_html__( 'Features', 'storeup' ) . '</label>
		<textarea class="at-features" name="' . $options['field_id'] . '_features[]" row="10"></textarea></div>';
		$output .= '</div>';
		$output .= '<div class="at-field-row">';
		$output .= '<label for="climate"><input size="50" name="' . $options['field_id'] . '_climatecontrol[]" type="checkbox" id="climate" />' . esc_html__( 'Climate Control', 'storeup' ) . '</label>';
		$output .= '<label for="non-climate"><input size="50" name="' . $options['field_id'] . '_non_climatecontrol[]" type="checkbox" id="non-climate" />' . esc_html__( 'Non-Climate Control', 'storeup' ) . '</label>';
		$output .= '<label for="alarm"><input size="50" name="' . $options['field_id'] . '_alarm[]" type="checkbox" id="alarm"/>' . esc_html__( 'Alarm', 'storeup' ) . '</label>';
		$output .= '<label for="inside"><input size="50" name="' . $options['field_id'] . '_inside[]" type="checkbox" id="inside" />' . esc_html__( 'Inside', 'storeup' ) . '</label>';
		$output .= '<label for="outstairs"><input size="50" name="' . $options['field_id'] . '_outside[]" type="checkbox" id="outstairs" />' . esc_html__( 'Outside', 'storeup' ) . '</label>';
		$output .= '<label for="upstairs"><input size="50" name="' . $options['field_id'] . '_upstairs[]" type="checkbox" id="upstairs" />' . esc_html__( 'Upstairs', 'storeup' ) . '</label>';
		$output .= '<label for="downstairs"><input size="50" name="' . $options['field_id'] . '_downstairs[]" type="checkbox" id="downstairs" />' . esc_html__( 'Downstairs', 'storeup' ) . '</label>';
		$output .= '</div>';

		$output .= '<div class="at-field">';
		$output .= '<a title="' . esc_html__( 'Delete button', 'storeup' ) . '" href="#" class="button button-primary red-button">' . esc_html__( 'Delete', 'storeup' ) . '</a></div>';
		$output .= '</div>';

		$output .= '</div>';
		$output .= '</td>';
		$output .= '</tr>';
	} else {
		$i = 0;
		foreach ( $options['meta'] as $optionvals ) {
			$item_id_val = ! empty( $optionvals['item_id'] ) ? $optionvals['item_id'] : '';
			$output .= '<tr class="at-row-sort">';
			$output .= '<td><div class="at-units-pricing">';
			$output .= '<div><label>' . esc_html__( 'Height', 'storeup' ) . '</label><input size="50" name="' . $options['field_id'] . '_height[]" class="at-height" type="text"   value="' . esc_attr( $optionvals['height'] ) . '" /></div>';
			$output .= '<div><label>' . esc_html__( 'Length', 'storeup' ) . '</label><input size="50" name="' . $options['field_id'] . '_length[]" class="at-length" type="text"   value="' . esc_attr( $optionvals['length'] ) . '" /></div>';
			$output .= '<div><label>' . esc_html__( 'Features', 'storeup' ) . '</label><textarea name="' . $options['field_id'] . '_features[]" class="at-features"  cols="47" row="10" />' . $optionvals['features'] . '</textarea></div>';
			$output .= '<div><label>' . esc_html__( 'Rate', 'storeup' ) . '</label><input size="50" name="' . $options['field_id'] . '_rate[]" class="at-rate" type="text"   value="' . $optionvals['rate'] . '"/></div>';
			$output .= '<div><label>' . esc_html__( 'Offer Rate', 'storeup' ) . '</label><input size="50" name="' . $options['field_id'] . '_ofr_rate[]" class="at-ofr-rate" type="text"   value="' . $optionvals['ofr_rate'] . '"/></div>';
			$output .= '<div><label>' . esc_html__( 'Item ID', 'storeup' ) . '</label><input size="50" name="' . $options['field_id'] . '_item_id[]" class="at-item-id" type="text"   value="' . $item_id_val . '"/></div>';			$output .= '<div><label>' . esc_html__( 'Offer Description', 'storeup' ) . '</label><input size="50" name="' . $options['field_id'] . '_ofr_desc[]" class="at-ofr-desc" type="text" value="' . $optionvals['ofr_desc'] . '"/></div>';

			$cc_checked = $al_checked = $in_checked = $up_checked = $non_cc_checked = $out_checked = $down_checked = '';
			if ( ! empty( $optionvals['climatecontrol'] ) ) {
				if ( $optionvals['climatecontrol'] == 'on' ) {
					$cc_checked = 'checked="checked"';
				} else {
					$cc_checked = '';
				}
			}
			if ( ! empty( $optionvals['alarm'] ) ) {
				if ( $optionvals['alarm'] == 'on' ) {
					$al_checked = 'checked="checked"';
				} else {
					$al_checked = '';
				}
			}
			if ( ! empty( $optionvals['non_climatecontrol'] ) ) {
				if ( $optionvals['non_climatecontrol'] == 'on' ) {
					$non_cc_checked = 'checked="checked"';
				} else {
					$non_cc_checked = '';
				}
			}
			if ( ! empty( $optionvals['inside'] ) ) {
				if ( $optionvals['inside'] == 'on' ) {
					$in_checked = 'checked="checked"';
				} else {
					$in_checked = '';
				}
			}
			if ( ! empty( $optionvals['outside'] ) ) {
				if ( $optionvals['outside'] == 'on' ) {
					$out_checked = 'checked="checked"';
				} else {
					$out_checked = '';
				}
			}
			if ( ! empty( $optionvals['downstairs'] ) ) {
				if ( $optionvals['downstairs'] == 'on' ) {
					$down_checked = 'checked="checked"';
				} else {
					$down_checked = '';
				}
			}
			if ( ! empty( $optionvals['upstairs'] ) ) {
				if ( $optionvals['upstairs'] == 'on' ) {
					$up_checked = 'checked="checked"';
				} else {
					$up_checked = '';
				}
			}

			$output .= '<div><label>' . esc_html__( 'Climate Control', 'storeup' ) . '</label><input size="50" name="' . $options['field_id'] . '_climatecontrol[' . $i . '] " type="checkbox" ' . $cc_checked . '/></div>';
			$output .= '<div><label>' . esc_html__( 'Non-Climate Control', 'storeup' ) . '</label><input size="50" name="' . $options['field_id'] . '_non_climatecontrol[' . $i . '] " type="checkbox" ' . $non_cc_checked . '/></div>';
			$output .= '<div><label>' . esc_html__( 'Alarm', 'storeup' ) . '</label><input size="50" name="' . $options['field_id'] . '_alarm[' . $i . '] " type="checkbox" ' . $al_checked . '/></div>';
			$output .= '<div><label>' . esc_html__( 'Inside', 'storeup' ) . '</label><input size="50" name="' . $options['field_id'] . '_inside[' . $i . '] " type="checkbox" ' . $in_checked . '/></div>';
			$output .= '<div><label>' . esc_html__( 'Outside', 'storeup' ) . '</label><input size="50" name="' . $options['field_id'] . '_outside[' . $i . '] " type="checkbox" ' . $out_checked . '/></div>';
			$output .= '<div><label>' . esc_html__( 'Upstairs', 'storeup' ) . '</label><input size="50" name="' . $options['field_id'] . '_upstairs[' . $i . '] " type="checkbox" ' . $up_checked . '/></div>';
			$output .= '<div><label>' . esc_html__( 'Downstairs', 'storeup' ) . '</label><input size="50" name="' . $options['field_id'] . '_downstairs[' . $i . '] " type="checkbox" ' . $down_checked . '/></div>';
			$output .= '<div><label>&nbsp;</label><a title="' . esc_html__( 'Delete button', 'storeup' ) . '" href="#" class="button button-primary red-button">' . esc_html__( 'Delete', 'storeup' ) . '</a></div>';
			$output .= '</div></td>';
			$output .= '</tr>';
			$i++;
		}
	}
	$output .= '</tbody>';
	$output .= '</table>';
	$output .= '</div>';
	$output .= '</div>';
	$output .= '<div class="clearfix" style="height: 10px;"></div>';
	$output .= '<a href="#" id="add_units_pricing" class="add button button-primary green-button button-hero">' . esc_html__( 'Add', 'storeup' ) . '</a>';
	return $output;
}
add_filter( 'add_googlemap', 'storeup_googlemap' );
function storeup_googlemap( $storeup_meta_options ) {

	$output = '';
	$lat = $lng = $address = $streetno = $route = $city = $state = $zip_code = $country = '';
	$fieldid 	= $storeup_meta_options['field_id'];
	$meta 		= $storeup_meta_options['meta'];

	if ( ! empty( $meta ) ) {
		$lat 			= $meta['0']['lat'];
		$lng			= $meta['0']['lng'];
		$address		= $meta['0']['address'];
		$streetno  		= $meta['0']['streetno'];
		$route			= $meta['0']['route'];
		$city	        = $meta['0']['city'];
		$state			= $meta['0']['state'];
		$zip_code       = $meta['0']['zip_code'];
		$country		= $meta['0']['country'];
	}

	$output .= '<div class ="mapdisplay">';
	$output .= '<div id="gmap_errormessage"></div>';
	$output .= '<label class="loc_labels">' . esc_html__( 'Address', 'storeup' ) . '</label>';
	$output .= '<div class="loc_input">';
	$output .= '<input type="text" id="iva_loc_address"  name="' . $fieldid . '_address" value="' . $address . '" size="30"/>';
	$output .= '</div>';

	$output .= '<div id="iva_loc_map_canvas" style="width:800px;height:450px;border:1px solid #999;"></div>';

	$output .= '<input type="hidden" id="iva_loc_lat" name="' . $fieldid . '_lat" value="' . $lat . '" readonly />';
	$output .= '<input type="hidden"  id="iva_loc_lng" name="' . $fieldid . '_lng" value="' . $lng . '" readonly />';
	$output .= '</div>';//.mapdisplay

	return $output;
}
