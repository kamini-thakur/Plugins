<?php
add_filter( 'customlocalization_themeoptions', 'storeup_cpt_localization_options' );
function storeup_cpt_localization_options( $storeup_options ) {

		global $storeup_options;

		// Labels
		//---------------------------------------------------------------------------------------------------
		$storeup_options[] = array( 'name' => esc_html__( 'Storeup Labels','storeup' ), 'desc' => esc_html__( '<h3>Storeup Labels</h3> Text translation for differnt sections.','storeup' ), 'type' => 'subnav' );
		//---------------------------------------------------------------------------------------------------
		$storeup_options[] = array(
									'name'	=> esc_html__( 'Click Here to View All Units Text','storeup' ),
									'desc'	=> esc_html__( 'Custom text which appears on taxonomy page:cities','storeup' ),
									'id'	=> 'storeup_cities_tx_btn_txt',
									'std'	=> '',
									'type'	=> 'text',
									'inputsize' => '300',
							);
		$storeup_options[] = array(
									'name'	=> esc_html__( 'Size Text','storeup' ),
									'desc'	=> esc_html__( 'Custom text which appears on units & pricing section','storeup' ),
									'id'	=> 'storeup_up_size_txt',
									'std'	=> '',
									'type'	=> 'text',
									'inputsize' => '300',
							);
		$storeup_options[] = array(
									'name'	=> esc_html__( 'Features Text','storeup' ),
									'desc'	=> esc_html__( 'Custom text which appears on units & pricing section','storeup' ),
									'id'	=> 'storeup_up_features_txt',
									'std'	=> '',
									'type'	=> 'text',
									'inputsize' => '300',
							);
		$storeup_options[] = array(
									'name'	=> esc_html__( 'Monthly Rate Text','storeup' ),
									'desc'	=> esc_html__( 'Custom text which appears on units & pricing section','storeup' ),
									'id'	=> 'storeup_up_monthlyrate_txt',
									'std'	=> '',
									'type'	=> 'text',
									'inputsize' => '300',
							);
		$storeup_options[] = array(
									'name'	=> esc_html__( 'Available Text','storeup' ),
									'desc'	=> esc_html__( 'Custom text which appears on units & pricing section','storeup' ),
									'id'	=> 'storeup_up_available_txt',
									'std'	=> '',
									'type'	=> 'text',
									'inputsize' => '300',
							);
		$storeup_options[] = array(
									'name'	=> esc_html__( 'Climatecontrol Text','storeup' ),
									'desc'	=> esc_html__( 'Custom text which appears on units & pricing section','storeup' ),
									'id'	=> 'storeup_climatecontrol_txt',
									'std'	=> '',
									'type'	=> 'text',
									'inputsize' => '300',
							);
		$storeup_options[] = array(
									'name'	=> esc_html__( 'Non Climatecontrol Text','storeup' ),
									'desc'	=> esc_html__( 'Custom text which appears on units & pricing section','storeup' ),
									'id'	=> 'storeup_non_climatecontrol_txt',
									'std'	=> '',
									'type'	=> 'text',
									'inputsize' => '300',
							);
		$storeup_options[] = array(
									'name'	=> esc_html__( 'Alarm Text','storeup' ),
									'desc'	=> esc_html__( 'Custom text which appears on units & pricing section','storeup' ),
									'id'	=> 'storeup_alaram_txt',
									'std'	=> '',
									'type'	=> 'text',
									'inputsize' => '300',
							);
		$storeup_options[] = array(
									'name'	=> esc_html__( 'Inside Text','storeup' ),
									'desc'	=> esc_html__( 'Custom text which appears on units & pricing section','storeup' ),
									'id'	=> 'storeup_inside_txt',
									'std'	=> '',
									'type'	=> 'text',
									'inputsize' => '300',
							);
		$storeup_options[] = array(
									'name'	=> esc_html__( 'Outside Text','storeup' ),
									'desc'	=> esc_html__( 'Custom text which appears on units & pricing section','storeup' ),
									'id'	=> 'storeup_outside_txt',
									'std'	=> '',
									'type'	=> 'text',
									'inputsize' => '300',
							);
		$storeup_options[] = array(
									'name'	=> esc_html__( 'Downstairs Text','storeup' ),
									'desc'	=> esc_html__( 'Custom text which appears on units & pricing section','storeup' ),
									'id'	=> 'storeup_downstairs_txt',
									'std'	=> '',
									'type'	=> 'text',
									'inputsize' => '300',
							);
		$storeup_options[] = array(
									'name'	=> esc_html__( 'Upstairs Text','storeup' ),
									'desc'	=> esc_html__( 'Custom text which appears on units & pricing section','storeup' ),
									'id'	=> 'storeup_upstairs_txt',
									'std'	=> '',
									'type'	=> 'text',
									'inputsize' => '300',
							);
		$storeup_options[] = array(
									'name'	=> esc_html__( 'Reserve Now Text','storeup' ),
									'desc'	=> esc_html__( 'Custom text which appears on units & pricing section','storeup' ),
									'id'	=> 'storeup_reserve_btn_txt',
									'std'	=> '',
									'type'	=> 'text',
									'inputsize' => '300',
							);
		// Form Labels
		//---------------------------------------------------------------------------------------------------
		$storeup_options[] = array( 'name' => esc_html__( 'Form Labels','storeup' ), 'desc' => esc_html__( '<h3>Form Labels</h3> Text translation for the Booking form section.','storeup' ), 'type' => 'subnav' );
		//---------------------------------------------------------------------------------------------------
		$storeup_options[] = array(
									'name'	=> esc_html__( 'Form Heading1 Text','storeup' ),
									'desc'	=> esc_html__( 'Custom text which appears on Booking Form','storeup' ),
									'id'	=> 'storeup_bk_heading1_txt',
									'std'	=> '',
									'type'	=> 'text',
									'inputsize' => '300',
							);
		$storeup_options[] = array(
									'name'	=> esc_html__( 'Form Heading2 Text','storeup' ),
									'desc'	=> esc_html__( 'Custom text which appears on Booking Form','storeup' ),
									'id'	=> 'storeup_bk_heading2_txt',
									'std'	=> '',
									'type'	=> 'text',
									'inputsize' => '300',
							);
		$storeup_options[] = array(
									'name'	=> esc_html__( 'Name Text','storeup' ),
									'desc'	=> esc_html__( 'Custom text which appears on Booking Form','storeup' ),
									'id'	=> 'storeup_bk_fnametxt',
									'std'	=> '',
									'type'	=> 'text',
									'inputsize' => '300',
							);
		$storeup_options[] = array(
									'name'	=> esc_html__( 'Phone Number Text','storeup' ),
									'desc'	=> esc_html__( 'Custom text which appears on Booking Form','storeup' ),
									'id'	=> 'storeup_bk_phonetxt',
									'std'	=> '',
									'type'	=> 'text',
									'inputsize' => '300',
							);
		$storeup_options[] = array(
									'name'	=> esc_html__( 'Email Text','storeup' ),
									'desc'	=> esc_html__( 'Custom text which appears on Booking Form','storeup' ),
									'id'	=> 'storeup_bk_emailtxt',
									'std'	=> '',
									'type'	=> 'text',
									'inputsize' => '300',
							);
		$storeup_options[] = array(
									'name'	=> esc_html__( 'Location Text','storeup' ),
									'desc'	=> esc_html__( 'Custom text which appears on Booking Form','storeup' ),
									'id'	=> 'storeup_bk_loc_txt',
									'std'	=> '',
									'type'	=> 'text',
									'inputsize' => '300',
							);
		$storeup_options[] = array(
									'name'	=> esc_html__( 'Units & Price Text','storeup' ),
									'desc'	=> esc_html__( 'Custom text which appears on Booking Form','storeup' ),
									'id'	=> 'storeup_bk_unit_price_txt',
									'std'	=> '',
									'type'	=> 'text',
									'inputsize' => '300',
							);
		$storeup_options[] = array(
									'name'	=> esc_html__( 'message text','storeup' ),
									'desc'	=> esc_html__( 'Custom text which appears on Booking Form','storeup' ),
									'id'	=> 'storeup_bk_message_txt',
									'std'	=> '',
									'type'	=> 'text',
									'inputsize' => '300',
							);

		$storeup_options[] = array(
									'name'	=> esc_html__( 'Address Text','storeup' ),
									'desc'	=> esc_html__( 'Custom text which appears on Booking Form','storeup' ),
									'id'	=> 'storeup_bk_address_txt',
									'std'	=> '',
									'type'	=> 'text',
									'inputsize' => '300',
							);
		$storeup_options[] = array(
									'name'	=> esc_html__( 'Zipcode Text','storeup' ),
									'desc'	=> esc_html__( 'Custom text which appears on Booking Form','storeup' ),
									'id'	=> 'storeup_bk_zipcode_txt',
									'std'	=> '',
									'type'	=> 'text',
									'inputsize' => '300',
								);
		$storeup_options[] = array(
									'name'	=> esc_html__( 'Captcha Text','storeup' ),
									'desc'	=> esc_html__( 'Custom text which appears on Booking Form','storeup' ),
									'id'	=> 'storeup_bk_captchatxt',
									'std'	=> '',
									'type'	=> 'text',
									'inputsize' => '300',
								);
		$storeup_options[] = array(
									'name'		=> esc_html__( 'Button Text','storeup' ),
									'desc'		=> esc_html__( 'Custom text which appears on Booking Form.','storeup' ),
									'id'		=> 'storeup_bk_buttontxt',
									'std'		=> '',
									'inputsize' => '300',
									'type'		=> 'text',
							);

		return $storeup_options;
}
