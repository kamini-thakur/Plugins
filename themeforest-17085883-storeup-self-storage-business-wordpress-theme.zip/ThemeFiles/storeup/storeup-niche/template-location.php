<?php
/**
 * Template Name: Locations
 **/
	get_header();
?>
<div id="primary" class="pagemid_section">
	<main class="content-area">
		<div class="entry-content-wrapper clearfix">
		<?php
		$template_id = $post->ID;
		// Get the content from page template.
		if ( have_posts() ) : while ( have_posts() ) : the_post();
				the_content();
			endwhile;
		endif;
		?>
		<?php
		$citi_names = get_categories( 'taxonomy=cities' );
		?>
		<div class="storeup-map-location">
			<div id="storeup-googlemap"></div>
			<div class="storeup-location-section">
				<div class="storeup-loc-overlay">
					<div class="storeup-loc-overlay-inner scrollbar" id="scrollbar-style">
						<div class="storeup-location-head">
							<div class="storeup-location-dropdown">
							<select name="iva_cities" id="iva_cities">
							<?php foreach ( $citi_names as $citi ) {
								echo '<option value=' . esc_attr( $citi->slug ) . '>' . esc_html( $citi->name ) . '</option>';
							}
							?>
							</select>
							</div>
						</div> <!-- .location-location-head -->
						<div class='iva_loc_display' style='display:none;'></div>
					</div> <!--  storeup-loc-overlayinner -->
				</div> <!-- storeup-loc-overlay end -->
			</div><!-- storeup-location-end -->
		</div><!-- storeup-map-location end -->
		</div><!-- .entry-content-wrapper -->
	</main><!-- .content-area -->

	<?php if ( storeup_generator( 'storeup_sidebar_option', $template_id ) !== 'fullwidth' ) { get_sidebar(); } ?>

	<div class="clear"></div>
</div><!-- .pagemid-section -->
<?php
get_footer();
