<?php

/**
 * The Header for our theme.
 * Includes the header.php template file.
 */

get_header(); ?>

	<div id="primary" class="pagemid">
		<div class="inner">
			<main class="content-area">
			<div class="entry-content-wrapper clearfix">
			<?php
			$storeup_orderby 			= get_option( 'storeup_location_orderby' ) ? get_option( 'storeup_location_orderby' ) : 'date';
			$storeup_order   			= get_option( 'storeup_location_order' ) ? get_option( 'storeup_location_order' ) : 'ASC';
			$storeup_pagination 		= get_option( 'storeup_location_pagination' );
			$storeup_cities_tx_btn_txt 	= get_option( 'storeup_cities_tx_btn_txt' ) ? get_option( 'storeup_cities_tx_btn_txt' ) : esc_html__( 'Click Here to View All Units', 'storeup' );

			if ( get_query_var( 'paged' ) ) {
				$paged = get_query_var( 'paged' );
			} elseif ( get_query_var( 'page' ) ) {
				$paged = get_query_var( 'page' );
			} else {
				$paged = 1;
			}
			if ( $storeup_pagination == 'on' ) {
				$storeup_loc_limit = get_option( 'storeup_location_limits' );
			} else {
				$storeup_loc_limit = '-1' ;
			}
			$storeup_taxonomy_loc_obj = $wp_query->get_queried_object();

			if ( $storeup_taxonomy_loc_obj ) {
				$args = array(
					'post_type'	=> 'location',
					'posts_per_page' => $storeup_loc_limit,
					'tax_query' => array(
							array(
								'taxonomy' => 'cities',
								'field' => 'id',
								'terms' => $storeup_taxonomy_loc_obj->term_id,
							),
					),
					'paged'		=> $paged,
					'orderby'	=> $storeup_orderby,
					'order'		=> $storeup_order,
				);
			}

			$storeup_location_query = new WP_Query( $args );

			$storeup_location_count = $storeup_location_query->post_count;
			if ( $storeup_location_query->have_posts() ) :

				echo '<h3 class="at-city-list-title">';
				printf( _n( 'We have %1$s facility near you!' , 'We have %1$s facilities near you!', $storeup_location_count, 'storeup' ), $storeup_location_count );
				echo '</h3>';

				while (  $storeup_location_query->have_posts() ) :  $storeup_location_query->the_post();

					$storeup_loc_map_details = get_post_meta( $post->ID, 'storeup_loc_map', true );
					if ( ! empty( $storeup_loc_map_details ) ) {
				    	$storeup_loc_address 	  = $storeup_loc_map_details['0']['address'];
						$storeup_loc_lattitudes   = $storeup_loc_map_details['0']['lat'];
						$storeup_loc_longitudes   = $storeup_loc_map_details['0']['lng'];
					}
					$storeup_loc_phno     	= get_post_meta( $post->ID, 'storeup_loc_phno', true );
					$storeup_loc_email		= get_post_meta( $post->ID, 'storeup_loc_email', true );

					echo '<div class="at-city-list">';
					echo '<div class="at-city-thumb">';
					if ( has_post_thumbnail() ) {
						echo storeup_img_resize( $post->ID, '', 120, 80, '', get_the_title() );
					} else {
						echo '<span class="at-city-empty-img"><i class="fa fa-picture-o fa-2x"></i></span>';
					}
					echo '</div>';
					echo '<div class="at-city-details">';
					echo '<span class="at-city-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark" title="' . get_the_title() . '">' . get_the_title() . '</a></span>';
					if ( $storeup_loc_address != '' ) {
						echo '<div class="at-city-addr">';
						echo '<span>' . esc_html( $storeup_loc_address ) . '</span>';
						echo '</div>';//.city-addr
					}
					if ( $storeup_loc_phno != '' ) {
						echo '<div class="at-city-phno">';
						echo '<i class="fa fa-phone fa-fw"></i><span>' . esc_html( $storeup_loc_phno ) . '</span>';
						echo '</div>';//.city-phno
					}
					echo '</div>';//.at-city-details
					echo '<div class="at-city-more">';
					echo '<a href="' . esc_url( get_permalink( get_the_id() ) ) . '" class="btn medium border rounded dark"><span>' . esc_html( $storeup_cities_tx_btn_txt ) . '</span></a>';
					echo '</div>';//.at-city-more
					echo '</div>';//.at-city-list
				?>
			<?php endwhile; ?>
			<?php wp_reset_postdata(); ?>
			<?php
			if ( $storeup_pagination == 'on' ) {
				if ( function_exists( 'storeup_pagination' ) ) {
					storeup_pagination();
				}
			} ?>
			<?php else : ?>
			<p><?php esc_html_e( 'Apologies, but no results were found for the requested archive. Perhaps searching will help find a related post.', 'storeup' ); ?></p>

			<?php get_search_form(); ?>

			<?php endif;?>

			</div><!-- .entry-content-wrapper-->
			</main><!-- .content-area -->

			<?php get_sidebar(); ?>

		</div><!-- inner -->
	</div><!-- #primary.pagemid -->

<?php
get_footer();
