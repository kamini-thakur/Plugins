<?php
add_action( 'wp_ajax_storeup_get_locations_by_cat', 'storeup_get_locations_by_cat' );
add_action( 'wp_ajax_nopriv_storeup_get_locations_by_cat', 'storeup_get_locations_by_cat' );
function storeup_get_locations_by_cat() {
	$storeup_loc_cat = $_POST['cat_slug'] ;
	if ( $storeup_loc_cat != '' ) {
		// Start the loop.
		$args = array(
			'post_type' => 'location',
			'posts_per_page' => -1,
			'tax_query' => array(
				array(
					'taxonomy' => 'cities',
					'field'    => 'slug',
					'terms'    => $storeup_loc_cat,
					'post_status' => 'publish',
				),
			),
		);
	} else {
		$args = array(
			'post_type'      => 'location',
			'posts_per_page' => -1,
			'post_status'    => 'publish',
		);
	}
	$loop = new WP_Query( $args );
	if ( $loop->have_posts() ) : while ( $loop->have_posts() ) : $loop->the_post();
			global $post;

			$storeup_loc_address = $storeup_loc_lattitudes = $storeup_loc_longitudes = '';
			$storeup_loc_map_details = get_post_meta( $post->ID, 'storeup_loc_map', true );
			$storeup_loc_posttitle 	= get_the_title( $post->ID );
			$storeup_loc_postlink 	= get_the_permalink();
			if ( ! empty( $storeup_loc_map_details ) ) {
			    $storeup_loc_address 	  = $storeup_loc_map_details['0']['address'];
				$storeup_loc_lattitudes   = $storeup_loc_map_details['0']['lat'];
				$storeup_loc_longitudes   = $storeup_loc_map_details['0']['lng'];
			}
			$storeup_loc_phno     	= get_post_meta( $post->ID, 'storeup_loc_phno', true );
	        $storeup_loc_all_info[] = array(
				$storeup_loc_lattitudes,
				$storeup_loc_longitudes,
				$storeup_loc_posttitle,
				$storeup_loc_address,
				$storeup_loc_phno,
				$storeup_loc_postlink,
	        );
	endwhile;
	else :
		echo esc_html__( 'Apologies, but no results were found.', 'storeup' );
	endif;
	if ( ! empty( $storeup_loc_all_info ) ) {
		echo wp_json_encode( $storeup_loc_all_info );
	}
	wp_reset_query();
	exit;
}
//
add_action( 'wp_ajax_storeup_bk_loc_pricings', 'storeup_bk_loc_pricings' );
add_action( 'wp_ajax_nopriv_storeup_bk_loc_pricings', 'storeup_bk_loc_pricings' );
function storeup_bk_loc_pricings() {

	$storeup_loc_id 	= $_POST['iva_loc_id'] ;
	$storeup_price_val 	= isset($_POST['loc_price']) ? $_POST['loc_price'] : '';
	$storeup_size_val 	= isset($_POST['loc_size']) ? $_POST['loc_size'] : '';
	
	$pricing_unit = true;
	if( !empty( $storeup_size_val ) ){
		$pricing_unit = true;
	}
	
	$storeup_bk_unit_price_txt = get_option( 'storeup_bk_unit_price_txt' ) ? get_option( 'storeup_bk_unit_price_txt' ) : esc_html__( 'Unit & Price:','storeup' );
	$storeup_area_unit = get_option( 'storeup_area_unit' ) ? get_option( 'storeup_area_unit' ): esc_html__( 'sq ft', 'storeup-vc-textdomain' );
	$storeup_special_txt = get_option( 'storeup_special_txt' ) ? get_option( 'storeup_special_txt' ) : esc_html__( 'Special','storeup-vc-textdomain' );

	if ( ! empty( $storeup_loc_id ) ) {
		// $size_dim = array();
		$storeup_units_pricing = get_post_meta( $storeup_loc_id, 'storeup_units_pricing', true );
		if( ! empty( $storeup_units_pricing ) ){
			foreach ( $storeup_units_pricing as $key => $value ) {
				$size_dim = array();
				$units_val  = $value['height'] * $value['length'];
				$uints 		= $value['height'] . 'x' . $value['length'];
				if ( ! empty( $value['ofr_rate'] ) ) {
					$price = $value['ofr_rate'];
				} elseif ( ! empty( $value['rate'] ) ) {
					$price = $value['rate'];
				}
				if( $storeup_size_val == 'small' ){
					if ( $units_val <= 75 ) {
						$size_dim[] = array( 'units' => $uints , 'price' => $price, 'units_val' => $units_val );
					}
				}
				if( $storeup_size_val == 'medium' ){
					if ( $units_val > 76 && $units_val <= 150 ) {
						$size_dim[] = array( 'units' => $uints , 'price' => $price, 'units_val' => $units_val );
					}
				}
				if( $storeup_size_val == 'large' ){
					if ( $units_val > 151 && $units_val <= 250 ) {
						$size_dim[] = array( 'units' => $uints , 'price' => $price, 'units_val' => $units_val );
					}
				}
				if( $storeup_size_val == 'xlarge' ){
					if ( $units_val > 251 ) {
						$size_dim[] = array( 'units' => $uints , 'price' => $price, 'units_val' => $units_val );
					}
				}
				if( ! empty( $size_dim ) ){
					$pricing_unit = true;
					
					foreach( $size_dim as $size_key => $size_val ){
						
						$unit_price_value =	$size_val['units'] . '-' . $size_val['price'];
						$selected = '';
						if( $unit_price_value == $storeup_price_val ) { 
							$selected = 'is-selected';
							$pricing_unit = true;
						}
						
						echo '<div id="at-bk-units-wrap" class="at-bk-units-wrap">';
						echo '<div id="storeup_bk_price" class="storeup_bk_price at-bk-units-item ' . $selected . '" data-pricing="' . esc_attr( $unit_price_value ) . '">';
						echo '<div class="at-bk-unitsize">';
						echo '<span class="at-bk-size">' . $value['height'] . 'x' . $value['length'] . '</span>';
						echo '<span class="at-bk-sqft">' . $units_val . ' ' . $storeup_area_unit . '</span>';
						
						if ( ! empty( $value['features'] ) ) { 
							echo '<span class="at-bk-features">' . nl2br($value['features']) . '</span>';
						}
						echo '</div>'; //. at-bk-unitsize
						
						// unitsprice
						echo '<div class="at-bk-unit-price">';
						if ( ! empty( $value['rate'] ) ) {
							echo '<span class="at-rate">'; 
							if ( ! empty( $value['ofr_rate'] ) ) { echo '<strike>WAS '; }
							echo $value['rate'];
							if ( ! empty( $value['ofr_rate'] ) ) { echo '</strike>'; }
							echo '</span>';
						}
						if ( ! empty( $value['ofr_rate'] ) ) {
							echo '<div class="at-unit-price-spl">';
							echo '<span class="at-ofr-txt">' . $storeup_special_txt . '</span>';
							echo '<span class="at-ofr-rate">' . $value['ofr_rate'] . '</span>';
							if ( ! empty( $value['ofr_desc'] ) ) {
								echo '<span class="at-ofr-desc">' . $value['ofr_desc'] . '</span>';
							}
							echo '</div>';
						}
						echo '</div>'; //. at-bk-unit-price
						echo '</div>'; //. at-bk-units-item
						echo '</div>'; //. at-bk-units-wrap
					}
				} else{
					$pricing_unit = false;
				}
			}
		}
		
		//if( $pricing_unit == false ) {
		//echo '<div>' . esc_html__( 'Nothing', 'storeup' ) .'</div>';
		//}
	}
	exit;
}
