<?php
/**
 * The Header for our theme.
 * Includes the header.php template file.
 */
get_header(); ?>
<?php
$storeup_loc_fullwidth_class = '';
$storeup_loc_fullwidth = get_post_meta( get_the_ID(),'storeup_loc_fullwidth', true );
if ( $storeup_loc_fullwidth == 'on' ) {  $storeup_loc_fullwidth_class = 'location-stretched'; }
?>
	<div id="primary" class="pagemid_section <?php echo esc_attr( $storeup_loc_fullwidth_class );?>">
	<div class="inner">

		<div class="content-area">
			<div class="entry-content-wrapper clearfix">
				<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
				<div <?php post_class();?> id="post-<?php the_ID(); ?>">
				<?php echo do_shortcode( get_the_content() ); ?>
				</div><!-- #post-<?php the_ID();?> -->
				<?php endwhile; ?>
				<?php else : ?>
				<?php echo '<p>' . esc_html__( 'Sorry, no projects matched your criteria.', 'storeup' ) . '</p>';?>
				<?php endif; ?>
				<div class="clear"></div>
				<?php comments_template( '', true ); ?>
			</div><!-- .entrycontent-wrapper -->
		</div><!-- .content-area -->
		
		<?php
		if ( $storeup_loc_fullwidth != 'on' ) {
			if ( storeup_generator( 'storeup_sidebar_option', $post->ID ) != 'fullwidth' ) { get_sidebar(); }
		}
		?>
	</div><!-- inner -->
	</div><!-- #primary.pagemid -->
<?php
get_footer();
