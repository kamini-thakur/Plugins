<?php
	// L O C A T I O N   M E T A B O X
	//--------------------------------------------------------
	$storeup_sidebar_widget  = get_option( 'storeup_customsidebar' );
	$storeup_pagetitle_align = get_option( 'storeup_subheader_style' ) ? get_option( 'storeup_subheader_style' ) : 'center';
	$storeup_sidebar_layout  = get_option( 'storeup_defaultlayout' ) ? get_option( 'storeup_defaultlayout' ) : 'rightsidebar';

	$this->meta_box[] = array(
		'id'		=> 'location-meta-box',
		'title'		=> esc_html__( 'Location Options', 'storeup' ),
		'page'		=> array( 'location' ),
		'context'	=> 'normal',
		'priority'	=> 'core',
		'fields'	=> array(
			array(
				'name'	=> esc_html__( 'Google Map', 'storeup' ),
				'desc'	=> esc_html__( 'Type the text you wish to display in the venue element', 'storeup' ),
				'id'	=> 'storeup_loc_map',
				'std'	=> '',
				'type'	=> 'googlemap',
			),
			array(
				'name'	=> esc_html__( 'Phone Number', 'storeup' ),
				'desc'	=> esc_html__( ' Enter the phone number. It Must be Numbrs Only.', 'storeup' ),
				'id'	=> 'storeup_loc_phno',
				'std'	=> '',
				'type'	=> 'text',
			),
			array(
				'name'	=> esc_html__( 'Email ID', 'storeup' ),
				'desc'	=> esc_html__( ' Enter email id.', 'storeup' ),
				'id'	=> 'storeup_loc_email',
				'std'	=> '',
				'type'	=> 'text',
			),
			array(
				'name'	=> esc_html__( 'Office Hours', 'storeup' ),
				'desc'	=> esc_html__( ' Enter the office hours.', 'storeup' ),
				'id'	=> 'storeup_ofc_hrs',
				'std'	=> '',
				'type'	=> 'textarea',
			),
			array(
				'name'	=> esc_html__( 'Access Hours / Gate Hours', 'storeup' ),
				'desc'	=> esc_html__( ' Enter the gate hours.', 'storeup' ),
				'id'	=> 'storeup_gate_hrs',
				'std'	=> '',
				'type'	=> 'textarea',
			),
			array(
				'name'	=> esc_html__( 'Features', 'storeup' ),
				'desc'	=> esc_html__( ' Enter the features.', 'storeup' ),
				'id'	=> 'storeup_features',
				'std'	=> '',
				'type'	=> 'default_editor',
			),
			/**
			 * Unit Sizes & Pricing
			 */
			array(
				'name'		=> esc_html__( 'Unit Sizes & Pricing','storeup' ),
				'desc'		=> esc_html__( 'Unit Sizes & Pricing.','storeup' ),
				'id'		=> 'storeup_units_pricing',
				'std' 		=> '',
				'class'		=> 'units_pricing',
				'type'		=> 'units_pricing',
			),
			/**
			 * Fullwidth section
			 */
			array(
				'name'		=> esc_html__( 'FullWidth','storeup' ),
				'desc'		=> esc_html__( 'Check this if you wish to display this page as fullwidth layout.','storeup' ),
				'id'		=> 'storeup_loc_fullwidth',
				'std' 		=> 'off',
				'type'		=> 'checkbox',
			),

		),
	);

	$this->meta_box[] = array(
		'id'		=> 'locatiion_page_options',
		'title'		=> esc_html__( 'Location Page Options', 'storeup' ),
		'page'		=> array( 'location' ),
		'context'	=> 'normal',
		'priority'	=> 'core',
		'fields'	=> array(

			/**
			 * page background
			 */
			array(
				'name'		=> esc_html__( 'Page Background','storeup' ),
				'desc'		=> esc_html__( 'Upload the image for the page background. This will apply only if the layout is selected as boxed in options panel','storeup' ),
				'id'		=> 'storeup_page_bg_image',
				'std'		=> '',
				'type'		=> 'upload',
			),
			/**
			 * Subheader content alignment
			 */
			array(
				'name'  	=> esc_html__( 'Subheader Alignment','storeup' ),
				'desc'   	=> esc_html__( 'Select subheader content alignment. Choose between 1, 2 or 3 position layout.','storeup' ),
				'id' 		=> 'storeup_sub_styling',
				'std' 		=> $storeup_pagetitle_align,
				'type'   	=> 'layout',
				'options'  	=> array(
					'left' => STOREUP_FRAMEWORK_URI . 'admin/images/columns/sh-left.png',
					'center' => STOREUP_FRAMEWORK_URI . 'admin/images/columns/sh-center.png',
					'right' => STOREUP_FRAMEWORK_URI . 'admin/images/columns/sh-right.png',
				),
			),
			/**
			 * subheader options
			 */
			array(
				'name'		=> esc_html__( 'Subheader Options','storeup' ),
				'desc'		=> esc_html__( 'Select the subheader type you wish to display.','storeup' ),
				'id'		=> 'storeup_subheader_teaser_options',
				'std'		=> '',
				'type'		=> 'select',
				'class'		=> 'select300',
				'options'	=> array(
							'default'		=> esc_html__( 'Default ( Options Panel )', 'storeup' ),
							'customtitle'	=> esc_html__( 'Custom', 'storeup' ),
							'disable'		=> esc_html( 'Disable', 'storeup' ),
						),
			),

			/**
			 * subheader custom title
			 */
			array(
				'name'		=> esc_html__( 'Subheader Custom Title','storeup' ),
				'desc'		=> esc_html__( 'Type the custom text you wish to display in the subheader of this page/post. If you wish to use bold text then use strong element example &lt;strong&gt;bold text &lt;/strong&gt;','storeup' ),
				'id'		=> 'storeup_page_title',
				'class'		=> 'sub_teaser_option customtitle',
				'std'		=> '',
				'type'		=> 'text',
			),


			/**
			 * subheader custom text
			 */
			array(
				'name'		=> esc_html__( 'Subheader Custom Text','storeup' ),
				'desc'		=> esc_html__( 'Type the custom text you wish to display in the subheader of this page/post. If you wish to use bold text then use strong element example &lt;strong&gt;bold text &lt;/strong&gt;','storeup' ),
				'id'		=> 'storeup_page_desc',
				'class'		=> 'sub_teaser_option customtitle',
				'std'		=> '',
				'type'		=> 'textarea',
			),
			/**
			 * subheader background
			 */
			array(
				'name'		=> esc_html__( 'Subheader Background','storeup' ),
				'desc'		=> esc_html__( 'Upload Subheader Image and its properties','storeup' ),
				'id'		=> 'storeup_subheader_img',
				'type'		=> 'background',
				'std' 		=> '',
				'options'	=> array(
							'image'		=> '',
							'color'		=> '',
							'repeat' 	=> '',
							'position'	=> '',
							'attachment' => '',
				),
			),
			/**
			 * subheader text color
			 */
			array(
				'name'		=> esc_html__( 'Subheader Text Color','storeup' ),
				'desc'		=> esc_html__( 'Select the color for the content in the subheader','storeup' ),
				'id'		=> 'storeup_sh_txtcolor',
				'std'		=> '',
				'type'		=> 'color',
			),
			/**
			 * subheader padding
			 */
			array(
				'name'		=> esc_html__( 'Subheader Padding','storeup' ),
				'desc'		=> esc_html__( 'Enter the padding for the subheader area. Padding should be in the following format - 20px 0 20px 0 - directions are Top Right Bottom Left.','storeup' ),
				'id'		=> 'storeup_sh_padding',
				'std'		=> '',
				'type'		=> 'text',
			),
			/**
			 * sidebar position
			 */
			array(
				'name'		=> esc_html__( 'Sidebar Position','storeup' ),
				'desc'		=> esc_html__( 'Select the sidebar position you wish to use for this page, Left Sidebar or Right Sidebar or Full Width.','storeup' ),
				'id'		=> 'storeup_sidebar_options',
				'std'		=> $storeup_sidebar_layout,
				'type'		=> 'layout',
				'options'	=> array(
							'rightsidebar'	=> STOREUP_FRAMEWORK_URI . 'admin/images/columns/rightsidebar.png',
							'leftsidebar'	=> STOREUP_FRAMEWORK_URI . 'admin/images/columns/leftsidebar.png',
							'fullwidth'		=> STOREUP_FRAMEWORK_URI . 'admin/images/columns/fullwidth.png',
						),
			),
			/**
			 * custom sidebar
			 */
			array(
				'name'		=> esc_html__( 'Custom Sidebar','storeup' ),
				'desc' 		=> esc_html__( 'Select the Sidebar you wish to assign for this page.','storeup' ),
				'id' 		=> 'storeup_custom_widget',
				'type' 		=> 'customselect',
				'class'		=> 'select300',
				'std' 		=> '',
				'options'	=> $storeup_sidebar_widget,
			),
			/**
			 * breadcrumb
			 */
			array(
				'name'		=> esc_html__( 'Breadcrumb','storeup' ),
				'desc'		=> esc_html__( 'Check this if you wish to disable the breadcrumb for this page.','storeup' ),
				'id'		=> 'storeup_breadcrumb',
				'std' 		=> 'off',
				'type'		=> 'checkbox',
			),
		),
	);
