<?php
/**
 * Widget API: Storeup_Locationinfo_Widget class
 *
 * @package WordPress
 * @subpackage Widgets
 * @since 4.5.0
 */
class Storeup_Locationinfo_Widget extends WP_Widget {
	public function __construct() {
		$widget_ops = array( 'classname' => 'storeup-loc-wg', 'description' => esc_html__( 'Location Info', 'storeup' ) );
		$control_ops = array( 'width' => 400, 'height' => 350 );
		parent::__construct( 'Location Info', STOREUP_THEME_NAME . esc_html__( ' Location Info', 'storeup' ), $widget_ops, $control_ops );
	}

	public function widget( $args, $instance ) {
		extract( $args );
		/** This filter is documented in wp-includes/widgets/class-wp-widget-pages.php */
		$title = apply_filters( 'widget_title', empty( $instance['title'] ) ? '' : $instance['title'], $instance, $this->id_base );

		$out = '';

		$title  = ! empty( $instance['title'] ) ? $instance['title'] : '';

		global $storeup_theme_ob;
		$storeup_locations = $storeup_theme_ob->storeup_get_vars( 'locations' );
		echo  wp_kses_post( $before_widget );
		echo '<div class="at-wg-loc-tabs-wrap">';
		echo '<select id="at-wg-loc-tabs" class="at-wg-loc-tab" name="at_wg_locations">';
		foreach ( $storeup_locations as $key => $value ) {
			echo '<option value="' . esc_attr( $key ) . '">' . esc_html( $value ) . '</option>';
		}
		echo '</select>';
		echo '</div>';//.at-wg-loc-tabs-wrap
		echo '<div class="at_wg_loc_tabs_list">';
		foreach ( $storeup_locations as $key => $value ) {
			$storeup_addr = '';
			$storeup_gate_hrs 	 = get_post_meta( $key, 'storeup_gate_hrs', true );
			$storeup_phno 	   	 = get_post_meta( $key, 'storeup_loc_phno', true );
			$storeup_email 	   	 = get_post_meta( $key, 'storeup_loc_email', true );
			$storeup_map_details = get_post_meta( $key, 'storeup_loc_map', true );
			if ( ! empty( $storeup_map_details ) ) {
			    $storeup_addr = $storeup_map_details['0']['address'];
			}
			echo '<div id="' . esc_attr( $key ) . '" class="at-wg-loc-tab-list-content">';
			if ( ! empty( $storeup_addr ) ) {
				echo '<div class="at_location_box">';
				echo '<i class="fa at-loc-w_icon fa-fw fa-map-marker"></i>';
				echo '<span class="at-loc-w_desc">' . esc_html( $storeup_addr ) . '</span>';
				echo '</div>'; // #at_location_box
			}
			if ( ! empty( $storeup_gate_hrs ) ) {
				echo '<div class="at_location_box">';
				echo '<i class="fa at-loc-w_icon fa-fw fa-clock-o"></i>';
				echo '<span class="at-loc-w_desc">' . esc_html( $storeup_gate_hrs ) . '</span>';
				echo '</div>'; // #at_location_box
			}
			if ( ! empty( $storeup_phno ) ) {
				echo '<div class="at_location_box">';
				echo '<i class="fa at-loc-w_icon fa-fw fa-phone"></i>';
				echo '<span class="at-loc-w_desc">' . esc_html( $storeup_phno ) . '</span>';
				echo '</div>'; // #at_location_box
			}
			echo '</div>'; //.at-wg-loc-tab-list-content
		}
		echo '</div>'; // at_wg_loc_tabs_list
		echo wp_kses_post( $after_widget );
	}
	/**
	 * Handles updating settings for the current iconbox widget instance.
	 *
	 * @since 2.8.0
	 * @access public
	 *
	 * @param array $new_instance New settings for this instance as input by the user via
	 *                            WP_Widget::form().
	 * @param array $old_instance Old settings for this instance.
	 * @return array Settings to save or bool false to cancel saving.
	 */
	public function update( $new_instance, $old_instance ) {

		$instance = $old_instance;
		$instance['title'] = sanitize_text_field( $new_instance['title'] );

		return $instance;
	}

	/**
	 * Outputs the Text widget settings form.
	 *
	 * @since 2.8.0
	 * @access public
	 *
	 * @param array $instance Current settings.
	 */
	public function form( $instance ) {
			$instance = wp_parse_args( (array) $instance, array(
				'title' => '',
			) );
			$title = sanitize_text_field( $instance['title'] );
		?>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title', 'storeup' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
		</p>
		<?php
	}
}
// Register Widget
function storeup_locationinfo_widget() {
	register_widget( 'storeup_locationinfo_widget' );
}

/* Add our function to the widgets_init hook. */
add_action( 'widgets_init', 'storeup_locationinfo_widget' );
