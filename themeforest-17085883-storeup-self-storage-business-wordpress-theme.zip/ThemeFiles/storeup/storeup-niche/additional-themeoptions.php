<?php
add_filter( 'custompost_themeoptions','storeup_cpt_addition_theme_options' );
function storeup_cpt_addition_theme_options( $storeup_options ) {

		global $storeup_options, $storeup_theme_ob;
		// Storeup settings
		//--------------------------------------------------------------------------------------------
		$storeup_options[] = array( 'name' => esc_html__( 'Storeup','storeup' ), 'icon' => 'fa-cog','type' => 'heading' );
		//-------------------------------------------------------------------------------------------

		// General Settings
		//---------------------------------------------------------------------------------------------------
		$storeup_options[] = array( 'name' => esc_html__( 'General Settings', 'storeup' ), 'type' => 'subnav' );
		//---------------------------------------------------------------------------------------------------

		$storeup_options[] = array(
								'name'	=> esc_html__( 'Booking Page', 'storeup' ),
								'desc'	=> __('The WordPress page template used to display the Booking Form.', 'storeup'),
								'id'	=> 'storeup_booking_page',
								'std'	=> '',
								'class'	=> 'select300',
								'type'	=> 'select',
								'options'=> $storeup_theme_ob->storeup_get_vars('pages'),
								);
		$storeup_options[] = array(
								'name'	=> esc_html__( 'Gallery Slug','storeup' ),
								'desc'	=> esc_html__( 'Slugs are meant to be used with permalinks as they help describe what you wish to have at the URL.', 'storeup' ),
								'id'	=> 'storeup_gallery_slug',
								'std'	=> '',
								'type'	=> 'text',
								'inputsize' => '330',
							);
		$storeup_options[] = array(
								'name'	=> esc_html__( 'Slider Slug','storeup' ),
								'desc'	=> esc_html__( 'Slugs are meant to be used with permalinks as they help describe what you wish to have at the URL.', 'storeup' ),
								'id'	=> 'storeup_slider_slug',
								'std'	=> '',
								'type'	=> 'text',
								'inputsize' => '330',
							);
		$storeup_options[] = array(
								'name'	=> esc_html__( 'Testimonial Slug','storeup' ),
								'desc'	=> esc_html__( 'Slugs are meant to be used with permalinks as they help describe what you wish to have at the URL.', 'storeup' ),
								'id'	=> 'storeup_testimonial_slug',
								'std'	=> '',
								'type'	=> 'text',
								'inputsize' => '330',
							);
		$storeup_options[] = array(
								'name'	=> esc_html__( 'Location Slug','storeup' ),
								'desc'	=> esc_html__( 'Slugs are meant to be used with permalinks as they help describe what you wish to have at the URL.', 'storeup' ),
								'id'	=> 'storeup_location_slug',
								'std'	=> '',
								'type'	=> 'text',
								'inputsize' => '330',
							);
		$storeup_options[] = array(
								'name'	=> esc_html__( 'Calendar Language','storeup' ),
								'desc'	=> esc_html__( 'Calendar Language','storeup' ),
								'id'	=> 'storeup_datepicker_language',
								'std'	=> '',
								'type'	=> 'select',
								'class'	=> 'select300',
								'options'	=> array(
													''  		=> esc_html__( 'English', 'storeup' ),
													'sq'		=> esc_html__( 'Albanian', 'storeup' ),
													'ar' 		=> esc_html__( 'Arabic', 'storeup' ),
													'bg'		=> esc_html__( 'Bulgarian', 'storeup' ),
													'zh-CN'		=> esc_html__( 'Chinese', 'storeup' ),
													'zh-TW'  	=> esc_html__( 'Chinese Traditiona', 'storeup' ),
													'da'		=> esc_html__( 'Danish', 'storeup' ),
													'fr'  		=> esc_html__( 'French', 'storeup' ),
													'fa'  		=> esc_html__( 'Farsi', 'storeup' ),
													'fi'		=> esc_html__( 'Finnish', 'storeup' ),
													'de'		=> esc_html__( 'German', 'storeup' ),
													'ka'		=> esc_html__( 'Georgian', 'storeup' ),
													'he'  		=> esc_html__( 'Hebrew', 'storeup' ),
													'id'		=> esc_html__( 'Indonesian', 'storeup' ),
													'is'		=> esc_html__( 'Icelandic', 'storeup' ),
													'it'		=> esc_html__( 'Italian', 'storeup' ),
													'ja'		=> esc_html__( 'Japanese', 'storeup' ),
													'lt'		=> esc_html__( 'Lithuanian', 'storeup' ),
													'lv'		=> esc_html__( 'Latvian', 'storeup' ),
													'ms'		=> esc_html__( 'Malaysian', 'storeup' ),
													'ml'		=> esc_html__( 'Malayalam', 'storeup' ),
													'mk'		=> esc_html__( 'Macedonian','storeup' ),
													'nn'		=> esc_html__( 'Norwegian Nynorsk', 'storeup' ),
													'no'		=> esc_html__( 'Norwegian', 'storeup' ),
													'pl'		=> esc_html__( 'Polish', 'storeup' ),
													'pt'		=> esc_html__( 'Portuguese', 'storeup' ),
													'pt-BR'		=> esc_html__( 'Brazilian', 'storeup' ),
													'rm'		=> esc_html__( 'Romansh', 'storeup' ),
													'ro'		=> esc_html__( 'Romanian', 'storeup' ),
													'ru'		=> esc_html__( 'Russian', 'storeup' ),
													'sk' 		=> esc_html__( 'Slovak', 'storeup' ),
													'sl'		=> esc_html__( 'Slovenian', 'storeup' ),
													'sr' 		=> esc_html__( 'Serbian', 'storeup' ),
													'es' 		=> esc_html__( 'Spanish', 'storeup' ),
													'sv'		=> esc_html__( 'Swedish', 'storeup' ),
													'ta'		=> esc_html__( 'Tamil', 'storeup' ),
													'th'		=> esc_html__( 'Thai', 'storeup' ),
													'tj'		=> esc_html__( 'Tajiki', 'storeup' ),
													'tr'		=> esc_html__( 'Turkish', 'storeup' ),
													'uk'		=> esc_html__( 'Ukrainian', 'storeup' ),
													'vi'		=> esc_html__( 'Vietnamese', 'storeup' ),
													),
							);
		$storeup_options[] = array(
									'name'	=> esc_html__( 'Calendar Week Start Day','storeup' ),
									'desc'	=> esc_html__( 'Set the first day of the week: Sunday is 0, Monday is 1, etc.', 'storeup' ),
									'id'	=> 'storeup_first_day',
									'std'	=> '',
									'class' => 'select300',
									'type'	=> 'select',
									'options'	=> array(
													'0' => esc_html__( 'Sunday','storeup' ),
													'1' => esc_html__( 'Monday','storeup' ),
													'2' => esc_html__( 'Tuesday','storeup' ),
													'3' => esc_html__( 'Wednesday','storeup' ),
													'4' => esc_html__( 'Thursday','storeup' ),
													'5' => esc_html__( 'Friday','storeup' ),
													'6' => esc_html__( 'Saturday','storeup' ),
												 ),
							);
		$storeup_options[] = array(
									'name'	  => esc_html__( 'Weather Location','storeup' ),
									'desc'	  => esc_html__( 'Location of the weather like New York, USA. This is used on Bookings Page above the calendar', 'storeup' ),
									'id'	   => 'storeup_weather_loc',
									'std'	   => '',
									'type'	   => 'text',
									'inputsize' => '330',
							);
		$storeup_options[] = array(
									'name'		=> esc_html__( 'Weather Unit','storeup' ),
									'desc'		=> esc_html__( 'Select the weather unit. This is used on Bookings Page above the calendar', 'storeup' ),
									'id'		=> 'storeup_weather_unit',
									'std'		=> 'f',
									'type'		=> 'radio',
									'class'		=> '',
									'inputsize'	=> '',
									'options'   => array(
													'f' => esc_html__( 'Fahrenheit','storeup' ),
													'c'	=> esc_html__( 'Celsius','storeup' ),
												),
								);
		$storeup_options[] = array(
								'name'	=> esc_html__( 'Disable Calender Days Using Date Picker', 'storeup' ),
								'desc'	=> esc_html__( 'Use the following generator to disable certain dates from the calendar. Disabled dates will not be available for booking. Please do not manually edit the date text. Use the datepicker to enter the date.', 'storeup' ),
								'id'	=> 'storeup_disable_days',
								'std'	=> '',
								'type'	=> 'add_custom_dates',
							);

		$storeup_options[] = array(
									'name'	=> esc_html__( 'Disable Calender Week Days','storeup' ),
									'desc'	=> esc_html__( 'Select the days you wish to make it off by default in the calendar. This is used on Bookings page above the calendar','storeup' ),
									'id'	=> 'storeup_disable_weekdays',
									'std'	=> '',
									'type'	=> 'multiselect',
									'inputsize' => '330',
									'options'	=> array(
												'0' => esc_html__( 'Sunday','storeup' ),
												'1' => esc_html__( 'Monday','storeup' ),
												'2' => esc_html__( 'Tuesday','storeup' ),
												'3' => esc_html__( 'Wednesday','storeup' ),
												'4' => esc_html__( 'Thursday','storeup' ),
												'5' => esc_html__( 'Friday','storeup' ),
												'6' => esc_html__( 'Saturday','storeup' ),
											),
						);
		$storeup_options[] = array(
								'name'		=> esc_html__( 'Area Unit Measurement','storeup' ),
								'desc'	 	=> esc_html__( 'Area unit which appears on single page location Ex: sq ft.', 'storeup' ),
								'id'		=> 'storeup_area_unit',
								'std'		=> '',
								'inputsize' => '330',
								'type'		=> 'text',
							);
		$storeup_options[] =array(
						'name'	=> esc_html__( 'Unit Size Dimensions Names','storeup' ),
						'desc'	=> esc_html__( 'Enter the Unit Names to display in the storage bookings and single page.','storeup' ),
						'id'	=> 'storeup_size_dim_name',
						'std'	=>  array(
										'small' => esc_html__( 'Small','storeup' ),
										'medium' => esc_html__( 'Medium','storeup' ),
										'large' => esc_html__( 'Large','storeup' ),
										'xlarge' => esc_html__( 'X-large','storeup' ),
									),
						'type'	=> 'multitext',
					);
		//---------------------------------------------------------------------------------------------------
		$storeup_options[] = array( 'name' => esc_html__( 'Gallery Properties','storeup' ), 'type' => 'subnav' );
		//---------------------------------------------------------------------------------------------------
		$storeup_options[] = array(
					'name'			=> esc_html__( 'Gallery Columns', 'storeup' ),
					'desc'			=> esc_html__( 'Select the no. of columns which you wish to display in Gallery Page Template.', 'storeup' ),
					'id'			=> 'storeup_gallery_columns',
					'class'			=> 'select300',
					'std'			=> '4',
					'type'			=> 'select',
					'inputsize'		=> '',
					'options'		=> array(
											'2' => esc_html__( '2 Columns','storeup' ),
											'3' => esc_html__( '3 Columns','storeup' ),
											'4' => esc_html__( '4 Columns','storeup' ),
											'5' => esc_html__( '5 Columns','storeup' ),
										),
		);
		$storeup_options[] = array(
					'name'			=> esc_html__( 'Gallery Pagination', 'storeup' ),
					'desc'			=> esc_html__( 'Check this if you wish to display pagination in Gallery page template', 'storeup' ),
					'id'			=> 'storeup_gallery_pagination',
					'class'			=> 'gallery_pagination',
					'std'			=> '',
					'type'			=> 'checkbox',
					'inputsize'		=> '',
		);
		$storeup_options[] = array(
					'name'			=> esc_html__( 'Galleries Limit', 'storeup' ),
					'desc'			=> esc_html__( 'Type the limits for Gallery you wish to limit on the page  (e.g: 5)', 'storeup' ),
					'id'			=> 'storeup_gallery_limits',
					'class'			=> 'gallery_limits',
					'std'			=> '',
					'type'			=> 'text',
					'inputsize'		=> '',
		);
		$storeup_options[] = array(
					'name'			=> esc_html__( 'Gallery Orderby', 'storeup' ),
					'desc'			=> esc_html__( 'Select the orderby  which you want to use  Id ,title,date or menu order in Gallery page template', 'storeup' ),
					'id'			=> 'storeup_gallery_orderby',
					'class'			=> 'gallery_orderby',
					'std'			=> '',
					'type'			=> 'select',
					'class'			=> 'select300',
					'options'		=> array(
											'ID' 			=> esc_html__( 'ID','storeup' ),
											'title'			=> esc_html__( 'Title','storeup' ),
											'date' 			=> esc_html__( 'Date','storeup' ),
											'menu_order'	=> esc_html__( 'Menu Order','storeup' ),
										),
		);
		$storeup_options[] = array(
					'name'			=> esc_html__( 'Gallery Order','storeup' ),
					'desc'			=> esc_html__( 'Select the order which you wish to display in Gallery Page Template','storeup' ),
					'id'			=> 'storeup_gallery_order',
					'class'			=> 'gallery_order',
					'std'			=> 'ASC',
					'type'			=> 'radio',
					'inputsize'		=> '',
					'options'		=> array(
											'ASC' => esc_html__( 'Ascending', 'storeup' ),
											'DSC' => esc_html__( 'Descending', 'storeup' ),
										),
		);
		$storeup_options[] = array(
					'name'			=> esc_html__( 'Single page Gallery Pagination','storeup' ),
					'desc'			=> esc_html__( 'Check this if you wish to display pagination in gallery single page','storeup' ),
					'id'			=> 'storeup_single_gallery_pagination',
					'class'			=> 'gallery_pagination',
					'std'			=> '',
					'type'			=> 'checkbox',
					'inputsize'		=> '',
		);
		$storeup_options[] = array(
					'name'			=> esc_html__( 'Single page galleries items','storeup' ),
					'desc'			=> esc_html__( 'Type the limit for galleries you wish to display on the gallery single page.','storeup' ),
					'id'			=> 'storeup_single_gallery_limits',
					'class'			=> 'gallery_limits',
					'std'			=> '',
					'type'			=> 'text',
					'inputsize'		=> '',
		);
		$storeup_options[] = array(
					'name'			=> esc_html__( 'Gallery Image Caption','storeup' ),
					'desc'			=> esc_html__( 'Check this if you wish to display caption on gallery single page','storeup' ),
					'id'			=> 'storeup_single_gallery_imagecaption',
					'class'			=> 'gallery_pagination',
					'std'			=> '',
					'type'			=> 'checkbox',
					'inputsize'		=> '',
		);
		//---------------------------------------------------------------------------------------------------
		$storeup_options[] = array( 'name' => esc_html__( 'Location Properties', 'storeup' ), 'type' => 'subnav' );
		//---------------------------------------------------------------------------------------------------
		$storeup_options[] = array(
					'name'			=> esc_html__( 'Location Pagination', 'storeup' ),
					'desc'			=> esc_html__( 'Check this if you wish to display pagination in Location Taxonomy Page', 'storeup' ),
					'id'			=> 'storeup_location_pagination',
					'class'			=> 'location_pagination',
					'std'			=> '',
					'type'			=> 'checkbox',
					'inputsize'		=> '',
		);
		$storeup_options[] = array(
					'name'			=> esc_html__( 'Location Limit', 'storeup' ),
					'desc'			=> esc_html__( 'Type the limits for Location you wish to limit on the page  (e.g: 5)', 'storeup' ),
					'id'			=> 'storeup_location_limits',
					'class'			=> 'location_limits',
					'std'			=> '',
					'type'			=> 'text',
					'inputsize'		=> '',
		);
		$storeup_options[] = array(
					'name'			=> esc_html__( 'Location Orderby', 'storeup' ),
					'desc'			=> esc_html__( 'Select the orderby  which you want to use  Id ,title,date or menu order in Location Taxonomy page', 'storeup' ),
					'id'			=> 'storeup_location_orderby',
					'class'			=> 'location_orderby',
					'std'			=> '',
					'type'			=> 'select',
					'class'			=> 'select300',
					'options'		=> array(
											'ID' 		=> esc_html__( 'ID','storeup' ),
											'title'		=> esc_html__( 'Title','storeup' ),
											'date' 		=> esc_html__( 'Date','storeup' ),
											'menu_order' => esc_html__( 'Menu Order','storeup' ),
										),
		);
		$storeup_options[] = array(
					'name'			=> esc_html__( 'Location Order','storeup' ),
					'desc'			=> esc_html__( 'Select the order which you wish to display in Location Taxonomy Page','storeup' ),
					'id'			=> 'storeup_location_order',
					'class'			=> 'location_order',
					'std'			=> 'ASC',
					'type'			=> 'radio',
					'inputsize'		=> '',
					'options'		=> array(
											'ASC' => esc_html__( 'Ascending','storeup' ),
											'DSC' => esc_html__( 'Descending','storeup' ),
										),
		);

		// Email Setup
		//------------------------------------------------------------------------------------------------
		$storeup_options[] = array( 'name' => esc_html__( 'Front end E-mails Setup','storeup' ), 'type' => 'subnav' );
		//------------------------------------------------------------------------------------------------
		$storeup_options[] = array(
									'name'	=> esc_html__( 'Shortcodes for Email Setup','storeup' ),
									'desc'	=> wp_kses( __( 'Custom shortcodes defined for this theme in use for the Email Message systems<br><br>
												[first_name] - <em>First Name of the Customer </em><br>
												[phone_no]	 - <em>Contact Number of the Customer </em><br>
												[email]		 - <em>Email of the Customer </em><br>
												[address]	 - <em>Address Of the Customer</em><br>
												[zipcode]	 - <em>Zipcode</em><br>
												[location]	 - <em> Location</em><br>
												[price]		 - <em> Price</em><br>
												[bk_date]	 - <em> Date </em><br>', 'storeup' ),array( 'em' => true,'br' => array(), ) ),
									'type'	=> 'subsection',
							);
		$storeup_options[] = array(
							'name'	=> esc_html__( 'Booking Form Thank You Page','storeup' ),
							'desc'	=> esc_html__( 'Page which displays when Booking form has been submitted successfully.', 'storeup' ),
							'id'	=> 'storeup_bk_thankyou_page',
							'std'	=> '',
							'type'	=> 'select',
							'class' => 'select300',
							'options' => $storeup_theme_ob->storeup_get_vars( 'pages' ),
						);

		$storeup_options[] = array(
								'name'	=> esc_html__( 'Booking Form Thank You Message','storeup' ),
								'desc'	=> esc_html__( 'Message which displays when Booking form has been submitted successfully.', 'storeup' ),
								'id'	=> 'storeup_bk_thankyou_msg',
								'std'	=> 'Thank you! [first_name], Your Booking has been scheduled and you will be notified soon for confirmation by our consultant.',
								'type'	=> 'textarea',
							);

		$storeup_options[] = array(
									'name'	=> esc_html__( 'Booking Notification Subject','storeup' ),
									'desc'	=> esc_html__( 'Subject for the Booking Confirmation Email Message.', 'storeup' ),
									'id'	=> 'storeup_bk_client_notify_subject',
									'std'	=> '',
									'type'	=> 'text',
									'inputsize'	=> '330',
							);
		$storeup_options[] = array(
									'name'	=> esc_html__( 'Customer Email Header Name','storeup' ),
									'desc'	=> esc_html__( 'Displays Header for the email. Example: New Booking Request.','storeup' ),
									'id'	=> 'storeup_bk_client_headers_msg',
									'std'	=> '',
									'type'	=> 'text',
									'inputsize'	=> '330',
							);

		$storeup_options[] = array(
									'name'	=> esc_html__( 'Booking Notification message','storeup' ),
									'desc'	=> esc_html__( 'Email Message which appears when a user gets a confirmation for the Booking he fixed.','storeup' ),
									'id'	=> 'storeup_bk_client_notify_msg',
									'std'	=> 'Dear [first_name]
												Thank you for making an booking  for [first_name] on [bk_date]. The last thing we require from you is to please confirm your booking.
												Sincerely,',
									'type'	=> 'textarea',
							);
							//------------------------------------------------------------------------------------------------
		$storeup_options[] = array( 'name' => esc_html__( 'Admin E-mails Setup','storeup' ), 'type' => 'subnav' );
		//------------------------------------------------------------------------------------------------
		$storeup_options[] = array(
									'name'	=> esc_html__( 'Shortcodes for Email Setup','storeup' ),
									'desc'	=> wp_kses( __( 'Custom shortcodes defined for this theme in use for the Email Message systems<br><br>
												[first_name] - <em>First Name of the Customer </em><br>
												[phone_no]	 - <em>Contact Number of the Customer </em><br>
												[email]		 - <em>Email of the Customer </em><br>
												[address]	 - <em>Address Of the Customer</em><br>
												[zipcode]	 - <em>Zipcode</em><br>
												[location]	 - <em> Location</em><br>
												[price]		 - <em> Price</em><br>
												[bk_date]	 - <em> Date </em><br><br>', 'storeup' ),array( 'em' => true, 'br' => array(), ) ),
									'type'	=> 'subsection',
							);

		$storeup_options[] = array(
									'name'		=> esc_html__( 'Admin Email ID','storeup' ),
									'desc'		=> esc_html__( 'Email id where you want to get all the Booking requests.','storeup' ),
									'id'		=> 'storeup_bk_admin_emailid',
									'std'		=> '',
									'type'		=> 'text',
									'inputsize'	=> '330',
							);
		$storeup_options[] = array(
									'name'	=> esc_html__( 'Admin Email Subject','storeup' ),
									'desc'	=> esc_html__( 'Display admin email subject. Ex: StoreUp Inc.','storeup' ),
									'id'	=> 'storeup_bk_admin_notify_subject',
									'std'	=> '',
									'type'	=> 'text',
									'inputsize'	=> '330',
							);

		$storeup_options[] = array(
									'name'	=> esc_html__( 'Admin Email Header Name','storeup' ),
									'desc'	=> esc_html__( 'Displays Header for the email. Example: New Booking Request.','storeup' ),
									'id'	=> 'storeup_bk_headers_msg',
									'std'	=> '',
									'type'	=> 'text',
									'inputsize'	=> '330',
							);
		$storeup_options[] = array(
									'name' => esc_html__( 'Admin Notification Email Message', 'storeup' ),
									'desc'	=> esc_html__( 'Email message format which goes to Admin when a new Booking is requested. For admin email-ID please see the field below <strong>booking Email</strong>', 'storeup' ),
									'id'	=> 'storeup_bk_admin_notification_msg',
									'std'	=> 'Name : [first_name]
												Email : [email]
												You have a New booking Scheduled to for [first_name] on [bk_date].
												For more information to contact [first_name] you can make a call on [phone_no].

												Regards
												Admin',
									'type'	=> 'textarea',
							);
		return $storeup_options;
}
