jQuery(document).ready(function($){
	'use strict';

	jQuery(".at-unit-price-tab-content").hide();

	jQuery(".at-unit-price-tab-content:first").show();
	jQuery('.at-unit-price-tabs li:first').addClass('active'); // FIRST LI  ADD CLASS
	var selected_tabs = jQuery('.at-unit-price-tabs li:first').attr('data-tab');
	jQuery("." + selected_tabs).show();
	jQuery('.at-unit-price-tab-list').live('click',function(){
		var selected_tab = jQuery(this).attr('data-tab');
		jQuery(".at-unit-price-tab-content").hide();
		jQuery('.at-unit-price-tabs li.active').removeClass('active'); // LI REMOVE CLASS
		jQuery(this).closest('li').addClass('active');  // LI CLASS ADDED
		jQuery("." + selected_tab).show();
	});
	// tablesorter
	jQuery("#at-units-pricing-table").tablesorter({
		sortList: [[3, 1]]
	});
	// Form
	jQuery('#storeup_bk_submit').click(function(){
        validateForm();
    });
	function validateForm(){
        var nameReg      = /^[A-Za-z]+$/;
        var numberReg    =  /^[0-9]+$/;
        var emailReg     = /^[A-Z0-9._%+-]+@([A-Z0-9-]+\.)+[A-Z]{2,4}$/i;
        var iva_fname    = jQuery('#storeup_bk_name').val();
        var iva_phone    = jQuery('#storeup_bk_phoneno').val();
        var iva_email    = jQuery('#storeup_bk_email').val();
        var iva_fax      = jQuery('#storeup_bk_fax').val();
		var iva_price = '';
		if ( jQuery('.storeup_bk_price').hasClass('is-selected')){
			var iva_price = jQuery('.storeup_bk_price').attr('data-pricing');
		}
		var iva_location  = jQuery('#storeup_bk_location').val();
		var iva_size      = jQuery('#storeup_bk_size').val();
	    var iva_address  = jQuery('#storeup_bk_address').val();
        var iva_city  	 = jQuery('#storeup_bk_city').val();
        var iva_state  	 = jQuery('#storeup_bk_state').val();
		var iva_country  = jQuery('#storeup_bk_country').val();
		var iva_zipcode  = jQuery('#storeup_bk_zipcode').val();
		var iva_captcha  = jQuery('#storeup_bk_captcha').val();
		var iva_captcha_correct  = jQuery('#storeup_bk_captcha_correct').val();
		var proceed 	= true;

		// First name
        if( iva_fname == ""){
			jQuery("#storeup_bk_name").addClass("error");
			 proceed = false;
        }
		if( iva_fname ){
			jQuery("#storeup_bk_name").removeClass("error");
		}

		// Phone number
		if( numberReg.test( iva_phone ) ){
			jQuery("#storeup_bk_phoneno").removeClass("error");
            proceed = true;
        }else{
			jQuery("#storeup_bk_phoneno").addClass("error");
			proceed = false;
		}
		// Email
		if( emailReg.test( iva_email ) ){
			jQuery("#storeup_bk_email").removeClass("error");
            proceed = true;
        }else{
			jQuery("#storeup_bk_email").addClass("error");
			proceed = false;
		}
		// location
		if( iva_location == ""){
			jQuery("#storeup_bk_location").addClass("error");
			 proceed = false;
        }
		if( iva_location ){
            jQuery("#storeup_bk_location").removeClass("error");
			 proceed = true;
        }
		// Size
		if( iva_size == ""){
			jQuery("#storeup_bk_size").addClass("error");
			 proceed = false;
        }
		if( iva_size ){
            jQuery("#storeup_bk_size").removeClass("error");
			 proceed = true;
        }
		// price
		if( iva_price == ""){
			jQuery(".iva_bk_pricings").addClass("error");
			 proceed = false;
        }
		if( iva_price ){
            jQuery(".iva_bk_pricings").removeClass("error");
			 proceed = true;
        }

		// Fax
		if( iva_fax == ""){
			jQuery("#storeup_bk_fax").addClass("error");
			 proceed = false;
        }
		if( iva_fax ){
            jQuery("#storeup_bk_fax").removeClass("error");
			 proceed = true;
        }
		// Address
		if( iva_address == ""){
			jQuery("#storeup_bk_address").addClass("error");
			 proceed = false;
        }
		if( iva_address){
            jQuery("#storeup_bk_address").removeClass("error");
			 proceed = true;
        }
		// City
		if( iva_city == ""){
			jQuery("#storeup_bk_city").addClass("error");
			 proceed = false;
        }
		if( iva_city ){
            jQuery("#storeup_bk_city").removeClass("error");
			 proceed = true;
        }
		// State
        if( iva_state == ""){
			jQuery("#storeup_bk_state").addClass("error");
			 proceed = false;
        }
		if( iva_state ){
            jQuery("#storeup_bk_state").removeClass("error");
			 proceed = true;
        }
		// Country
        if( iva_country == ""){
			jQuery("#storeup_bk_country").addClass("error");
			 proceed = false;
        }
		if( iva_country ){
            jQuery("#storeup_bk_country").removeClass("error");
			 proceed = true;
        }
		// zipcode
        if( iva_zipcode == ""){
			jQuery("#storeup_bk_zipcode").addClass("error");
			 proceed = false;
        }
		if( iva_zipcode ){
            jQuery("#storeup_bk_zipcode").removeClass("error");
			 proceed = true;
        }
		// Captch
		if( iva_captcha == ""){
			jQuery("#storeup_bk_captcha").addClass("error");
			 proceed = false;
        }

		if( iva_captcha != "" ){
			if( iva_captcha !== iva_captcha_correct ){
            	jQuery("#storeup_bk_captcha").addClass("error");
				proceed = false;
			}else if( iva_captcha === iva_captcha_correct ){
				jQuery("#storeup_bk_captcha").removeClass("error");
			 	proceed = true;
			}
        }
		// If  no error proceed
        if( proceed ){
            storeup_bookings( iva_price );
        }
    }
	function storeup_bookings( iva_price ){
		 jQuery.ajax({
            url: storeup_localize_script_param.ajaxurl,
            type: 'post',
            dataType: 'html',
            data: {
				storeup_bk_price : iva_price,
                action   : 'storeup_bk_form_action',
                data     : jQuery("#storeup-bk-form").serialize()
            },
            success: function( response ){
                jQuery('#storeup-bk-formstatus').html(response);
				if ( typeof storeup_localize_script_param.thankyou_page != 'undefined' ) {
					window.location.href = storeup_localize_script_param.thankyou_page;
				}
			}
        });
    }

	// Location
	jQuery( "#storeup_bk_location" ).change(function() {
		jQuery('.storeup_bk_size').attr( 'data-loc', jQuery(this).val() );
		var iva_loc_id = jQuery(this).val();
		var iva_loc_size = jQuery('.storeup_bk_size').val();
		var iva_loc_price = jQuery(this).attr('data-price');
		storeup_loc_pricings( iva_loc_id, iva_loc_price, iva_loc_size);
	}).change();

	jQuery(".storeup_bk_size").change(function() {
		var iva_loc_id = jQuery('.storeup_bk_size').attr('data-loc');
		if ( iva_loc_id == null ) {
			var iva_loc_id = jQuery('.storeup_bk_location').val();
		}
		var iva_loc_size = jQuery(this).val();
		var iva_loc_price = jQuery('.storeup_bk_location').attr('data-price');
		storeup_loc_pricings( iva_loc_id, iva_loc_price, iva_loc_size);
	}).change();

	function storeup_loc_pricings( iva_loc_id, iva_loc_price, iva_loc_size ){
		jQuery.ajax({
			url: storeup_localize_script_param.ajaxurl,
			type: 'post',
			dataType: 'html',
			data: {
				action     : 'storeup_bk_loc_pricings',
				iva_loc_id : iva_loc_id,
				loc_price  : iva_loc_price,
				loc_size   : iva_loc_size,
			},
			success: function( response ){
				jQuery('.iva_bk_pricings').html(response).show();
				jQuery('.at-bk-units-item').click(function(){
					jQuery('.at-bk-units-item').removeClass('is-selected');
					jQuery(this).addClass('is-selected');
				});
		   }
		});
	}

	$('#at-wg-loc-tabs').change(function(){
		var loc_opt = $(this).val();
		$( ".at-wg-loc-tab-list-content" ).hide();
		$( "#" + loc_opt ).fadeIn(800);
		$( ".at-wg-loc-tabs" ).fadeOut(800);
	}).change();
});