<?php
/*
Template Name: Booking
*/
get_header(); ?>
<div id="primary" class="pagemid">
	<div class="inner">

		<main class="content-area">
		<div class="entry-content-wrapper clearfix">
			<?php
				global $storeup_theme_ob;

				$storeup_js_defaultdate 		= storeup_get_js_defaultdate();
				$storeup_bk_weather_location 	= get_option( 'storeup_weather_loc' ) ? get_option( 'storeup_weather_loc' ) : 'Hyderabad,IN';
				$storeup_bk_weather_unit 	  	= get_option( 'storeup_weather_unit' ) ? get_option( 'storeup_weather_unit' ) : 'f';
				$storeup_bk_cal_firstday		= get_option( 'storeup_first_day' );
				$storeup_disable_days  			= get_option( 'storeup_disable_days' ) ? get_option( 'storeup_disable_days' ):'';
				$storeup_bk_disable_weekdays    = get_option( 'storeup_disable_weekdays' ) ? get_option( 'storeup_disable_weekdays' ):'';
				if ( ! empty( $storeup_bk_disable_weekdays ) ) {
					$storeup_disable_weekdays = implode( ', ',$storeup_bk_disable_weekdays );
				}
				$storeup_bk_frm_heading1_txt  = get_option( 'storeup_bk_heading1_txt' ) ? get_option( 'storeup_bk_heading1_txt' ) : '';
				$storeup_bk_frm_heading2_txt  = get_option( 'storeup_bk_heading2_txt' ) ? get_option( 'storeup_bk_heading2_txt' ) : '';
				$storeup_bk_name_txt		  = get_option( 'storeup_bk_fnametxt' ) ? get_option( 'storeup_bk_fnametxt' ) : esc_html__( 'Your Name','storeup' );
				$storeup_bk_phone_txt		  = get_option( 'storeup_bk_phonetxt' ) ? get_option( 'storeup_bk_phonetxt' ) : esc_html__( 'Phone Number','storeup' );
				$storeup_bk_email_txt		  = get_option( 'storeup_bk_emailtxt' ) ? get_option( 'storeup_bk_emailtxt' ) : esc_html__( 'Email ID','storeup' );
				$storeup_bk_captcha_txt  	  = get_option( 'storeup_bk_captchatxt' ) ? get_option( 'storeup_bk_captchatxt' ) : esc_html__( 'Captcha','storeup' );
				$storeup_bk_fax_txt		  	  = get_option( 'storeup_bk_fax_txt' ) ? get_option( 'storeup_bk_fax_txt' ) : esc_html__( 'Fax Number','storeup' );
				$storeup_bk_company_txt 	  = get_option( 'storeup_bk_company_txt' ) ? get_option( 'storeup_bk_company_txt' ) : esc_html__( 'Company Name', 'storeup' );
				$storeup_bk_address_txt 	  = get_option( 'storeup_bk_address_txt' ) ? get_option( 'storeup_bk_address_txt' ) : esc_html__( 'Street Address', 'storeup' );
				$storeup_bk_message_txt			= get_option( 'storeup_bk_message_txt' ) ? get_option( 'storeup_bk_message_txt' ) : esc_html__( 'Additional Notes', 'storeup' );
				$storeup_bk_city_txt		  = get_option( 'storeup_bk_city_txt' ) ? get_option( 'storeup_bk_city_txt ' ) : esc_html__( 'City','storeup' );
				$storeup_bk_state_txt		  = get_option( 'storeup_bk_state_txt' ) ? get_option( 'storeup_bk_state_txt ' ) : esc_html__( 'State / Province','storeup' );
				$storeup_bk_country_txt	  	  = get_option( 'storeup_bk_country_txt' ) ? get_option( 'storeup_bk_country_txt ' ) : esc_html__( 'Country','storeup' );
				$storeup_bk_zipcode_txt	  	  = get_option( 'storeup_bk_zipcode_txt' ) ? get_option( 'storeup_bk_zipcode_txt ' ) : esc_html__( 'Zip / Post Code:','storeup' );
				$storeup_bk_btn_txt		  	  = get_option( 'storeup_bk_buttontxt' ) ? get_option( 'storeup_bk_buttontxt' ) : esc_html__( 'Submit', 'storeup' );
				$storeup_bk_loc_txt	 	  	  = get_option( 'storeup_bk_loc_txt' ) ? get_option( 'storeup_bk_loc_txt ' ) : esc_html__( 'Storage Location','storeup' );
				$storeup_bk_loc_select_txt    = get_option( 'storeup_bk_loc_select_txt' ) ? get_option( 'storeup_bk_loc_select_txt ' ) : esc_html__( 'Select Location','storeup' );
				$storeup_bk_size_txt		  = get_option( 'storeup_bk_size_txt' ) ? get_option( 'storeup_bk_size_txt ' ) : esc_html__( 'Size','storeup' );
				$storeup_bk_datepicker_lang   = get_option( 'storeup_datepicker_language' ); 
				$loc_selected = isset($_GET['loc_id']) ? $_GET['loc_id'] : '';
				$loc_unit = isset($_GET['loc_unit']) ? $_GET['loc_unit'] : '';
				$storeup_locations = $storeup_theme_ob->storeup_get_vars( 'locations' );
				$args = array(
					'posts_per_page'   => -1,
					'offset'           => 0,
					'orderby'          => 'post_date',
					'order'            => 'DESC',
					'post_type'        => 'location',
					'post_status'      => 'publish',
					'suppress_filters' => true,
				);
				$storeup_loc_args = array(
					'post_type' => 'location',
					'posts_per_page' => -1,
				);
				$storeup_loc_title = array();
				$storeup_loc_query = new WP_Query( $storeup_loc_args );
				if ( $storeup_loc_query->have_posts() ) :
					while ( $storeup_loc_query->have_posts() ) : $storeup_loc_query->the_post();
						$storeup_units_pricing = get_post_meta( get_the_ID(), 'storeup_units_pricing', true );
						if ( ! empty( $storeup_units_pricing ) ) {
							foreach ( $storeup_units_pricing as $key => $value ) {
								if ( ! empty( $value['rate'] ) || ! empty( $value['ofr_rate'] ) ) {
									$storeup_loc_post_id = get_the_ID();
									$storeup_loc_title[ $storeup_loc_post_id ] = $post->post_name;
								}
							}
						}
					endwhile;
					else :
					endif;
					$storeup_loc_title = array_unique( $storeup_loc_title );
				?>
				<script type="text/javascript">
					jQuery(document).ready( function($) {
						var date_monthNames = '';
						<?php if ( $storeup_bk_datepicker_lang !='' ) { ?>
							$.datepicker.setDefaults($.datepicker.regional[ '<?php echo esc_js( $storeup_bk_datepicker_lang ); ?>' ] );
							var date_monthNames = $.datepicker.regional[ '<?php echo esc_js( $storeup_bk_datepicker_lang ); ?>' ].monthNames;
						<?php } ?>
							//Simple Weather
							jQuery.simpleWeather({
								location: '<?php echo esc_js( $storeup_bk_weather_location ); ?>',
								woeid: '',
								unit: '<?php echo esc_js( $storeup_bk_weather_unit ); ?>',
								success: function(weather) {
									html = '<h2><span class="wi icon-'+weather.code+'"></span> '+weather.temp+'&deg;'+weather.units.temp+'</h2>';
									html += '<ul><li>'+weather.city+', '+weather.region+'</li>';
									html += '<li class="currently">'+weather.currently+'</li>';
									html += '<li>'+weather.wind.direction+' '+weather.wind.speed+' '+weather.units.speed+'</li></ul>';
									jQuery("#storeup_bk_weather").html(html);
								},
								error: function(error) {
									jQuery("#storeup_bk_weather").html('<p>'+error.message+'</p>');
								}
							});
							// Callender Date,Month,Year
							var iva_cur_date      = new Date();
							//  language added Since 1.3
							if( date_monthNames != '' ){
								var iva_months = date_monthNames;
							}else{
								var	iva_months 		= [ "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December" ];
							}
							var iva_current_date  = iva_cur_date.getDate();
							var iva_current_month = iva_months[iva_cur_date.getMonth()];
							var iva_current_year  = iva_cur_date.getFullYear();
			
							// Callender Date,Month,Year
							jQuery('.storeup-bk-calDate').html( iva_current_date );
							jQuery('.storeup-bk-calMonth').html( iva_current_month );
							jQuery('.storeup-bk-calYear').html( iva_current_year );
			
							// Disable Specific Days:
							function iva_disable_specificdays(date) {
								// disable selected dates
								<?php if ( isset( $storeup_disable_days ) && ! empty( $storeup_disable_days ) ) { ?>
								var disabledDays = <?php echo str_replace('\\/', '/', json_encode( $storeup_disable_days )); ?>;
								var m 			 = date.getMonth();
								var d 			 = date.getDate();
								var y 			 = date.getFullYear();
								var current_date = (m + 1) + '/' + d + '/' + y ;
								for ( var k = 0; k < disabledDays.length; k++ ) {
									if ($.inArray(current_date, disabledDays) != -1 ) {
									return [0];
									}
								}
								<?php } ?>
								// disable week days
								<?php if ( isset( $storeup_disable_weekdays ) && ! empty( $storeup_disable_weekdays ) ) { ?>
								var disableweekDay = [ <?php echo esc_js( $storeup_disable_weekdays ); ?> ];
								var day = date.getDay();
								for ( j = 0; j < disableweekDay.length; j++ ) {
									if ($.inArray(day, disableweekDay) != -1) {
									   return [0];
									}
								}
								<?php } ?>
								return [1];
							}
			
							// Callender
							jQuery("#storeup_booking_date").datepicker({
								showOtherMonths: true,
								selectOtherMonths: true,
								nextText: "<?php echo esc_html__( 'Next', 'storeup' ); ?>",
								prevText: "<?php echo esc_html__( 'Prev', 'storeup' ); ?>",
								beforeShowDay : iva_disable_specificdays,
								dateFormat:'<?php echo esc_js( $storeup_js_defaultdate ); ?>',
								minDate: 0,
								firstDay: <?php echo ( $storeup_bk_cal_firstday !='' ) ? esc_js( $storeup_bk_cal_firstday ) :'0';?>,
								altField: "#storeup_bk_date",
							});
						});
					</script>
					<?php
					$out = '<div id="storeup-bk-formstatus"></div>';
					$out .= '<form id="storeup-bk-form" class="clearfix storeup-form" name="storeup_bk_form">';
					$out .= '<div class="col_third">';
					$out .= '<div class="storeup-bk-date-wrap">';
					$out .= '<div class="col_half nomargin">';
					$out .= '<div class="storeup-bk-date">';
					$out .= '<span class="storeup-bk-calDate"></span><span class="storeup-bk-calMonth"></span><span class="storeup-bk-calYear"></span>';
					$out .= '</div>';
					$out .= '</div>';

					$out .= '<div class="col_half nomargin end">';
					$out .= '<div id="storeup_bk_weather"></div>';
					$out .= '</div>';
					$out .= '</div>';

					// Calender Field
					$out .= '<div id="storeup_booking_date"></div>';
					$out .= '<input type="hidden" name="storeup_bk_date" id="storeup_bk_date" value="">';
					$out .= '</div>';// One_half ends here end

					$out .= '<div class="col_third">';
					if ( $storeup_bk_frm_heading1_txt ) {
						$out .= '<h4>' . $storeup_bk_frm_heading1_txt . '</h4>';
					}
					// Name
					$out .= '<div class="iva_bk_name">';
					$out .= '<label for="bk_name" class="bk_req">' . $storeup_bk_name_txt . '</label>';
					$out .= '<input type="text" id="storeup_bk_name" name="storeup_bk_name" value="" size="25" class="storeup_bk_name" />';
					$out .= '</div>';

					// Phone
					$out .= '<div class="iva_bk_phoneno">';
					$out .= '<label for="bk_phoneno" class="bk_req">' . $storeup_bk_phone_txt . '</label>';
					$out .= '<input type="text" id="storeup_bk_phoneno" name="storeup_bk_phoneno" value="" size="25" class="storeup_bk_phoneno" />';
					$out .= '</div>';

					// Email
					$out .= '<div class="iva_bk_email">';
					$out .= '<label for="bk_email" class="bk_req">' . $storeup_bk_email_txt . '</label>';
					$out .= '<input type="email" id="storeup_bk_email" name="storeup_bk_email" value="" size="25" class="storeup_bk_email"/>';
					$out .= '</div>';
					// Address
					$out .= '<div class="iva_bk_address">';
					$out .= '<label for="bk_address" class="bk_req">' . $storeup_bk_address_txt . '</label>';
					$out .= '<textarea id="storeup_bk_address" class="storeup_bk_address" name="storeup_bk_address" rows="6" cols="30"></textarea>';
					$out .= '</div>';

					// Zipcode
					$out .= '<div class="iva_bk_zipcode">';
					$out .= '<label for="bk_zipcode" class="bk_req">' . $storeup_bk_zipcode_txt . '</label>';
					$out .= '<input type="text" id="storeup_bk_zipcode" name="storeup_bk_zipcode" value="" size="25" class="storeup_bk_zipcode" />';
					$out .= '</div>';
					
					$out .= '</div>'; // col_third end
					$out .= '<div class="col_third last">';
					if ( $storeup_bk_frm_heading2_txt ) {
						$out .= '<h4>' . $storeup_bk_frm_heading2_txt . '</h4>';
					}
					// locations
					if ( ! empty( $storeup_loc_title ) ) {
					$storeup_price_val 	= isset($_GET['loc_price']) ? $_GET['loc_price'] : '';
						$out .= '<div class="iva_bk_locations">';
						$out .= '<label for="bk_location" class="bk_req">' . $storeup_bk_loc_txt . '</label>';
						$out .= '<select name="storeup_bk_location" data-price="'.$storeup_price_val.'"  id="storeup_bk_location" class="storeup_bk_location">';
						foreach ( $storeup_loc_title as $key => $value ) {
							$selected = '';
							if( $key == $loc_selected) { $selected = ' selected="selected"'; }
							$out .= '<option value= "' . $key . '" '.$selected .'>' . get_the_title( $key ) . '</option>';
						}
						$out .= '</select>';
						$out .= '</div>';
					}
					// size
					$storeup_bk_unit_size_txt = get_option( 'storeup_size_dimensions' ) ? get_option( 'storeup_size_dimensions' ) : esc_html( 'Sizes','storeup');
					$size_dim_name = get_option('storeup_size_dim_name');
					
					if( empty( $size_dim_name ) ){
						$size_dim_name = array( 
							'small' => esc_html__( 'Small', 'storeup' ) , 
							'medium' => esc_html__( 'Medium','storeup' ) , 
							'large' => esc_html__('Large','storeup'),
							'xlarge' => esc_html__('XLarge','storeup'),
						);
					}
					$out .= '<div class="iva_bk_size">';
					$out .= '<label for="bk_size" class="bk_req">' . esc_html( $storeup_bk_unit_size_txt ) . '</label>';
					$out .= '<select name="storeup_bk_size" id="storeup_bk_size"  data-loc="" class="storeup_bk_size">';
					foreach ( $size_dim_name as $key => $value ){
						$selected = '';
						if( $key == strtolower($loc_unit) ) { $selected = ' selected="selected"'; }
						$out .= '<option value="' . $key . '" '.$selected .'> ' . $value . ' </option>';
					}
					$out .= '</select>';
					$out .= '</div>';


					$out .= '<div class="iva_bk_pricings" style="display:none;"></div>';

					// Message
					$out .= '<div class="iva_bk_message">';
					$out .= '<label for="bk_message" class="bk_req">' . $storeup_bk_message_txt . '</label>';
					$out .= '<textarea id="storeup_bk_message" class="storeup_bk_message" name="storeup_bk_message" rows="6" cols="30"></textarea>';
					$out .= '</div>';

					// Captcha
					function storeup_bk_rand_string( $length ) {
						$chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
						$size = strlen( $chars );
						$str = '';
						for ( $i = 0; $i < $length; $i++ ) {
							$str .= $chars[ rand( 0, $size - 1 ) ];
						}
						return $str;
					}
					$storeup_bk_captcha = storeup_bk_rand_string( 6 );
					// Captcha
					$out .= '<div class="iva_bk_captcha">';
					$out .= '<label for="iva_lb_captcha" class="storeup_bk_captcha">' . $storeup_bk_captcha_txt . '</label>';
					$out .= '<span class="storeup_bk_captcha_string">' . $storeup_bk_captcha . '</span>';
					$out .= '<p><input type="text" class="bk_req storeup_bk_captcha" name="storeup_bk_captcha" id="storeup_bk_captcha"  value=""></p>';
					$out .= '<input type="hidden" name="storeup_bk_captcha_correct" id="storeup_bk_captcha_correct" value="' . $storeup_bk_captcha . '" />';
					$out .= '</div>';

					// Submit
					$out .= '<div class="iva_subbtn">';
					$out .= '<input type="button" name="submit" value="' . $storeup_bk_btn_txt . '" size="25" id="storeup_bk_submit" class="btn medium storeup_bk_submit"/>';
					$out .= '</div>';

					$out .= '</div>';
					$out .= '</form>';
					global $storeup_kses_array;
					echo wp_kses( $out, $storeup_kses_array );
				?>
		</div><!-- .entry-content-wrapper -->
		</main><!-- .content-area -->

		<?php if ( storeup_generator( 'storeup_sidebar_option', $post->ID ) !== 'fullwidth' ) { get_sidebar(); } ?>

	</div><!-- inner -->
	</div><!-- #primary.pagemid -->

<?php get_footer();
