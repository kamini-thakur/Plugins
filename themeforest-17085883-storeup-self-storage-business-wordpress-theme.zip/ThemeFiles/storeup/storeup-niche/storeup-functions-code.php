<?php
$storeup_kses_array = array(
	'a'  => array(
		'data-id' => true,
		'href' => true,
		'class' => true,
		'title' => true,
		'data-tab' => true,
	),
	'h1'       => array( 'class' => true ),
	'h2'       => array( 'class' => true ),
	'h3'       => array( 'class' => true ),
	'h4'       => array( 'class' => true ),
	'h5'       => array( 'class' => true ),
	'h6'       => array( 'class' => true ),
	'p' => array(
		'class' => true,
	),
	'em' => array(),
	'i'  => array(
		'class' => true,
	),
	'span' => array(),
	'small' => array(),
	'strike' => array(),
	'div' => array(
		'data-price' => true,
		'id' => true,
		'class' => true,
		'style' => true,
	),
	'select' => array(
		'class' => true,
		'name'  => true,
		'id'    => true,
	),
	'option'   => array(
		'value' => true,
		'selected' => true,
	),
	'button' => array(
		'name' => true,
		'id' => true,
		'class' => true,
		'type' => true,
		'value' => true,
	),
	'li'    => array(
		'class' => true,
		'style' => true,
	),
	'ul'    => array(
		'class' => true,
		'style' => true,
	),
	'span'    => array(
		'class' => true,
	),
	'heading'  => array(),
	'input'    => array(
		'checked' => true,
		'type' => true,
		'class' => true,
		'name' => true,
		'id' => true,
		'value' => true,
		'style' => true,
		'size' => true,
	),
	'label' => array(
		'for' => true,
		'class' => true,
	),
	'form' => array(
		'action' => true,
		'accept' => true,
		'accept-charset' => true,
		'class' => true,
		'id' => true,
		'enctype' => true,
		'method' => true,
		'name' => true,
		'target' => true,
	),
	'textarea' => array(
		'class' => true,
		'name' => true,
		'id' => true,
		'cols' => true,
		'rows' => true,
	),
	'strong'   => array(),
);

add_action( 'wp_ajax_storeup_bk_form_action', 'storeup_bk_form_action' );
add_action( 'wp_ajax_nopriv_storeup_bk_form_action', 'storeup_bk_form_action' );
function storeup_bk_form_action() {

	$storeup_post_form = isset( $_POST['data'] ) ? $_POST['data'] :'';

	/**
	 * function parse_str
	 * @param 'str' inpput string
	 * @param 'arr' If the second parameter arr is present, variables are stored in this variable as array elements instead.
	 * @return No value is returned.
	 */
	parse_str( $storeup_post_form, $storeup_form_data );

	$error = '';
	$post  = ( ! empty( $_POST ) ) ? true : false;

	$storeup_bk_name 		 = isset( $storeup_form_data['storeup_bk_name'] ) ? $storeup_form_data['storeup_bk_name'] :'';
	$storeup_bk_phoneno 	 = isset( $storeup_form_data['storeup_bk_phoneno'] ) ? $storeup_form_data['storeup_bk_phoneno']:'';
	$storeup_bk_email 		 = isset( $storeup_form_data['storeup_bk_email'] ) ? $storeup_form_data['storeup_bk_email'] :'';
	$storeup_bk_address 	 = isset( $storeup_form_data['storeup_bk_address'] ) ? $storeup_form_data['storeup_bk_address'] :'';
	$storeup_bk_zipcode 	 = isset( $storeup_form_data['storeup_bk_zipcode'] ) ? $storeup_form_data['storeup_bk_zipcode'] :'';
	$storeup_bk_date		 = isset( $storeup_form_data['storeup_bk_date'] ) ? $storeup_form_data['storeup_bk_date'] :'';
	$storeup_bk_location	 = isset( $storeup_form_data['storeup_bk_location'] ) ? $storeup_form_data['storeup_bk_location'] :'';
	$storeup_bk_price		 = isset( $storeup_form_data['storeup_bk_price'] ) ? $storeup_form_data['storeup_bk_price'] :'';
	$storeup_bk_message		 = isset( $storeup_form_data['storeup_bk_message'] ) ? $storeup_form_data['storeup_bk_message'] :'';

	if (
			$storeup_bk_name &&
			$storeup_bk_email &&
			$storeup_bk_date &&
			$storeup_bk_phoneno &&
			$storeup_bk_location &&
			$storeup_bk_price
		) {
		$storeup_default_date = get_option( 'storeup_date_format' ) ? get_option( 'storeup_date_format' ) :'Y/m/d';	
		if ( $storeup_bk_date ) {
			$storeup_booking_date = @date( $storeup_default_date, strtotime( $storeup_bk_date ) );
		}
		/**
	 	* Client Notification message
	 	*/
		$storeup_usr_placeholders  = array(
								'[first_name]',
								'[phone_no]',
								'[email]',
								'[address]',
								'[zipcode]',
								'[bk_date]',
								'[location]',
								'[price]',
								'[message]',
							 );
		$storeup_usr_values  = array(
							$storeup_bk_name,
							$storeup_bk_phoneno,
							$storeup_bk_email,
							$storeup_bk_address,
							$storeup_bk_zipcode,
							$storeup_booking_date,
							get_the_ID( $storeup_bk_location ),
							$storeup_bk_price,
							$storeuo_bk_message,
						);
		$storeup_client_notify_msg  	= get_option( 'storeup_bk_client_notify_msg' ); //get email message
		$storeup_client_notify_em_msg   = str_replace( $storeup_usr_placeholders, $storeup_usr_values, $storeup_client_notify_msg ); // Replace the placeholders

		/**
	 	* Admin Notification message
	 	*/
	 	$storeup_usr_placeholders  = array(
									'[first_name]',
									'[phone_no]',
									'[email]',
									'[address]',
								'[zipcode]',
								'[bk_date]',
								'[location]',
								'[price]',
								'[message]',
								 );
		$storeup_usr_values  = array(
								$storeup_bk_name,
								$storeup_bk_phoneno,
								$storeup_bk_email,
								$storeup_bk_zipcode,
								$storeup_bk_address,
							$storeup_booking_date,
							get_the_ID( $storeup_bk_location ),
							$storeup_bk_price,
							$storeup_bk_message,
							);

		$storeup_admin_notify_msg 		= get_option( 'storeup_bk_admin_notification_msg' ); // Get email message
		$storeup_admin_notify_em_msg   = str_replace( $storeup_admin_placeholders,$storeup_admin_values,$storeup_admin_notify_msg ); // Replace the placeholders

		/**
	 	* Notification Subject
	 	*/
		$storeup_client_notify_sub 	= get_option( 'storeup_bk_client_notify_subject' );
		$storeup_subj_placeholders     = array( '[first_name]' );
		$storeup_subj_values           = array( $storeup_bk_name );
		$storeup_notify_email_subject	= str_replace( $storeup_subj_placeholders,$storeup_subj_values,$storeup_client_notify_sub ); // Replace the placeholders

		/**
	 	* Send email
	 	*/
		$storeup_client_email = $storeup_bk_email;
		$storeup_admin_email  = get_option( 'storeup_bk_admin_emailid' );

		/**
	 	* Headers
	 	*/
		$storeup_bk_headers_msg = get_option( 'storeup_bk_headers_msg' ) ? get_option( 'storeup_bk_headers_msg' ): get_option( 'blogname' );
		$storeup_client_headers = esc_html__( 'From: ', 'storeup' ) . $storeup_bk_headers_msg . esc_html__( ' Booking', 'storeup' ) . '<' . $storeup_admin_email . '>' . "\r\n\\";
		$storeup_admin_headers = esc_html__( 'From: ', 'storeup' ) . $storeup_bk_headers_msg . esc_html__( ' Booking', 'storeup' ) . ' <' . $storeup_client_email . '>' . "\r\n\\";

		/**
		 * Sends mail to user mail
		 */
		wp_mail( $storeup_bk_email, $storeup_notify_email_subject, $storeup_client_notify_em_msg, $storeup_client_headers );

		/**
		 * Sends mail to admin email
		 */
		wp_mail( $storeup_admin_email, $storeup_notify_email_subject, $storeup_admin_notify_em_msg, $storeup_admin_headers );
		$storeup_bk_msg  			 = get_option( 'storeup_bk_thankyou_msg' ) ? get_option( 'storeup_bk_thankyou_msg' ): esc_html__( 'Thank you for booking appointment','storeup' );
		$storeup_bk_placeholders 	 = array( '[first_name]' );
		$storeup_bk_values 		 = array( $storeup_bk_name );
		$storeup_bk_thanku_message  = str_replace( $storeup_bk_placeholders, $storeup_bk_values, $storeup_bk_msg ); // Replace the placeholders
		$storeup_bk_response 		 = '<div id="storeup-bk-msg" class="iva_message_box success iva-box-solid iva-box-normal clearfix"><div class="iva_message_box_content">' . $storeup_bk_thanku_message . '</div></div>';
	} else {
			/**
			 * If error occurs in validation
			 */
		$storeup_bk_response = '<div id="storeup-bk-msg" class="iva_message_box error iva-box-solid iva-box-normal clearfix"><div class="iva_message_box_content">' . esc_html__( 'error', 'storeup' ) . '</div></div>';
	}
	echo wp_kses_post( $storeup_bk_response );
	die();
}
