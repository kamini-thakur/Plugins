<?php
function storeup_skin_generator() {
	$storeup_option_var = array(
	'storeup_themecolor',
	'storeup_site_title',
	'storeup_tagline',
	'storeup_page_preloader_image',
	'storeup_page_preloader_bgcolor',
	'storeup_headerproperties',
	'storeup_topbar_bgcolor',
	'storeup_topbar_text',
	'storeup_topbar_link',
	'storeup_bodyproperties',
	'storeup_overlayimages',
	'storeup_subheaderproperties',
	'storeup_subheader_textcolor',
	'storeup_footer_area_middle',
	'storeup_footer_area_bottom',
	'storeup_footer_area_top',
	'storeup_content_area_bg',
	'storeup_breadcrumbtext',
	'storeup_mmenu_bg',
	'storeup_mmenu_font',
	'storeup_mmenu_hoverbg',
	'storeup_mmenu_linkhover',
	'storeup_mmenu_dd_bg',
	'storeup_mmenu_dd_link',
	'storeup_mmenu_dd_linkhover',
	'storeup_mmenu_dd_hoverbg',
	'storeup_mmenu_active_link',
	'storeup_link',
	'storeup_linkhover',
	'storeup_subheaderlink',
	'storeup_subheaderlinkhover',
	'storeup_footerlink',
	'storeup_footerlinkhover',
	'storeup_copyrightlink',
	'storeup_copyrightlinkhover',
	'storeup_bodyfont',
	'storeup_headingfont',
	'storeup_mainmenufont',
	'storeup_bodyp',
	'storeup_countdown_font',
	'storeup_h1',
	'storeup_h2',
	'storeup_h3',
	'storeup_h4',
	'storeup_h5',
	'storeup_h6',
	'storeup_sidebar_widget_title',
	'storeup_footer_widget_title',
	'storeup_footer_widget_text',
	'storeup_copyright_text',
	'storeup_extracss',
	'storeup_footer_area_top_bg_color',
	'storeup_footer_area_top_text_color',
	'storeup_footer_area_top_link_color',
	'storeup_footer_area_top_link_hover_color',
	'storeup_footer_area_bottom_bg_color',
	'storeup_footer_area_bottom_text_color',
	'storeup_footer_area_bottom_link_color',
	'storeup_footer_area_bottom_link_hover_color',
	);

	foreach ( $storeup_option_var as $value ) {
		$$value = get_option( $value );
	}

	$storeup_page_bg_properties = get_post_meta( get_the_ID(),'storeup_page_bg_prop', true );

	if( !empty( $storeup_page_bg_properties ) ){
		$storeup_page_bg_properties = array(
			'image' => $storeup_page_bg_properties['0']['image'],
			'repeat' => $storeup_page_bg_properties['0']['repeat'],
			'position' => $storeup_page_bg_properties['0']['position'],
			'color' => $storeup_page_bg_properties['0']['color'],
			'attachment' => $storeup_page_bg_properties['0']['attachement'],
		);
	}

	$storeup_sh_bg_properties = get_post_meta( get_the_ID(),'storeup_subheader_img', true );
	if ( ! empty( $storeup_sh_bg_properties ) ) {
		$storeup_sh_bg_properties = array(
			'image' => $storeup_sh_bg_properties['0']['image'],
			'repeat' => $storeup_sh_bg_properties['0']['repeat'],
			'position' => $storeup_sh_bg_properties['0']['position'],
			'color' => $storeup_sh_bg_properties['0']['color'],
			'attachment' => $storeup_sh_bg_properties['0']['attachement'],
		);
	}

	$custom_css = '';

	$theme_color = isset( $storeup_themecolor ) ? $storeup_themecolor : '';
	if ( '' !== $theme_color ) {
		$custom_css = "
	#back-top span,
	.copyright,
	.button,
	button,
	.footer-area-top,
	input[type='button'],
	input[type='reset'], input[type='submit'],
	.woocommerce a.button,
	.woocommerce button.button,
	.woocommerce input.button,
	.woocommerce-cart .wc-proceed-to-checkout a.checkout-button,
	.woocommerce input.button.alt,
	.post-password-form input[type='submit'],
	.contributor-posts-link,
	.singlepost .tagcloud a,
	.at-cases-details:after,
	.ac_wrap .ac_title.active,
	.at-unit-price-tabs-wrap,
	.at-unit-btn,
	.at-more-locations-btn,
	.contributor-posts-link,
	input[type='button'],
	input[type='reset'],
	input[type='submit'],
	.storeup-bk-date-wrap,
	#at-wg-loc-tabs,
	.iva-date-ui.ui-datepicker .ui-state-default:hover,
	.iva-date-ui.ui-widget-content .ui-state-active {
		background-color:{$theme_color} !important;
	}

	.content-area a,
	.widget a,
	.client-name,
	.storeup_tip,
	.ivaSearch.icnalign,
	.at_location_box i,
	#footer .contactinfo-wrap .icon,
	.breadcrumbs > span i.fa,
	.product-categories .cat-item a:hover:after,
	.at-staff-wapper .at-staff-info .info i,
	.widget_postslist li .pdesc a:hover,
	.widget_postslist li .w-postmeta:before,
	.woocommerce nav.woocommerce-pagination ul li a,
	.woocommerce nav.woocommerce-pagination ul li span,
	.woocommerce nav.woocommerce-pagination ul li a:focus,
	.woocommerce nav.woocommerce-pagination ul li a:hover,
	.woocommerce nav.woocommerce-pagination ul li span.current { 
		color:{$theme_color};
	}

	.fancytitle span,
	blockquote,
	.iva-tabs li.current,
	.woocommerce ul.products li.product a:hover img,
	.at-vacancy-table-wrap .at-vacancy-table thead th.headerSortDown,
	.at-person.grid ul li:hover .at-person-image img,
	#sidebar .widget_nav_menu li.current_page_item > a,
	#sidebar .widget_nav_menu li.current_page_item > a:hover,
	#sidebar .widget_nav_menu li.current_page_item a,
	.woocommerce nav.woocommerce-pagination ul li a:focus,
	.woocommerce nav.woocommerce-pagination ul li a:hover,
	.woocommerce nav.woocommerce-pagination ul li span.current,
	.woocommerce ul.products li.product a:hover img {
		border-color:{$theme_color} ;
	}";
	} // End if().

	$custom_css .= storeup_generate_font_prop( array(
		'h1#site-title a',
		), $storeup_site_title
	);
	$custom_css .= storeup_generate_font_prop( array(
		'h2#site-description',
		), $storeup_tagline
	);

	$custom_css .= storeup_gen_css_prop( array(
		'.storeup_page_loader',
		), array(
			'background-color' => $storeup_page_preloader_bgcolor,
			'background-image' => 'url( ' . STOREUP_THEME_URI . '/images/svg-loaders/' . $storeup_page_preloader_image . ')',
		)
	);

	$custom_css .= storeup_gen_css_prop( array(
		'.topbar',
		), array(
			'background-color' => $storeup_topbar_bgcolor,
		 	'color' => $storeup_topbar_text,
		)
	);

	$custom_css .= storeup_gen_css_prop( array(
		'.topbar a',
		), array(
			'color' => $storeup_topbar_link,
		)
	);
	$custom_css .= storeup_generate_image_prop( array(
		'.header',
		), $storeup_headerproperties
	);
	$custom_css .= storeup_generate_image_prop( array(
		'body',
		), $storeup_bodyproperties
	);
	$custom_css .= storeup_generate_image_prop( array(
		'body',
		), $storeup_page_bg_properties
	);

	if ( ! empty( $storeup_overlayimages ) ) {
		$custom_css .= storeup_gen_css_prop( array(
			'.bodyoverlay',
			), array(
				'background-image' => 'url( ' . STOREUP_THEME_URI . '/images/patterns/' . $storeup_overlayimages . ')',
			)
		);
	}

	//$custom_css .= storeup_generate_image_prop( array(
		//'.header_section',
		//), $storeup_subheaderproperties
	//);

	$custom_css .= storeup_generate_image_prop( array(
		'#subheader',
		), $storeup_subheaderproperties
	);
	$custom_css .= storeup_gen_css_prop( array(
		'#subheader .page-title',
		), array(
			'color' => $storeup_subheader_textcolor,
		)
	);
	$custom_css .= storeup_generate_image_prop( array(
		'.footer-area-middle',
		), $storeup_footer_area_middle
	);
	$custom_css .= storeup_gen_css_prop( array(
		'.footer-area-bottom',
		), array(
			'background-color' => $storeup_footer_area_bottom,
		)
	);
	$custom_css .= storeup_gen_css_prop( array(
		'.footer-area-top',
		), array(
			'background-color' => $storeup_footer_area_top,
		)
	);
	$custom_css .= storeup_gen_css_prop( array(
		'.footer-area-top',
		), array(
			'background-color' => $storeup_footer_area_top,
		)
	);
	$custom_css .= storeup_gen_css_prop( array(
		'.pagemid',
		), array(
			'background-color' => $storeup_content_area_bg,
		)
	);
	$custom_css .= storeup_gen_css_prop( array(
		'.breadcrumbs',
		), array(
			'color' => $storeup_breadcrumbtext,
		)
	);
	
	$custom_css .= storeup_gen_css_prop( array(
		'.content-area a',
		'.widget li a',
		), array(
			'color' => $storeup_link,
		)
	);
	$custom_css .= storeup_gen_css_prop( array(
		'.content-area a:hover',
		'.widget li a:hover',
		), array(
			'color' => $storeup_linkhover,
		)
	);
	$custom_css .= storeup_gen_css_prop( array(
		'#subheader a',
		), array(
			'color' => $storeup_subheaderlink,
		)
	);
	$custom_css .= storeup_gen_css_prop( array(
		'#subheader a:hover',
		), array(
			'color' => $storeup_subheaderlinkhover,
		)
	);
	$custom_css .= storeup_gen_css_prop( array(
		'.footer-area-middle a',
		'.footer-area-middle .widget a',
		), array(
			'color' => $storeup_footerlink,
		)
	);
	$custom_css .= storeup_gen_css_prop( array(
		'.footer-area-middle a:hover',
		'.footer-area-middle .widget a:hover',
		), array(
			'color' => $storeup_footerlinkhover,
		)
	);
	$custom_css .= storeup_gen_css_prop( array(
		'.copyright a',
		), array(
			'color' => $storeup_copyrightlink,
		)
	);
	$custom_css .= storeup_gen_css_prop( array(
		'.copyright a:hover',
		), array(
			'color' => $storeup_copyrightlinkhover,
		)
	);
	$custom_css .= storeup_gen_css_prop( array(
		'body',
		), array(
			'font-family' => $storeup_bodyfont,
		)
	);
	$custom_css .= storeup_gen_css_prop( array( 'h1', 'h2', 'h3', 'h4', 'h5', 'h6' ), array( 'font-family' => $storeup_headingfont ) );
	$custom_css .= storeup_gen_css_prop( array(
		'.sf-menu',
		), array(
			'font-family' => $storeup_mainmenufont,
		)
	);
	$custom_css .= storeup_gen_css_prop( array(
		'.countdown-amount',
		'.countdown-section',
		), array(
			'font-family' => $storeup_countdown_font,
		)
	);

	$custom_css .= storeup_generate_font_prop( array(
		'body', 'input', 'select', 'textarea',
		), $storeup_bodyp
	);
	$custom_css .= storeup_generate_font_prop( array( 'h1' ), $storeup_h1 );
	$custom_css .= storeup_generate_font_prop( array( 'h2' ), $storeup_h2 );
	$custom_css .= storeup_generate_font_prop( array( 'h3' ), $storeup_h3 );
	$custom_css .= storeup_generate_font_prop( array( 'h4' ), $storeup_h4 );
	$custom_css .= storeup_generate_font_prop( array( 'h5' ), $storeup_h5 );
	$custom_css .= storeup_generate_font_prop( array( 'h6' ), $storeup_h6 );
	$custom_css .= storeup_generate_font_prop( array(
		'.widget-title',
		), $storeup_sidebar_widget_title
	);
	$custom_css .= storeup_generate_font_prop( array(
		'#footer .widget-title',
		), $storeup_footer_widget_title
	);
	$custom_css .= storeup_generate_font_prop( array(
		'#footer',
		), $storeup_footer_widget_text
	);

	$custom_css .= storeup_generate_font_prop( array( '.copyright' ), $storeup_copyright_text );

	// Footer Area Top Properties
	$custom_css .= storeup_gen_css_prop( array(
		'.footer-area-top',
		), array(
			'background-color' => $storeup_footer_area_top_bg_color,
		 	'color' => $storeup_footer_area_top_text_color,
		)
	);
	$custom_css .= storeup_gen_css_prop( array(
		'.footer-area-top a',
		), array(
		'color' => $storeup_footer_area_top_link_color,
		)
	);
	$custom_css .= storeup_gen_css_prop( array(
		'.footer-area-top a:hover',
		), array(
		'color' => $storeup_footer_area_top_link_hover_color,
		)
	);
	// Footer Area Top Properties
	$custom_css .= storeup_gen_css_prop( array(
		'.footer-area-bottom',
		), array(
			'background-color' => $storeup_footer_area_bottom_bg_color,
		 	'color' => $storeup_footer_area_bottom_text_color,
		)
	);
	$custom_css .= storeup_gen_css_prop( array(
		'.footer-area-bottom a',
		), array(
		'color' => $storeup_footer_area_bottom_link_color,
		)
	);
	$custom_css .= storeup_gen_css_prop( array(
		'.footer-area-bottom a:hover',
		), array(
		'color' => $storeup_footer_area_bottom_link_hover_color,
		)
	);

	// Menu Background for header 3,2
	$custom_css .= storeup_gen_css_prop( array(
		'.header-style2 .primarymenu',
		'.header-style3 .primarymenu'
		), array(
		 	'background-color' => $storeup_mmenu_bg,
		)
	);

	// Menu font color and properties
	$custom_css .= storeup_generate_font_prop( array(
		'.sf-menu a',
		'.header-style3 .sf-menu > li > a'
		), $storeup_mmenu_font
	);

	// Menu Link Hover Background - Parent
	$custom_css .= storeup_gen_css_prop( array(
		'.header-style .sf-menu li:hover'
		), array(
		 	'background-color' => $storeup_mmenu_hoverbg,
		)
	);

	// Menu Link Hover Color
	$custom_css .= storeup_gen_css_prop( array(
		'.sf-menu a:hover',
		'.header-style3 .sf-menu > li > a:hover'
		), array(
		 	'color' => $storeup_mmenu_linkhover,
		)
	);

	// Menu Dropdown Background
	$custom_css .= storeup_gen_css_prop( array(
		'.sf-mega, .sf-menu ul'
		), array(
		 	'background-color' => $storeup_mmenu_dd_bg,
		)
	);

	// Menu Dropdown Link Color
	$custom_css .= storeup_gen_css_prop( array(
		'.sf-menu ul a'
		), array(
		 	'color' => $storeup_mmenu_dd_link,
		)
	);

	// Menu Dropdown Link Color
	$custom_css .= storeup_gen_css_prop( array(
		'.sf-menu li li:hover',
		'.sf-menu li li:hover ul',
		'.sf-menu li li.sfHover',
		'.sf-menu li li a:focus',
		'.sf-menu li li a:hover',
		'.sf-menu li li a:active'
		), array(
		 	'color' => $storeup_mmenu_dd_linkhover,
		)
	);

	// Menu Dropdown Link Color
	$custom_css .= storeup_gen_css_prop( array(
	'.sf-menu li li:hover',
	'.sf-menu li li:hover ul',
	'.sf-menu li li.sfHover',
	'.sf-menu li li a:focus',
	'.sf-menu li li a:hover',
	'.sf-menu li li a:active'
		), array(
		 	'background-color' => $storeup_mmenu_dd_hoverbg,
		)
	);

	// Menu Active Link Background
	$custom_css .= storeup_gen_css_prop( array(
		'.header-style3 .sf-menu li.current-menu-item > a',
		'.header-style3 .sf-menu li.current-menu-ancestor > a',
		'.header-style3 .sf-menu li.current-page-ancestor > a'
		), array(
		 	'color' => $storeup_mmenu_active_link,
		)
	);

	// Individual Page Subheader Properties
	$custom_css .= storeup_generate_image_prop( array(
		'.subheader_bg_image',
		'.header_section_bg',
		), $storeup_sh_bg_properties
	);
	
	// Custom CSS from theme options
	$custom_css .= $storeup_extracss;

	wp_add_inline_style( 'storeup-responsive', $custom_css );
}
add_action( 'wp_enqueue_scripts', 'storeup_skin_generator', 2000 );

//for font css attributes
function storeup_generate_font_prop( $selectors = null, $arr_var = null ) {
$css = $inline_css = '';

$size			= isset( $arr_var['size'] ) 			? 'font-size:' . $arr_var['size'] . ';' : '';
$color			= isset( $arr_var['color'] ) 		? 'color:' . $arr_var['color'] . ';' : '';
$lineheight		= isset( $arr_var['lineheight'] )	? 'line-height:' . $arr_var['lineheight'] . ';' : '';
$style			= isset( $arr_var['style'] ) 		? 'font-style:' . $arr_var['style'] . ';' : '';
$variant		= isset( $arr_var['fontvariant'] ) 	? 'font-weight:' . $arr_var['fontvariant'] . ';' : '';

$css = "{$size} {$color} {$lineheight} {$style} {$variant}";
$css = trim( $css );

if ( isset( $selectors ) ) {
	if ( is_array( $selectors ) && ! empty( $selectors ) ) {
		$inline_css .= implode( ",\n$inline_css",  $selectors );
	}
}
// Apply inline CSS
if ( '' == trim( $inline_css ) ) {
	$inline_css .= $css;
} else {
	$inline_css .= '{ ' . $css . '} ';
}
// Format/Clean the CSS.
$inline_css = "\n" . $inline_css;
if ( '' != $css ) {
	return $inline_css;
}

}

//for background image css attributes
function storeup_generate_image_prop( $selectors = null, $arr_var = null ) {

$css = $inline_css = '';

$image			= isset( $arr_var['image'] ) 	? 'background-image:url( ' . $arr_var['image'] . ' );' : '';
$repeat			= isset( $arr_var['repeat'] ) 	? 'background-repeat:' . $arr_var['repeat'] . ';' : '';
$position		= isset( $arr_var['position'] )	? 'background-position:' . $arr_var['position'] . ';' : '';
$color			= isset( $arr_var['color'] ) 	? 'background-color:' . $arr_var['color'] . ';' : '';
$attachment		= isset( $arr_var['attachment'] ) ? 'background-attachment:' . $arr_var['attachment'] . ';' : '';

if ( '' !== $image ) {
	$css = "{$image} {$repeat} {$position} {$color} {$attachment}";
} else {
	$css = "{$color}";
}

if ( isset( $selectors ) ) {
	if ( is_array( $selectors ) && ! empty( $selectors ) ) {
		$inline_css .= implode( ",\n$inline_css",  $selectors );
	}
}
// Apply inline CSS
if ( '' == trim( $inline_css ) ) {
	$inline_css .= $css;
} else {
	$inline_css .= '{ ' . $css . '} ';
}

// Format/Clean the CSS.
$inline_css = "\n" . $inline_css;
if ( '' != $css ) {
	return $inline_css;
}
}

function storeup_gen_css_prop( $selectors = null, $properties = null ) {
$css = $inline_css = '';

if ( is_array( $properties ) && ! empty( $properties ) ) {
	foreach ( $properties as $name => $value ) {
		if ( '' != $value ) {
			if ( 'font-family' === $name ) {
				$value = '"' . $value . '"';
			}
			$css .= "$name:$value; ";
		}
	}
}
if ( isset( $selectors ) ) {
	if ( is_string( $selectors ) && '' != $selectors ) {
		$inline_css .= $selectors;
	} elseif ( is_array( $selectors ) && ! empty( $selectors ) ) {
		$inline_css .= implode( ",\n$inline_css",  $selectors );
	}
}
// Apply inline CSS
if ( '' == trim( $inline_css ) ) {
	$inline_css .= $css;
} else {
	$inline_css .= '{ ' . $css . '} ';
}

// Format/Clean the CSS.
$inline_css = "\n" . $inline_css;
if ( '' != $css ) {
	return $inline_css;
}
}
