<?php
$storeup_owlslider_limit = get_option( 'storeup_owlslidelimit' ) ? get_option( 'storeup_owlslidelimit' ) : '5';
$storeup_pageslider = get_post_meta( $post->ID,'storeup_page_slider', true );
if ( '' !== $storeup_pageslider ) {
	$storeup_slider_cat = get_post_meta( $post->ID,'storeup_slidercat', true );
} else {
	$storeup_slider_cat = get_option( 'storeup_owlslidercat' );
}
?>
<section id="featured_slider" class="clearfix">
<?php do_action( 'storeup_theme_owlcarouselslider', $post->ID );?>
	<div class="slider_wrapper">
		<div class="container">
			<div id="owlcarousel_slider" class="owl-carousel storeup-owl-theme">
				<?php
				$storeup_slider_query = array(
					'post_type'			=> 'slider',
					'posts_per_page'	=> $storeup_owlslider_limit,
					'tax_query' => array(
						'relation' => 'OR',
					),
					'orderby'			=> 'menu_order',
					'order'				=> 'ASC',
				);

				if ( '' !== $storeup_slider_cat ) {
					$storeup_tax_cat = array(
						'taxonomy' 		=> 'slider_cat',
						'field' 		=> 'slug',
						'terms' 		=> $storeup_slider_cat,
					);
					array_push( $storeup_slider_query['tax_query'], $storeup_tax_cat );
				}
				$storeup_slider = new WP_Query( $storeup_slider_query );
				while ( $storeup_slider->have_posts() ) : $storeup_slider->the_post();
					$storeup_terms = get_the_terms( get_the_ID(), 'slider_cat' );
					$storeup_terms_slug = array();
					if ( is_array( $storeup_terms ) ) {
						foreach ( $storeup_terms as $term ) {
							$storeup_terms_slug[] = $term->slug;
						}
					}
					$width = ''; $height = '';
					if ( 'stretched' === get_option( 'storeup_layoutoption' ) ) {
						$width = '1920';
					} else {
						$width = '1200';
					}
					$storeup_postlinktype_options 	= get_post_meta( get_the_ID(), 'storeup_postlinktype_options', true );
					$storeup_owl_slider_desc		= get_post_meta( get_the_ID(), 'storeup_slider_desc', true );
					$storeup_postlinkurl 			= storeup_generator( 'storeup_post_link_to', $storeup_postlinktype_options );
					$storeup_slidercaption 			= get_post_meta( get_the_ID(), 'storeup_slider_caption', true );
					echo ' <div class="item">';
					if ( $storeup_postlinkurl != 'nolink') {
						echo '<a href="' . esc_url( $storeup_postlinkurl ) . '"  >' . storeup_img_resize( get_the_ID(), '', $width, $height, '','' ) . '</a>';
					} else {
						echo storeup_img_resize( get_the_ID(),'', $width, $height, '' ,'' );
					}
					if ( $storeup_slidercaption != 'on' ) {
						echo '<div class="owl-caption">';
						echo '<div class="owl-caption-inner">';
						echo '<div class="owl-title">';
						echo '<h2>' . get_the_title() . '</h2>';
						if ( $storeup_owl_slider_desc != '' ) {
							echo do_shortcode( $storeup_owl_slider_desc );
						}
						echo '</div>'; //.owl-caption-inner
						echo '</div>'; //.flex-title
						echo '</div>'; //. flex-caption
					}
					echo '</div>';//.item
					endwhile;
					wp_reset_postdata();
				?>
			</div><!-- .blogcarousel -->
		</div><!-- .container -->
	</div><!-- .slider_wrapper -->
</section><!-- #featured_slider -->
<?php
