<?php

$fs_slidelimit = get_option( 'storeup_flexslidelimit' ) ? get_option( 'storeup_flexslidelimit' ) : '3';
$pageslider = get_post_meta( $post->ID,'storeup_page_slider', true );

if ( '' !== $pageslider ) {
	$slider_cat = get_post_meta( $post->ID,'storeup_slidercat', true );
} else {
	$slider_cat = get_option( 'storeup_flexslidercat' );
}
?>
<section id="featured_slider" class="clearfix">
<?php
do_action( 'storeup_theme_flexslider', $post->ID );
?>
	<div class="slider_wrapper">
		<div class="flexslider">
			<ul class="slides">
				<?php
				$query = array(
					'post_type'			=> 'slider',
					'posts_per_page'	=> $fs_slidelimit,
					'tax_query' => array(
						'relation' => 'OR',
					),
					'orderby'			=> 'menu_order',
					'order'				=> 'ASC',
				);

				if ( '' !== $slider_cat ) {
					$tax_cat = array(
						'taxonomy' 		=> 'slider_cat',
						'field' 		=> 'slug',
						'terms' 		=> $slider_cat,
					);
					array_push( $query['tax_query'],$tax_cat );
				}
				$storeup_slider = new WP_Query( $query );
				while ( $storeup_slider->have_posts() ) : $storeup_slider->the_post();
					$terms = get_the_terms( get_the_ID(), 'slider_cat' );
					$terms_slug = array();
					if ( is_array( $terms ) ) {
						foreach ( $terms as $term ) {
							$terms_slug[] = $term->slug;
						}
					}
					$width = '';
					$height = '';
					if ( 'stretched' === get_option( 'storeup_layoutoption' ) ) {
						$width = '';
					} else {
						$width = '1280';
					}

					$postlinktype_options 	= get_post_meta( get_the_ID(), 'storeup_postlinktype_options', true );
					$flex_sliderdescription	= get_post_meta( get_the_ID(), 'storeup_slider_desc', true );
					$postlinkurl 			= storeup_generator( 'storeup_post_link_to', $postlinktype_options );
					$slidercaption 			= get_post_meta( get_the_ID(), 'storeup_slider_caption', true );
					$slider_align = get_post_meta(get_the_ID(), 'storeup_slider_cap_align', true ) ? get_post_meta(get_the_ID(), 'storeup_slider_cap_align', true ) : 'center';
					switch ( $slider_align ) {
						case 'left':
									$slider_align_class = 'fs-left';
									break;
						case 'right':
									$slider_align_class = 'fs-right';
									break;
						case 'center':
									$slider_align_class = 'fs-center';
									break;
						default :
									$slider_align_class = 'fs-center';
					}
					echo '<li>';
					if ( $postlinkurl != 'nolink' ) {
						echo '<a href="' . esc_url( $postlinkurl ) . '"  >' . storeup_img_resize( get_the_ID(), '', $width,$height,'','' ) . '</a>';
					} else {
						echo storeup_img_resize( get_the_ID(),'',$width, $height,'' ,'' );
					}
				?>
				<?php if ( $slidercaption != 'on' ) {?>
				<div class="flex-caption <?php echo $slider_align_class; ?>">
					<div class="flex-caption-inner">
						<?php if ( $flex_sliderdescription != '' ) { ?>
						<div class="flex-title">
						<h5><?php the_title();?></h5>
						<?php if ( $flex_sliderdescription != '') {?>
						<div class="flex-content"><?php echo do_shortcode( $flex_sliderdescription ); ?></div>
						<?php } ?>
						</div><!-- .flex-title -->
						<?php } ?>
					</div><!-- .flex-caption-inner -->
				</div><!-- .flex-caption -->
				<?php } ?>
				</li>
				<?php
				endwhile;
				wp_reset_postdata(); ?>
			</ul>
		</div><!-- .flexslider -->
	</div><!-- .flexslider_wrap -->
</section><!-- #featured_slider -->
<?php
