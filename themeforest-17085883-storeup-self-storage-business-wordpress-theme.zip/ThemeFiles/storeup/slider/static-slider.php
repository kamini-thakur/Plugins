<?php // Static Slider; ?>
<div id="featured_slider">
	<div class="slider_wrapper">
		<div id="static-slider" class="staticslider">
		<?php
		$pageslider = get_post_meta( $post->ID, 'page_slider', true );
		$width = '';

		if ( 'boxed' === get_option( 'storeup_layoutoption' ) ) {
			$width = '1280';
		} else {
			$width = '1920';
		}

		if ( '' !== $pageslider ) {
			$src = get_post_meta( $post->ID, 'staticimage', true );
			$link = esc_url( get_post_meta( $post->ID, 'cimage_link', true ) );
		} else {
			$src = get_option( 'storeup_static_image_upload' );
			$link = esc_url( get_option( 'storeup_static_link' ) );
		}

		if ( '' !== $link ) {
			echo '<figure>' . storeup_img_resize( '', $src, $width, '', '', '' ) . '</figure>';
		} else {
			echo '<figure>' . storeup_img_resize( '', $src, $width, '', '', '' ) . '</figure>';
		}
		?>
		</div>
	</div>
</div>
<?php
