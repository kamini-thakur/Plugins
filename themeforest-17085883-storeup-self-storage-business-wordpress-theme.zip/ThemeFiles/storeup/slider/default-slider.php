<?php // Default Slider; ?>
<div id="featured_slider">
	<div class="slider_wrapper">
		<figure><img src="<?php echo esc_url( STOREUP_THEME_URI );?>/images/storeup-slider-static-img.jpg" height="720" alt="" /></figure>
	</div>
</div>
<?php
