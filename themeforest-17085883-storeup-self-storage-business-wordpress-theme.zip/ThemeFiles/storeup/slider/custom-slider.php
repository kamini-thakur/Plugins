<div id="featured_slider">
	<div class="slider_stretched">
	<?php
	$pageslider = get_post_meta( $post->ID,'page_slider', true );
	if ( '' !== $pageslider ) {
		$slider = get_post_meta( $post->ID,'customslider', true );
	} else {
		$slider = get_option( 'storeup_customslider' );
	}
	echo do_shortcode( $slider );
	?>
	</div>
</div>
<?php
