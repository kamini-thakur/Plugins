<?php
/* Footer Sidebar */
?>
</div><!-- #main -->
	<div id="footer">
		<?php
		// Footer Area Top
		if ( 'on' !== get_option( 'storeup_footer_area_top' ) ) {
			if ( is_active_sidebar( 'footer_area_top' ) ) {
				echo '<div class="footer-area-top"><div class="inner">';
				dynamic_sidebar( 'footer_area_top' );
				echo '</div></div>';
			}
		}
		if ( 'on' !== get_option( 'storeup_footer_sidebar' ) ) {
			// Get footer sidebar widgets
			if ( 'on' !== get_option( 'storeup_footer_sidebar' )
				&& is_active_sidebar( 'footercolumn1' )
				|| is_active_sidebar( 'footercolumn2' )
				|| is_active_sidebar( 'footercolumn3' )
				|| is_active_sidebar( 'footercolumn4' )
				|| is_active_sidebar( 'footercolumn5' )
				|| is_active_sidebar( 'footercolumn6' )
			) {
				echo '<div class="footer-area-middle">';
				echo '<div class="inner">';
				get_template_part( 'sidebar', 'footer' );
				echo '</div></div>'; // Footer
			}
		}
		// Footer Area Bottom
		if ( 'on' !== get_option( 'storeup_footer_area_bottom' ) ) {
			if ( is_active_sidebar( 'footer_area_bottom' ) ) {
				echo '<div class="footer-area-bottom"><div class="inner">';
				dynamic_sidebar( 'footer_area_bottom' );
				echo '</div></div>';
			}
		} ?>

		<?php if ( is_active_sidebar( 'footer_leftcopyright' ) || is_active_sidebar( 'footer_rightcopyright' ) ) {  ?>
		<div class="copyright">
			<div class="inner">
				<div class="copyright_left">
					<?php
					if ( is_active_sidebar( 'footer_leftcopyright' ) ) :
						dynamic_sidebar( 'footer_leftcopyright' );
					endif; ?>
				</div>
				<div class="copyright_right">
					<?php
					if ( is_active_sidebar( 'footer_rightcopyright' ) ) :
						dynamic_sidebar( 'footer_rightcopyright' );
					endif;
					if ( is_active_sidebar( 'footer-branches' ) ) {
						$storeup_footer_branch_btn_txt = get_option( 'storeup_footer_branch_btn_txt' )
							? get_option( 'storeup_footer_branch_btn_txt' )
							: esc_html__( 'More Branches', 'storeup' );
						echo '<a class="at-footer-branches">' . esc_html( $storeup_footer_branch_btn_txt ) . '</a>';
					}
					?>
				</div>

			</div><!-- .inner -->
		</div><!-- .copyright -->

		<?php } ?>
		<?php
		if ( is_active_sidebar( 'footer-branches' ) ) { ?>
			<div class="footer-branches">
				<div class="inner">
					<?php
					if ( is_active_sidebar( 'footer-branches' ) ) : dynamic_sidebar( 'footer-branches' );
					endif;
					?>
				</div>
			</div>
		<?php } ?>
	</div> <!-- .footer-area -->
</div><!-- #wrapper -->
</div><!-- #layout -->
<div id="back-top"><a href="#header" title="<?php echo esc_attr_e( 'Scroll Top','storeup' ); ?>"><span><i class="fa fa-angle-up fa-fw fa-2x"></i></span></a></div>

<?php
$storeup_headerstyle = get_option( 'storeup_headerstyle' ) ? get_option( 'storeup_headerstyle' ) : '';
if ( 'headerstyle4' === $storeup_headerstyle || 'headerstyle5' === $storeup_headerstyle) { ?>
</div><!-- .sidebar-leftmenu -->
<?php } ?>

<?php wp_footer();?>
</body>
</html>
<?php
