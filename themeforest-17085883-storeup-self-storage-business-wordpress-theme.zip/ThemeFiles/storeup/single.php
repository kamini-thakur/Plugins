<?php get_header(); ?>
<div id="primary" class="pagemid">
	<div class="inner">

		<main class="content-area">

			<div class="entry-content-wrapper clearfix">

			<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
			<?php get_template_part( 'template-parts/content', get_post_format() );?>
			<?php get_template_part( 'share','link' ); ?>

			<?php

			if ( get_option( 'storeup_aboutauthor' ) !== 'on' ) {
				storeup_generator( 'storeup_about_author' );
			}

			if ( get_option( 'storeup_relatedposts' ) !== 'on' ) {
				storeup_generator( 'storeup_related_posts', $post->ID );
			}

			comments_template( '', true );

			if ( get_option( 'storeup_singlenavigation' ) !== 'on' ) {
				if ( get_previous_post_link() || get_next_post_link() ) { ?>
					<div class="navigation-section">
						<div class="navigation-post">
							<div class="nav-previous">
								<div class="innerlinks">
									<?php previous_post_link('<span class="nav-icon-left"><i class="fa  fa-chevron-left fa-lg"></i></span>
									<p> %link </p>') ?>
								</div>
							</div>
							<div class="nav-next">
								<div class="innerlinks">
									<?php next_post_link('<span class="nav-icon-right"><i class="fa  fa-chevron-right fa-lg"></i></span>
									<p>%link</p>') ?>
								</div>
							</div>
						</div>
					</div>
				<?php
				}
			} else {
				posts_nav_link();
			}
			?>

			<?php endwhile; ?>

			<?php else : ?>
			<?php '<p>' . esc_html__( 'Sorry, no posts matched your criteria.', 'storeup' ) . '</p>';?>

			<?php endif; ?>

			</div><!-- .entry-content-wrapper-->

		</main><!-- .content-area -->
		<?php if ( storeup_generator( 'storeup_sidebar_option', $post->ID ) !== 'fullwidth' ) { get_sidebar(); } ?>

		<div class="clear"></div>

	</div><!-- .inner -->
</div><!-- .pagemid -->
<?php
get_footer();
