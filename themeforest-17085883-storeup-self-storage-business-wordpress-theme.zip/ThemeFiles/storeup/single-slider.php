<?php get_header(); ?>
<div id="primary" class="pagemid">
	<div class="inner">
		<div class="content-area">
			<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
			<?php get_template_part( 'content', get_post_format() );  ?><!-- /postmetadata -->
			<div id="post-<?php the_ID(); ?>" <?php post_class();?>>
				<div class="post_content">
				<?php
				if ( has_post_thumbnail() ) {
					echo '<div class="postimg">';
					echo '<div class="post_thumb">';
					$storeup_attach_img_width = ( storeup_generator( 'storeup_sidebar_option', $post->ID ) !== 'fullwidth' ) ? '600' : '980';
					echo esc_url( storeup_generator( 'storeup_get_post_attachments',$post->ID, '', '', $storeup_attach_img_width, '200', '' ) );
					echo '</div>';
					echo '</div>';
				} ?>
				<div class="post-entry">
					<h2 class="entry-title">
					<a href="<?php echo esc_url( get_permalink() ); ?>" rel="bookmark" title="<?php printf( esc_attr_e( 'Permanent Link to %s', 'storeup' ), get_the_title() ); ?>">
					<?php the_title(); ?></a></h2>
					<?php the_content(); ?>
				</div><!-- /post-entry -->
			</div><!-- Post Content -->

			<?php the_tags( '<div class="tags">' . esc_html__( 'Tags','storeup' ) . ' : ',',&nbsp; ','</div>' );?>

		</div><!-- #post-<?php the_ID(); ?> -->

		<?php
		if ( get_option( 'on' !== 'storeup_aboutauthor' ) ) {
			storeup_generator( 'storeup_about_author' );
		} ?>

			<?php if ( get_option( 'storeup_singlenavigation' ) !== 'on' ) { ?>
				<div id="nav-below" class="navigation">
					<div class="nav-previous"><?php previous_post_link( '&larr; %link' ) ?></div>
					<div class="nav-next"><?php next_post_link( '%link &rarr;' ) ?></div>
				</div><!-- #nav-below-->
			<?php } ?>
			<?php
			if ( 'on' !== get_option( 'storeup_relatedposts' ) ) {
				storeup_generator( 'storeup_related_posts', $post->ID );
			} ?>

			<?php edit_post_link( esc_html__( 'Edit', 'storeup' ), '<span class="edit-link">', '</span>' ); ?>

			<?php comments_template( '', true ); ?>

			<?php endwhile; ?>
			<?php else : ?>
			<?php '<p>' . esc_html__( 'Sorry, no posts matched your criteria.', 'storeup' ) . '</p>';?>
			<?php endif; ?>

		</div><!-- .content-area -->

		<?php if ( storeup_generator( 'storeup_sidebar_option', $post->ID ) !== 'fullwidth' ) { get_sidebar(); } ?>
		<div class="clear"></div>
	</div><!-- /inner -->
</div><!-- /pagemid -->
<?php
get_footer();
